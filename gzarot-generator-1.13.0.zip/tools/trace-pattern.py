"""Traces a multi-size pattern PDF (one colour per size, nested) into lib/patterns/<mode>.json.

Each size's cut line is drawn as dashed vector paths in its own colour. For every piece and size this joins
the paths into one closed outline, splits it at its corners, and resamples every corner-to-corner run with the
same number of points in every size, so lib/traced.js can grade between sizes point by point.
Notches (small closed triangles) and darts (3-point open lines) are collected per size too.

Run: python3 tools/trace-pattern.py tools/patterns/kardi.json path/to/A0.pdf   (needs: pip install pymupdf)
"""
import json, math, sys, os, collections
import pymupdf

MM = 25.4 / 72          # PDF points to mm
JOIN = 12               # pt: path ends closer than this belong together (dash gaps at corners)

def flatten(item, n=12):
    k = item[0]
    if k == 'l': return [(item[1].x, item[1].y), (item[2].x, item[2].y)]
    if k == 'c':
        p0, c1, c2, p3 = item[1:5]; out = []
        for i in range(n + 1):
            t = i / n; a, b, c, e = (1 - t) ** 3, 3 * (1 - t) ** 2 * t, 3 * (1 - t) * t * t, t ** 3
            out.append((a * p0.x + b * c1.x + c * c2.x + e * p3.x, a * p0.y + b * c1.y + c * c2.y + e * p3.y))
        return out
    return []

def size_paths(pdf, cfg):
    """{page: {size: [polyline, ...]}} from the thin dashed strokes, sized by nearest reference colour."""
    out = {}
    for pno, page in enumerate(pymupdf.open(pdf), 1):
        by = collections.defaultdict(list)
        for d in page.get_drawings():
            if abs((d.get('width') or 0) - 1.0) > .01 or not d.get('dashes') or d['dashes'] == '[] 0': continue
            col = d.get('color') or (0, 0, 0)
            size = min(cfg['colors'], key=lambda s: sum((a - b) ** 2 for a, b in zip(col, cfg['colors'][s])))
            pts = []
            for it in d['items']:
                f = flatten(it)
                if pts and f and math.dist(pts[-1], f[0]) < .01: f = f[1:]
                pts += f
            if len(pts) > 1: by[size].append(pts)
        out[pno] = by
    return out

def chains(segs):
    segs = [list(s) for s in segs]; out = []
    while segs:
        cur = segs.pop(0); grown = True
        while grown:
            grown = False
            for i, s in enumerate(segs):
                for a, b, rev, front in ((cur[-1], s[0], 0, 0), (cur[-1], s[-1], 1, 0), (cur[0], s[-1], 0, 1), (cur[0], s[0], 1, 1)):
                    if math.dist(a, b) < JOIN:
                        s2 = s[::-1] if rev else s
                        cur = s2[:-1] + cur if front else cur + s2[1:]
                        segs.pop(i); grown = True; break
                if grown: break
        out.append({'pts': cur, 'closed': math.dist(cur[0], cur[-1]) < JOIN})
    return out

def area(P): return sum(P[i][0] * P[(i + 1) % len(P)][1] - P[(i + 1) % len(P)][0] * P[i][1] for i in range(len(P))) / 2
def centroid(P): return (sum(p[0] for p in P) / len(P), sum(p[1] for p in P) / len(P))
def dedupe(P):
    out = []
    for p in P:
        if not out or math.dist(out[-1], p) > .3: out.append(p)
    if math.dist(out[0], out[-1]) < .3: out.pop()
    return out

def corners(P, ang=28, merge=14):
    idx = []
    for i in range(len(P)):
        a, b, c = P[i - 1], P[i], P[(i + 1) % len(P)]
        v1, v2 = (b[0] - a[0], b[1] - a[1]), (c[0] - b[0], c[1] - b[1])
        l1, l2 = math.hypot(*v1), math.hypot(*v2)
        if l1 < 1e-6 or l2 < 1e-6: continue
        if math.degrees(math.acos(max(-1, min(1, (v1[0] * v2[0] + v1[1] * v2[1]) / (l1 * l2))))) > ang:
            if not idx or math.dist(P[idx[-1]], P[i]) >= merge: idx.append(i)
    if len(idx) > 1 and math.dist(P[idx[0]], P[idx[-1]]) < merge: idx.pop()
    return idx

def resample(seg, n):
    L = [0]
    for i in range(1, len(seg)): L.append(L[-1] + math.dist(seg[i - 1], seg[i]))
    out = []
    for k in range(n):
        s = L[-1] * k / (n - 1); j = 1
        while j < len(L) - 1 and L[j] < s: j += 1
        t = (s - L[j - 1]) / ((L[j] - L[j - 1]) or 1)
        out.append((seg[j - 1][0] + t * (seg[j][0] - seg[j - 1][0]), seg[j - 1][1] + t * (seg[j][1] - seg[j - 1][1])))
    return out

def runs(P):
    """Corner-to-corner runs, starting at the corner nearest the outline's top-left."""
    cs = corners(P); x0 = min(p[0] for p in P); y0 = min(p[1] for p in P)
    s0 = min(cs, key=lambda i: P[i][0] - x0 + P[i][1] - y0); k = cs.index(s0); cs = cs[k:] + cs[:k]
    return [P[a:b + 1] if a < b else P[a:] + P[:b + 1] for a, b in zip(cs, cs[1:] + cs[:1])]

def main(cfg_path, pdf):
    cfg = json.load(open(cfg_path)); S = cfg['sizes']
    paths = size_paths(pdf, cfg)
    loops = {pg: {sz: chains(v) for sz, v in by.items()} for pg, by in paths.items()}
    out = {k: cfg[k] for k in ('key', 'mode', 'source', 'sizes', 'chart_in', 'seam_allowance_cm')}; out['pieces'] = []
    for pc in cfg['pieces']:
        pg, ref = pc['page'], pc['ref']
        outlines = {}
        for sz in S:
            big = [c for c in loops[pg][sz] if len(c['pts']) > 8]
            c = min(big, key=lambda c: math.dist(centroid(c['pts']), ref))
            if not c['closed']: sys.exit(f"{pc['key']} {sz}: outline does not close")
            P = dedupe(c['pts']); outlines[sz] = P[::-1] if area(P) < 0 else P
        R = {sz: runs(outlines[sz]) for sz in S}
        if len({len(r) for r in R.values()}) != 1: sys.exit(f"{pc['key']}: corner count differs between sizes {[len(r) for r in R.values()]}")
        mid = S[len(S) // 2]
        ns = [max(3, round(sum(math.dist(a, b) for a, b in zip(run, run[1:])) / 8.5)) for run in R[mid]]   # ~3 mm
        grid = {sz: [p for j, run in enumerate(R[sz]) for p in resample(run, ns[j])[:-1]] for sz in S}
        # notches and darts: small shapes nearest this piece
        notches, darts = {sz: [] for sz in S}, {sz: [] for sz in S}
        for sz in S:
            for c in loops[pg][sz]:
                if len(c['pts']) > 8: continue
                ctr = centroid(c['pts'])
                owner = min((q for q in cfg['pieces'] if q['page'] == pg), key=lambda q: min(math.dist(ctr, p) for p in grid_or(q, pc, grid, sz, loops, cfg)))
                if owner['key'] != pc['key']: continue
                if c['closed']: notches[sz].append(min(range(len(grid[sz])), key=lambda i: math.dist(grid[sz][i], ctr)))
                elif len(c['pts']) == 3: darts[sz].append(c['pts'])
        if len({len(v) for v in notches.values()}) != 1 or len({len(v) for v in darts.values()}) != 1: sys.exit(f"{pc['key']}: notch or dart count differs between sizes")
        mm = lambda P: [[round(x * MM, 2), round(y * MM, 2)] for x, y in P]
        out['pieces'].append(dict({k: v for k, v in pc.items() if k not in ('page', 'ref')},
            outline=[mm(grid[sz]) for sz in S], notches=sorted(notches[mid]),
            darts=[[mm(d) for d in sorted(darts[sz], key=lambda d: d[1][0])] for sz in S]))
        print(f"{pc['key']}: {len(ns)} corners, {len(grid[mid])} points, {len(notches[mid])} notches, {len(darts[mid])} darts")
    dst = os.path.join(os.path.dirname(__file__), '..', 'lib', 'patterns', cfg['mode'] + '.json')
    json.dump(out, open(dst, 'w'), separators=(',', ':'))
    print('wrote', os.path.relpath(dst), os.path.getsize(dst) // 1024, 'KB')

_outline_cache = {}
def grid_or(q, pc, grid, sz, loops, cfg):
    """Outline points of piece q in size sz (the current piece's resampled grid, or q's raw loop)."""
    if q['key'] == pc['key']: return grid[sz]
    k = (q['key'], sz)
    if k not in _outline_cache:
        big = [c for c in loops[q['page']][sz] if len(c['pts']) > 8]
        _outline_cache[k] = min(big, key=lambda c: math.dist(centroid(c['pts']), q['ref']))['pts']
    return _outline_cache[k]

if __name__ == '__main__':
    main(*sys.argv[1:3])
