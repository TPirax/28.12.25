// Fabric calculator box: fetched after each successful preview, latest request wins.
(function () {
  var box = document.getElementById('fabric'), seq = 0; if (!box) return;
  var body = box.querySelector('tbody');
  function cell(v) { var td = document.createElement('td'); if (v == null) { td.textContent = 'לא מתאים'; td.className = 'na'; td.title = 'יש חלק רחב מהבד. צריך בד רחב יותר או תפר נוסף.'; } else td.textContent = v.toFixed(1) + ' מ׳'; return td; }
  window.gzFabric = function (url, payload) {
    var my = ++seq;
    if (!url) { box.hidden = true; return; }
    fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', body: JSON.stringify(payload) })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (d) {
        if (my !== seq) return;
        if (!d || !d.fabrics || !d.fabrics.length) { box.hidden = true; return; }
        body.innerHTML = '';
        d.fabrics.forEach(function (f) {
          var tr = document.createElement('tr'), th = document.createElement('th'); th.scope = 'row'; th.textContent = f.label; tr.appendChild(th);
          (d.widths || [110, 140, 150]).forEach(function (w) { tr.appendChild(cell(f.byWidth[w])); });
          body.appendChild(tr);
        });
        box.hidden = false;
      }).catch(function () { if (my === seq) box.hidden = true; });
  };
})();
