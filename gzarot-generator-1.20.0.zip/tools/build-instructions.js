// Renders tools/instructions-src/<model>.html into instructions/<model>.pdf with headless Chromium.
// Run: node tools/build-instructions.js kim-dress   (needs the playwright package)
'use strict';
const path = require('path');
const { chromium } = require(process.env.PLAYWRIGHT || 'playwright');
(async () => {
  const names = process.argv.slice(2);
  if (!names.length) throw new Error('usage: node tools/build-instructions.js <model> [...]');
  const browser = await chromium.launch();
  for (const name of names) {
    const page = await browser.newPage();
    await page.goto('file://' + path.join(__dirname, 'instructions-src', name + '.html'));
    await page.pdf({ path: path.join(__dirname, '..', 'instructions', name + '.pdf'), format: 'A4', printBackground: true, preferCSSPageSize: true,
      displayHeaderFooter: true, headerTemplate: '<span></span>', footerTemplate: '<div style="font-size:8px;width:100%;text-align:center;color:#56655D"><span class="pageNumber"></span>/<span class="totalPages"></span></div>' });
    console.log('instructions/' + name + '.pdf');
  }
  await browser.close();
})().catch(e => { console.error(e); process.exit(1); });
