// Screenshot the generator page for a model: node tools/shot.js <model> <out.png>
const { chromium } = require('/home/claude/fit/tools/node_modules/playwright-core');
const path=require('path'),os=require('os'),fs=require('fs');
const { createApp } = require('../server'); const { signTicket } = require('../lib/ticket');
(async()=>{
  const S='x'.repeat(64),dir=fs.mkdtempSync(path.join(os.tmpdir(),'gzs-'));
  const app=createApp({secret:S,siteUrl:'https://shop.test/',dbFile:path.join(dir,'d.db'),sessionTtl:3600,secureCookies:false});
  const srv=await new Promise(r=>{const s=app.listen(0,()=>r(s));});const base='http://127.0.0.1:'+srv.address().port;
  const now=Math.floor(Date.now()/1000);
  const t=signTicket({iat:now,exp:now+600,jti:'a'+Math.random(),usage_id:7,model:process.argv[2],customer:{id:1,name:'רותם לב',email:'rotem@example.com'},profile:{id:1,label:'המידות שלי'},measurements:{height:168,bust:92,underbust:76,waist:72,hips:100,knees:82,waist_to_underbust:9,waist_to_bust:17,waist_to_hip:20,waist_to_knee:58,waist_to_floor:105},watermark:'רותם לב · rotem@example.com · gzarot #7',return_url:'https://shop.test/'},S);
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome'});
  const pg=await b.newPage({viewport:{width:+(process.argv[4]||1280),height:1000}});
  const errs=[];pg.on('console',m=>{if(m.type()==='error')errs.push(m.text())});pg.on('pageerror',e=>errs.push(String(e)));
  await pg.goto(base+'/health');
  await pg.setContent(`<form id=f method=post action="${base}/generate"><input name=ticket value="${t}"></form>`);
  await Promise.all([pg.waitForURL(/\/s\//),pg.evaluate(()=>document.getElementById('f').submit())]);
  await pg.waitForTimeout(2500);
  await pg.screenshot({path:process.argv[3],fullPage:true});
  const [dl]=await Promise.all([pg.waitForEvent('download'),pg.click('button[value=a4]')]);
  console.log('download',dl.suggestedFilename(),'errors',errs);
  await b.close();srv.close();app.close();
})();
