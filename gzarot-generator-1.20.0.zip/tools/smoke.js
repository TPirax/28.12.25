const fs=require('fs');const {engine,pdfBuffer}=require('../lib/render');
(async()=>{
  fs.mkdirSync('/home/claude/fit/out',{recursive:true});
  for(const m of Object.keys(engine.BUILD)){
    const p={...engine.DEF[m]};const t0=Date.now();
    const w=engine.validate(m,p);const b=engine.build(m,p);
    const a4=await pdfBuffer(m,b,'a4','רותם לב · rotem@example.com · gzarot #12');
    const a0=await pdfBuffer(m,b,'a0','רותם לב · rotem@example.com · gzarot #12');
    fs.writeFileSync(`/home/claude/fit/out/${m}-a4.pdf`,a4);fs.writeFileSync(`/home/claude/fit/out/${m}-a0.pdf`,a0);
    console.log(m.padEnd(8),'warn',w.length,'a4',(a4.length/1024|0)+'K','a0',(a0.length/1024|0)+'K',Date.now()-t0,'ms');
  }
})().catch(e=>{console.error(e);process.exit(1)});
