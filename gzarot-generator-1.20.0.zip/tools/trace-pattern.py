"""Traces a multi-size pattern PDF (one colour per size, nested) into lib/patterns/<mode>.json.

Each size's cut line is drawn as dashed vector paths in its own colour. For every piece and size this joins
the paths into one closed outline, splits it at its corners, and resamples every corner-to-corner run with the
same number of points in every size, so lib/traced.js can grade between sizes point by point.
Notches (small closed triangles) and darts (3-point open lines) are collected per size too.

Run: python3 tools/trace-pattern.py tools/patterns/kardi.json path/to/A0.pdf   (needs: pip install pymupdf)
"""
import json, math, sys, os, collections, heapq
import pymupdf

MM = 25.4 / 72          # PDF points to mm
JOIN = 12               # pt: path ends closer than this belong together (dash gaps at corners)

def flatten(item, n=12):
    k = item[0]
    if k == 'l': return [(item[1].x, item[1].y), (item[2].x, item[2].y)]
    if k == 'c':
        p0, c1, c2, p3 = item[1:5]; out = []
        for i in range(n + 1):
            t = i / n; a, b, c, e = (1 - t) ** 3, 3 * (1 - t) ** 2 * t, 3 * (1 - t) * t * t, t ** 3
            out.append((a * p0.x + b * c1.x + c * c2.x + e * p3.x, a * p0.y + b * c1.y + c * c2.y + e * p3.y))
        return out
    return []

def dash_pair(d, k):
    nums = [float(x) for x in d['dashes'].split(']')[0].strip('[ ').split()][:2]
    return max(nums[0] * k, 1e-3), max(nums[1] * k, 1e-3)

def size_paths(pdf, cfg):
    """{page: {size: [polyline, ...]}} from the thin dashed strokes. A size is told by its colour, or by its dash
    pattern when the file uses one pattern per size ("dashes"). Thin solid lines are edges shared by all sizes
    ("shared_solid"), added to every size. "scale" undoes a sheet that was exported scaled down.
    Files that draw a size partly solid (corners, the smallest size) set "solid_by_colour"; "stroke_width": null
    takes any width, "colour_tol" leaves out strokes in no size's colour, "ignore_pt" drops strokes inside
    [page, x0, y0, x1, y1] boxes (sheet points), such as a lining-end line across a piece."""
    out, k = {}, cfg.get('scale', 1)
    width = cfg.get('stroke_width', 1.0)
    for pno, page in enumerate(pymupdf.open(pdf), 1):
        by, shared = collections.defaultdict(list), []
        boxes = [b[1:] for b in cfg.get('ignore_pt', []) if b[0] == pno]
        for d in page.get_drawings():
            r = d['rect']
            if any(b[0] <= r.x0 and r.x1 <= b[2] and b[1] <= r.y0 and r.y1 <= b[3] for b in boxes): continue
            pts = []
            for it in d['items']:
                f = [(x * k, y * k) for x, y in flatten(it)]
                if pts and f and math.dist(pts[-1], f[0]) < .01: f = f[1:]
                pts += f
            if len(pts) < 2: continue
            if len(pts) > 2 and math.dist(pts[0], pts[-1]) < .5 and abs(area(pts)) < 1:
                pts = pts[:max(range(len(pts)), key=lambda i: math.dist(pts[0], pts[i])) + 1]  # a line drawn there and back
            solid = not d.get('dashes') or d['dashes'] == '[] 0'
            if solid and not cfg.get('solid_by_colour'):
                if cfg.get('shared_solid') and d.get('color') is not None and (d.get('width') or 0) < 1: shared.append(pts)
                continue
            if solid and d.get('color') is None: continue
            if width is not None and abs((d.get('width') or 0) - width) > .02: continue
            raw = [1, 1] if solid else [float(x) for x in d['dashes'].split(']')[0].strip('[ ').split()][:2]
            if 'dashes' in cfg and min(raw) > 0:
                a, b = dash_pair(d, k)
                size = min(cfg['dashes'], key=lambda s: min(abs(math.log(a / r[0])) + abs(math.log(b / r[1])) for r in cfg['dashes'][s]))
            else:
                col = d.get('color') or (0, 0, 0)
                size = min(cfg['colors'], key=lambda s: sum((a - b) ** 2 for a, b in zip(col, cfg['colors'][s])))
                if sum((a - b) ** 2 for a, b in zip(col, cfg['colors'][size])) > cfg.get('colour_tol', 9): continue
            by[size].append(pts)
        for size in cfg['sizes']: by[size] += shared
        out[pno] = by
    if 'sheet_offsets_mm' in cfg: out = {1: merge_sheets(out, cfg)}
    return out

def merge_sheets(pages, cfg):
    """Sheets of one big layout, each holding the paths that cross it: move every sheet into sheet 1's frame
    (local = global + offset) and keep each path once."""
    merged, seen = collections.defaultdict(list), set()
    for pno, by in pages.items():
        dx, dy = (v / MM for v in cfg['sheet_offsets_mm'][str(pno)])
        for size, segs in by.items():
            for seg in segs:
                g = [(x - dx, y - dy) for x, y in seg]
                key = (size, tuple(sorted([(round(g[0][0] / 3), round(g[0][1] / 3)), (round(g[-1][0] / 3), round(g[-1][1] / 3))])), len(g))
                if key in seen: continue
                seen.add(key); merged[size].append(g)
    return merged

def chains(segs):
    segs = [list(s) for s in segs]; out = []
    while segs:
        cur = segs.pop(0); grown = True
        while grown:
            grown = False
            for i, s in enumerate(segs):
                for a, b, rev, front in ((cur[-1], s[0], 0, 0), (cur[-1], s[-1], 1, 0), (cur[0], s[-1], 0, 1), (cur[0], s[0], 1, 1)):
                    if math.dist(a, b) < JOIN:
                        s2 = s[::-1] if rev else s
                        cur = s2[:-1] + cur if front else cur + s2[1:]
                        segs.pop(i); grown = True; break
                if grown: break
        out.append({'pts': cur, 'closed': math.dist(cur[0], cur[-1]) < JOIN})
    return out

def area(P): return sum(P[i][0] * P[(i + 1) % len(P)][1] - P[(i + 1) % len(P)][0] * P[i][1] for i in range(len(P))) / 2
def centroid(P): return (sum(p[0] for p in P) / len(P), sum(p[1] for p in P) / len(P))
def dedupe(P):
    out = []
    for p in P:
        if not out or math.dist(out[-1], p) > .3: out.append(p)
    if math.dist(out[0], out[-1]) < .3: out.pop()
    return out

ROBUST = False   # set from the config: measure each turn over SPAN on both sides, so tiny jogs are not corners
SPAN = 23        # pt (8 mm)

def unspike(P):
    """Drops lines an outline runs along and straight back (A -> B -> A), left where bridging retraced a shared edge."""
    changed = True
    while changed and len(P) > 4:
        changed = False
        for i in range(len(P)):
            a, b, c = P[i - 1], P[i], P[(i + 1) % len(P)]
            u, v = (b[0] - a[0], b[1] - a[1]), (c[0] - b[0], c[1] - b[1])
            lu, lv = math.hypot(*u), math.hypot(*v)
            if lu and lv and (u[0] * v[0] + u[1] * v[1]) / (lu * lv) < -0.99 and math.dist(a, c) < 0.2 * max(lu, lv):
                # keep the end that reaches further; drop the tip and its return
                del P[i]; changed = True; break
    return P

def cut_detours(P):
    """Drops excursions where an outline leaves along one size's line and comes back along a neighbour's: a stretch
    that ends near where it started (under 20 mm) after a path many times longer (bridging that took a long way)."""
    lim = 20 / MM
    while True:
        cum = [0]
        for k in range(1, 2 * len(P)): cum.append(cum[-1] + math.dist(P[(k - 1) % len(P)], P[k % len(P)]))
        best = None
        for i in range(len(P)):
            for j in range(i + 2, i + len(P) // 2):
                d = math.dist(P[i], P[j % len(P)]); L = cum[j] - cum[i]
                if d < lim and L > 10 * d + 200 / MM and (not best or L > best[2]): best = (i, j, L)
        if not best: return P
        i, j, _ = best
        keep = [P[k % len(P)] for k in range(j, i + len(P) + 1)]
        P = keep[:-1] if math.dist(keep[0], keep[-1]) < 1e-9 else keep

def walk(P, i, step, dist):
    """Point at arc distance dist from P[i] going forwards (step=1) or backwards (step=-1)."""
    n, d, j = len(P), 0, i
    for _ in range(n):
        k = (j + step) % n; d += math.dist(P[j], P[k]); j = k
        if d >= dist: return P[j]
    return P[j]

def robust_corners(P, ang, merge):
    turn = []
    for i in range(len(P)):
        a, b, c = walk(P, i, -1, SPAN), P[i], walk(P, i, 1, SPAN)
        v1, v2 = (b[0] - a[0], b[1] - a[1]), (c[0] - b[0], c[1] - b[1]); l1, l2 = math.hypot(*v1), math.hypot(*v2)
        turn.append(math.degrees(math.acos(max(-1, min(1, (v1[0] * v2[0] + v1[1] * v2[1]) / (l1 * l2))))) if l1 and l2 else 0)
    idx = []
    for i in sorted(range(len(P)), key=lambda i: -turn[i]):   # strongest turns first, then suppress neighbours
        if turn[i] <= ang: break
        if all(math.dist(P[i], P[j]) >= max(merge, SPAN) for j in idx): idx.append(i)
    return sorted(idx)

def corners(P, ang=28, merge=14):  # merge in pt
    if ROBUST: return robust_corners(P, ang, merge)
    idx = []
    for i in range(len(P)):
        a, b, c = P[i - 1], P[i], P[(i + 1) % len(P)]
        v1, v2 = (b[0] - a[0], b[1] - a[1]), (c[0] - b[0], c[1] - b[1])
        l1, l2 = math.hypot(*v1), math.hypot(*v2)
        if l1 < 1e-6 or l2 < 1e-6: continue
        if math.degrees(math.acos(max(-1, min(1, (v1[0] * v2[0] + v1[1] * v2[1]) / (l1 * l2))))) > ang:
            if not idx or math.dist(P[idx[-1]], P[i]) >= merge: idx.append(i)
    if len(idx) > 1 and math.dist(P[idx[0]], P[idx[-1]]) < merge: idx.pop()
    return idx

def resample(seg, n):
    L = [0]
    for i in range(1, len(seg)): L.append(L[-1] + math.dist(seg[i - 1], seg[i]))
    out = []
    for k in range(n):
        s = L[-1] * k / (n - 1); j = 1
        while j < len(L) - 1 and L[j] < s: j += 1
        t = (s - L[j - 1]) / ((L[j] - L[j - 1]) or 1)
        out.append((seg[j - 1][0] + t * (seg[j][0] - seg[j - 1][0]), seg[j - 1][1] + t * (seg[j][1] - seg[j - 1][1])))
    return out

def runs(P):
    """Corner-to-corner runs, starting at the corner nearest the outline's top-left."""
    cs = corners(P); x0 = min(p[0] for p in P); y0 = min(p[1] for p in P)
    s0 = min(cs, key=lambda i: P[i][0] - x0 + P[i][1] - y0); k = cs.index(s0); cs = cs[k:] + cs[:k]
    return [P[a:b + 1] if a < b else P[a:] + P[:b + 1] for a, b in zip(cs, cs[1:] + cs[:1])]

def shortest_route(a, b, pool, limit=4000):
    """Points of the shortest chain of pool lines leading from a to b (ends within JOIN), or None."""
    L = lambda seg: sum(math.dist(seg[i - 1], seg[i]) for i in range(1, len(seg)))
    best, prev, heap, n = {None: 0}, {}, [(0, 0, None, a)], 0
    while heap:
        d, _, node, pt = heapq.heappop(heap)
        if d > best.get(node, 1e18): continue
        if node is not None and math.dist(pt, b) < JOIN:
            out = []
            while node is not None:
                i, rev = node; out = (pool[i][::-1] if rev else pool[i])[1:] + out; node = prev[node]
            return out
        if d > limit / MM: continue
        for i, seg in enumerate(pool):
            for rev in (0, 1):
                s2 = seg[::-1] if rev else seg
                if math.dist(s2[0], pt) < JOIN and d + L(s2) < best.get((i, rev), 1e18):
                    best[(i, rev)] = d + L(s2); prev[(i, rev)] = node; n += 1
                    heapq.heappush(heap, (d + L(s2), n, (i, rev), s2[-1]))
    return None

MATCH = 25     # pt (9 mm): how far a corner may move between neighbouring sizes

def matched_runs(outlines, S, mid, key):
    """Corner-to-corner runs with the same corners in every size. The middle size's corners are the template;
    each next size outwards takes, for every corner of its neighbour, its own nearest corner (or, where that size
    has none there, the nearest outline point), so a short edge seen as a corner in one size only cannot shift
    the correspondence."""
    own = {sz: runs(outlines[sz]) for sz in S}
    if len({len(r) for r in own.values()}) == 1: return own   # every size has the same corners
    cand = {sz: corners(outlines[sz], ang=25, merge=8) for sz in S}
    P = outlines[mid]; cs = corners(P, merge=34); x0 = min(p[0] for p in P); y0 = min(p[1] for p in P)   # corners under 12 mm apart count as one
    s0 = min(cs, key=lambda i: P[i][0] - x0 + P[i][1] - y0); k = cs.index(s0)
    picks = {mid: cs[k:] + cs[:k]}
    i = S.index(mid)
    for order in (range(i - 1, -1, -1), range(i + 1, len(S))):
        prev = mid
        for j in order:
            sz, Q = S[j], outlines[S[j]]
            def match(use_corners):
                out = []
                for c in picks[prev]:
                    q = outlines[prev][c]
                    near = [m for m in cand[sz] if math.dist(Q[m], q) < MATCH and m not in out] if use_corners else []
                    out.append(min(near, key=lambda m: math.dist(Q[m], q)) if near else min(range(len(Q)), key=lambda m: math.dist(Q[m], q)))
                rel = [(m - out[0]) % len(Q) for m in out]
                return out if rel == sorted(rel) and len(set(out)) == len(out) else None
            out = match(True) or match(False)   # nearest outline points when nearby corners cross over
            if not out: sys.exit(f"{key} {sz}: corners do not follow the outline in the same order as {prev}")
            picks[sz] = out; prev = sz
    return {sz: [outlines[sz][a:b + 1] if a < b else outlines[sz][a:] + outlines[sz][:b + 1] for a, b in zip(picks[sz], picks[sz][1:] + picks[sz][:1])] for sz in S}

def main(cfg_path, pdf):
    global ROBUST, JOIN0
    cfg = json.load(open(cfg_path)); S = cfg['sizes']; ROBUST = cfg.get('robust_corners', False); JOIN0 = JOIN
    paths = size_paths(pdf, cfg)
    def build_loops():
        loops = {pg: {sz: chains(v) for sz, v in by.items()} for pg, by in paths.items()}
        # an edge common to several sizes is often drawn once, in one size's style: an open outline is closed along
        # the shortest route of lines (any size) from its end back to its start
        for pg, by in paths.items():
            for sz in S:
                for c in loops[pg][sz]:
                    if c['closed'] or len(c['pts']) <= 8: continue
                    on = {(round(x, 1), round(y, 1)) for x, y in c['pts']}
                    pool = [seg for o in S for seg in by[o] if not (o == sz and all((round(x, 1), round(y, 1)) in on for x, y in seg))]
                    gap = math.dist(c['pts'][-1], c['pts'][0]) * MM
                    route = shortest_route(c['pts'][-1], c['pts'][0], pool, limit=gap * 2 + 100)   # no long detours
                    if route is not None: c['pts'] = c['pts'] + route; c['closed'] = True
        return loops
    loops_for = {}
    def loops_at(join_mm):
        """Outlines joined with this tolerance (a piece may need a looser one than the rest of the sheet)."""
        global JOIN
        if join_mm not in loops_for:
            JOIN = join_mm / MM if join_mm else JOIN0
            loops_for[join_mm] = build_loops()
            JOIN = JOIN0
        return loops_for[join_mm]
    out = {k: cfg[k] for k in ('key', 'mode', 'source', 'sizes', 'chart_in', 'seam_allowance_cm')}; out['pieces'] = []
    for pc in cfg['pieces']:
        pg, ref = pc['page'], pc['ref']
        loops = loops_at(pc.get('join_mm'))
        ROBUST = pc.get('robust_corners', cfg.get('robust_corners', False))
        outlines = {}
        for sz in S:
            big = [c for c in loops[pg][sz] if len(c['pts']) > 8]
            c = min(big, key=lambda c: math.dist(centroid(c['pts']), ref))
            if not c['closed']:
                gap = math.dist(c['pts'][0], c['pts'][-1]) * MM
                if gap > pc.get('close_gap_mm', 0): sys.exit(f"{pc['key']} {sz}: outline does not close ({gap:.1f} mm gap)")
                # an edge drawn once for one size only (e.g. a straight top edge) is closed with a straight line
            P = cut_detours(unspike(dedupe(c['pts']))); outlines[sz] = P[::-1] if area(P) < 0 else P
        mid = S[len(S) // 2]
        # the template is the size nearest the middle whose corners agree with most sizes, so one size with a
        # stray kink cannot set the correspondence for all of them
        count = {sz: len(corners(outlines[sz], merge=34)) for sz in S}
        common = collections.Counter(count.values()).most_common(1)[0][0]
        tmpl = min((sz for sz in S if count[sz] == common), key=lambda sz: abs(S.index(sz) - S.index(mid)))
        R = matched_runs(outlines, S, tmpl, pc['key'])
        ns = [max(3, round(sum(math.dist(a, b) for a, b in zip(run, run[1:])) / 8.5)) for run in R[tmpl]]   # ~3 mm
        grid = {sz: [p for j, run in enumerate(R[sz]) for p in resample(run, ns[j])[:-1]] for sz in S}
        # notches and darts: small shapes nearest this piece
        notches, darts = {sz: [] for sz in S}, {sz: [] for sz in S}
        for sz in S:
            for c in loops[pg][sz]:
                if len(c['pts']) > 8: continue
                ctr = centroid(c['pts'])
                owner = min((q for q in cfg['pieces'] if q['page'] == pg), key=lambda q: min(math.dist(ctr, p) for p in grid_or(q, pc, grid, sz, loops, cfg)))
                if owner['key'] != pc['key']: continue
                if c['closed']: notches[sz].append(min(range(len(grid[sz])), key=lambda i: math.dist(grid[sz][i], ctr)))
                elif len(c['pts']) == 3: darts[sz].append(c['pts'])
                elif len(c['pts']) == 2 and cfg.get('tick_notches') and math.dist(*c['pts']) * MM < 12:   # a short tick on the edge
                    end = min(c['pts'], key=lambda q: min(math.dist(q, g) for g in grid[sz]))
                    notches[sz].append(min(range(len(grid[sz])), key=lambda i: math.dist(grid[sz][i], end)))
        if pc.get('notch_size'):   # notches drawn for one size only stand for all sizes
            notches = {sz: notches[pc['notch_size']] for sz in S}
        # a mark drawn in only some sizes (a stray tick) is dropped: keep the count most sizes agree on
        for marks, name, pos in ((notches, 'notch', lambda sz, m: grid[sz][m]), (darts, 'dart', lambda sz, m: m[1])):
            want = collections.Counter(len(v) for v in marks.values()).most_common(1)[0][0]
            ref = next(sz for sz in [mid] + S if len(marks[sz]) == want)
            for sz in S:
                if len(marks[sz]) < want: sys.exit(f"{pc['key']} {sz}: missing a {name} ({[len(marks[s]) for s in S]})")
                if len(marks[sz]) > want:
                    marks[sz] = [min(marks[sz], key=lambda m: math.dist(pos(sz, m), pos(ref, r))) for r in marks[ref]]
                    print(f"  {pc['key']} {sz}: dropped a stray {name}")
        # a piece printed upside down on the sheet is turned upright
        turn = -1 if pc.get('rotate') == 180 else 1
        mm = lambda P: [[round(turn * x * MM, 2), round(turn * y * MM, 2)] for x, y in P]
        out['pieces'].append(dict({k: v for k, v in pc.items() if k not in ('page', 'ref', 'rotate', 'notch_size')},
            outline=[mm(grid[sz]) for sz in S], notches=sorted(notches[mid] if len(notches[mid]) else []),
            darts=[[mm(d) for d in sorted(darts[sz], key=lambda d: d[1][0])] for sz in S]))
        print(f"{pc['key']}: {len(ns)} corners, {len(grid[mid])} points, {len(notches[mid])} notches, {len(darts[mid])} darts")
    dst = os.path.join(os.path.dirname(__file__), '..', 'lib', 'patterns', cfg['mode'] + '.json')
    json.dump(out, open(dst, 'w'), separators=(',', ':'))
    print('wrote', os.path.relpath(dst), os.path.getsize(dst) // 1024, 'KB')

_outline_cache = {}
def grid_or(q, pc, grid, sz, loops, cfg):
    """Outline points of piece q in size sz (the current piece's resampled grid, or q's raw loop)."""
    if q['key'] == pc['key']: return grid[sz]
    k = (q['key'], sz)
    if k not in _outline_cache:
        big = [c for c in loops[q['page']][sz] if len(c['pts']) > 8]
        _outline_cache[k] = min(big, key=lambda c: math.dist(centroid(c['pts']), q['ref']))['pts']
    return _outline_cache[k]

if __name__ == '__main__':
    main(*sys.argv[1:3])
