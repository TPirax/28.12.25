'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { checkMeasurements } = require('../lib/checks');
const { areasFor, summarize, lean } = require('../lib/fit');

test('measurements: typical bodies pass, typos and swapped values are flagged', () => {
  assert.deepStrictEqual(checkMeasurements({ bust: 92, waist: 74, hips: 100, height: 165, waist_to_floor: 104 }), []);
  assert.deepStrictEqual(checkMeasurements({ bust: 36, waist: 28, hips: 38 }).map(c => c.fields[0]), ['bust', 'waist', 'hips'], 'inches');
  assert.deepStrictEqual(checkMeasurements({ bust: 92, underbust: 96 }).map(c => c.fields), [['underbust', 'bust']]);
  assert.deepStrictEqual(checkMeasurements({ bust: 88, waist: 104, hips: 100 }).map(c => c.fields), [['waist', 'bust']]);
  assert.strictEqual(checkMeasurements({ height: 165, waist_to_floor: 70 }).length, 1);
  assert.deepStrictEqual(checkMeasurements({ bust: 36, waist: 74 }, ['waist']), [], 'only the fields the pattern uses');
});

test('fit: areas follow the model, averages read as words', () => {
  assert.deepStrictEqual(areasFor({ body: { W: 'waist', H: 'hips' } }).map(a => a[0]), ['waist', 'hips', 'length']);
  const s = summarize([{ model: 'm', answers: { waist: -1, length: 0, overall: 4 }, note: 'צר במותן', at: 2 }, { model: 'm', answers: { waist: -2, length: 0, overall: 5 }, at: 1 }], { MODELS: { m: { name: 'דגם' } } });
  assert.strictEqual(s[0].n, 2); assert.strictEqual(s[0].overall, 4.5);
  assert.deepStrictEqual(s[0].areas.map(a => [a.key, lean(a.avg, a.key)]), [['waist', 'צר'], ['length', 'מתאים']]);
  assert.strictEqual(lean(.5, 'hips'), 'נוטה להיות רחב'); assert.strictEqual(lean(-.6, 'length'), 'נוטה להיות קצר');
});
