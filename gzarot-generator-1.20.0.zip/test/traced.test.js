'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { gradePiece, DEFS, build } = require('../lib/traced');
const { engine } = require('../lib/render');

for (const name of ['kardi', 'apoline', 'kaliya']) {
  test(`${name}: grading at a chart size reproduces the traced size exactly`, () => {
    const data = require(`../lib/patterns/${name}.json`), mid = Math.floor(data.sizes.length / 2);
    for (let s = 0; s < data.sizes.length; s++) for (const pc of data.pieces) {
      const g = gradePiece(pc, { B: s, W: s, H: s }, 0, mid);   // mid is unused for the outline
      g.cut.forEach((p, i) => assert.ok(Math.hypot(p[0] - pc.outline[s][i][0], p[1] - pc.outline[s][i][1]) < 0.01, `${pc.key} ${data.sizes[s]} #${i}`));
    }
  });
}

test('apoline: corset and skirt take their own pieces; skirt length moves the hem only', () => {
  const data = require('../lib/patterns/apoline.json');
  const corset = build(data, DEFS.apoline, engine, { B: 91, W: 71, H: 99 });
  const skirt = build(data, DEFS.apolineskirt, engine, { W: 71, H: 99, dL: 0 });
  assert.strictEqual(corset.pieces, data.pieces.filter(p => p.group === 'corset').length + 1);
  assert.strictEqual(skirt.pieces, data.pieces.filter(p => p.group === 'skirt').length + 1);
  const pc = data.pieces.find(p => p.key === 'fskirt2'), T = { W: 3, H: 3 };
  const a = gradePiece(pc, T, 0, 3).cut, b = gradePiece(pc, T, 10, 3).cut;
  const ext = c => [Math.min(...c.map(p => p[0])), Math.max(...c.map(p => p[0]))];
  assert.ok(Math.abs(ext(b)[1] - ext(a)[1] - 100) < 0.5 && Math.abs(ext(b)[0] - ext(a)[0]) < 0.5, 'the horizontal front panel lengthens at its hem end');
  assert.deepStrictEqual(engine.validate('apolineskirt', { W: 0, H: 99 }).length, 1);
});

test('kaliya: dress length changes below the hip line only; the upside-down front is turned upright', () => {
  const data = require('../lib/patterns/kaliya.json'), T = { B: 2, W: 2, H: 2 };
  for (const key of ['front', 'back']) {
    const pc = data.pieces.find(p => p.key === key);
    const a = gradePiece(pc, T, 0, 4).cut, b = gradePiece(pc, T, 5, 4).cut;
    const ys = c => c.map(p => p[1]);
    assert.ok(Math.abs(Math.max(...ys(b)) - Math.max(...ys(a)) - 50) < 0.5, key + ': hem moves 5 cm');
    assert.ok(Math.abs(Math.min(...ys(b)) - Math.min(...ys(a))) < 0.01, key + ': shoulders stay');
    // the hem is wider than the shoulders' width at the top of the piece: upright
    const w = (c, top) => { const y0 = Math.min(...ys(c)), y1 = Math.max(...ys(c)), lim = top ? y0 + 30 : y1 - 30; const xs = c.filter(p => top ? p[1] < lim : p[1] > lim).map(p => p[0]); return Math.max(...xs) - Math.min(...xs); };
    assert.ok(w(a, false) > w(a, true) * 0.9, key + ' upright');
  }
});
