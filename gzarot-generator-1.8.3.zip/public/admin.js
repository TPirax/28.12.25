// Admin studio: show only the measurements the chosen model needs.
'use strict';
(() => {
  const sel = document.getElementById('model'); if (!sel) return;
  const all = document.getElementById('all'), count = document.getElementById('need-count');
  document.getElementById('all-wrap').hidden = false;
  const update = () => {
    const list = name => (sel.selectedOptions[0].dataset[name] || '').split(' ').filter(Boolean);
    const need = list('fields'), optional = list('optional');
    for (const f of document.querySelectorAll('.af')) {
      const req = need.includes(f.dataset.f), opt = optional.includes(f.dataset.f);
      f.querySelector('input').required = req;
      f.classList.toggle('opt', opt);
      f.hidden = !req && !opt && !all.checked;
    }
    for (const g of document.querySelectorAll('.admin-group')) g.hidden = !g.querySelector('.af:not([hidden])');
    count.textContent = need.length ? `(${need.length} מידות נדרשות${optional.length ? `, ${optional.length} רשות` : ''})` : '(הדגם הזה לפי מידה, בלי מידות גוף)';
  };
  sel.addEventListener('change', update);
  all.addEventListener('change', update);
  update();
})();
