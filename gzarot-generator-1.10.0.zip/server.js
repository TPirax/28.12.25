// gzarot pattern generator: receives a signed ticket from WordPress, lets the customer
// choose design options, and returns a PDF watermarked with her name and email.
'use strict';
const path = require('path');
const fs = require('fs');
const os = require('os');
const express = require('express');
const { engine, pdfBuffer } = require('./lib/render');
const models = require('./lib/models');
const { verifyTicket } = require('./lib/ticket');
const { openStore } = require('./lib/store');
const { page, errorPage, generatorPage } = require('./lib/pages');
const { previewPng } = require('./lib/preview');
const yardage = require('./lib/yardage');
const { mountAdmin } = require('./lib/admin');
const photo = require('./lib/photo');
const { claudeVision } = require('./lib/vision');
const { wpCharge } = require('./lib/charge');

function createApp(cfg) {
  if (!cfg.secret || cfg.secret.length < 32) throw new Error('GZFQ_SECRET must be set (at least 32 characters)');
  cfg.maxAnalysesPerDay = cfg.maxAnalysesPerDay || 8;
  const store = openStore(cfg.dbFile);
  models.setCatalogDesigns(store.catalog());
  const app = express();
  app.disable('x-powered-by');
  if (cfg.trustProxy) app.set('trust proxy', 1);

  app.use((req, res, next) => {
    res.set({
      'Content-Security-Policy': "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'",
      'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin', 'X-Frame-Options': 'DENY',
      'Cache-Control': 'no-store',
    });
    next();
  });
  app.use('/static', express.static(path.join(__dirname, 'public'), { maxAge: '1d', setHeaders: r => r.set('Cache-Control', 'public, max-age=86400') }));

  // ---- small in-memory rate limit for ticket hand-offs
  const hits = new Map();
  const limited = (ip, max) => {
    const t = Math.floor(Date.now() / 60000), k = ip + ':' + t, n = (hits.get(k) || 0) + 1;
    hits.set(k, n);
    if (hits.size > 5000) for (const key of hits.keys()) if (!key.endsWith(':' + t)) hits.delete(key);
    return n > max;
  };

  // ---- PDF concurrency guard (PDF building is CPU heavy)
  const maxJobs = cfg.maxJobs || Math.max(1, Math.min(4, os.cpus().length));
  let running = 0; const queue = [];
  const withSlot = fn => new Promise((resolve, reject) => {
    const go = () => { running++; Promise.resolve().then(fn).then(resolve, reject).finally(() => { running--; const n = queue.shift(); if (n) n(); }); };
    if (running < maxJobs) go(); else if (queue.length < 20) queue.push(go); else reject(Object.assign(new Error('busy'), { code: 'busy' }));
  });

  const siteLink = p => (p && p.return_url) || cfg.siteUrl || '/';

  app.get('/favicon.ico', (req, res) => res.status(204).end());
  app.get('/health', (req, res) => res.json({ ok: true, models: Object.keys(models.MODELS).length }));
  app.get('/models.json', (req, res) => { res.set('Cache-Control', 'public, max-age=300'); res.json(models.manifest()); });

  // ---- 1. hand-off from WordPress
  app.post('/generate', express.urlencoded({ extended: false, limit: '32kb' }), (req, res) => {
    if (limited(req.ip, 30)) return res.status(429).send(errorPage('יותר מדי ניסיונות', 'נסי שוב בעוד דקה.', cfg.siteUrl));
    const v = verifyTicket(req.body && req.body.ticket, cfg.secret);
    if (!v.ok) {
      log('ticket_rejected', { error: v.error, ip: req.ip });
      const msg = v.error === 'expired' ? 'הקישור פג תוקף.' : 'לא הצלחנו לאמת את הבקשה.';
      return res.status(403).send(errorPage(msg, 'חזרי לאזור האישי באתר ולחצי שוב על ״צרי את הגזרה״. ההפקה החוזרת לא תיספר מהמכסה.', cfg.siteUrl));
    }
    const p = v.payload;
    if (!store.useTicket(p.jti, p.exp)) {
      return res.status(403).send(errorPage('הקישור כבר נוצל.', 'כל קישור מהאתר משמש פעם אחת. חזרי לאזור האישי ולחצי שוב, ההפקה החוזרת לא תיספר מהמכסה.', siteLink(p)));
    }
    if (!models.MODELS[p.model]) {
      log('unknown_model', { model: p.model, usage: p.usage_id });
      return res.status(400).send(errorPage('הדגם הזה עדיין לא זמין במחולל.', 'פני אלינו ונטפל בזה. ההפקה לא תיספר שוב כשננסה מחדש.', siteLink(p)));
    }
    const s = store.createSession(p, cfg.sessionTtl);
    res.cookie('gzk_' + s.id, s.key, { httpOnly: true, secure: cfg.secureCookies, sameSite: 'lax', path: '/s/' + s.id, maxAge: cfg.sessionTtl * 1000 });
    log('session', { usage: p.usage_id, model: p.model, customer: p.customer && p.customer.id });
    res.redirect(303, '/s/' + s.id);
  });

  // ---- session helpers
  const cookieOf = (req, id) => {
    const raw = req.headers.cookie || '';
    for (const part of raw.split(';')) { const i = part.indexOf('='); if (i > 0 && part.slice(0, i).trim() === 'gzk_' + id) return decodeURIComponent(part.slice(i + 1).trim()); }
    return null;
  };
  const load = (req, res) => {
    const s = store.session(req.params.id, cookieOf(req, req.params.id));
    if (!s) { res.status(403).send(errorPage('החלון הזה כבר לא פעיל.', 'מטעמי אבטחה הקישור עובד רק בדפדפן שבו פתחת אותו, ולמשך שלוש שעות. חזרי לאזור האישי באתר ולחצי על ״הורדה חוזרת״, ללא חיוב.', cfg.siteUrl)); return null; }
    return s.payload;
  };
  const prepare = (p, rawOptions) => {
    const key = p.model, M = models.MODELS[key];
    const miss = models.missing(key, p.measurements);
    if (miss.length) return { miss };
    const params = models.params(key, p.measurements, rawOptions);
    const warnings = engine.validate(M.mode, params);
    if (models.blocking(M.mode, warnings)) return { params, warnings, built: null };
    let built = null;
    try { built = engine.build(M.mode, params); } catch (e) { log('build_error', { model: key, err: String(e && e.stack || e) }); warnings.push('לא ניתן לשרטט עם האפשרויות האלה. נסי ערכים אחרים או פני אלינו.'); }
    return { params, warnings, built };
  };

  // ---- 2. options + preview page
  app.get('/s/:id', (req, res) => {
    const p = load(req, res); if (!p) return;
    const key = p.model, M = models.MODELS[key];
    const miss = models.missing(key, p.measurements);
    if (miss.length) {
      return res.send(errorPage('חסרות מידות בפרופיל', `כדי לחשב את ${M.name} צריך להוסיף לפרופיל ״${p.profile && p.profile.label || ''}״: ${miss.map(f => models.PROFILE_FIELDS[f] || f).join(', ')}. אחרי השמירה לחצי שוב על ״צרי את הגזרה״. ההפקה החוזרת לא תיספר מהמכסה.`, siteLink(p), 'חזרה לפרופיל המידות'));
    }
    if (M.kind === 'photo') return photoCtx.photoPage(req, res, p);
    if (M.kind === 'design') return photoCtx.catalogDesignPage(req, res, p, M);
    res.send(generatorPage({ id: req.params.id, payload: p, model: models.describe(key), mode: M.mode, info: engine.MODE_INFO[M.mode],
      options: models.defaultOptions(key, p.measurements), profileFields: models.PROFILE_FIELDS, body: M.body }));
  });

  app.post('/s/:id/preview', express.json({ limit: '8kb' }), async (req, res) => {
    const p = load(req, res); if (!p) return;
    const r = prepare(p, req.body && req.body.options);
    if (r.miss) return res.status(400).json({ error: 'missing' });
    if (!r.built) return res.json({ warnings: r.warnings, img: null });
    const b = r.built, a0 = engine.pages(b.bb, 'a0');
    try {
      const img = await withSlot(() => previewPng(b, p.customer && p.customer.name));
      const M = models.MODELS[p.model], used = {};
      for (const k of Object.keys(M.body)) used[k] = r.params[k];
      res.json({ warnings: r.warnings, img: img.url, w: img.w, h: img.h, used, a4: engine.a4Count(b), a0: a0.cols * a0.rows });
    } catch (e) {
      if (e.code === 'busy') return res.status(503).json({ error: 'busy' });
      log('preview_error', { model: p.model, err: String(e && e.stack || e) }); res.status(500).json({ error: 'preview' });
    }
  });

  // ---- fabric calculator (same options as the preview)
  app.post('/s/:id/fabric', express.json({ limit: '8kb' }), async (req, res) => {
    const p = load(req, res); if (!p) return;
    const r = prepare(p, req.body && req.body.options);
    if (!r.built) return res.json({ fabrics: null });
    try {
      const out = await withSlot(() => yardage.fabricNeeds(p.model, r.built));
      res.json(out ? { fabrics: out.fabrics, widths: yardage.WIDTHS } : { fabrics: null });
    } catch (e) {
      if (e.code === 'busy') return res.status(503).json({ error: 'busy' });
      log('fabric_error', { model: p.model, err: String(e && e.stack || e) }); res.status(500).json({ error: 'fabric' });
    }
  });

  // ---- 3. PDF download
  app.post('/s/:id/pdf', express.urlencoded({ extended: false, limit: '8kb' }), async (req, res) => {
    const p = load(req, res); if (!p) return;
    const format = req.body.f === 'a0' ? 'a0' : 'a4';
    const raw = {}; for (const [k, v] of Object.entries(req.body)) if (k.startsWith('o_')) raw[k.slice(2)] = v;
    const r = prepare(p, raw);
    if (!r.built) return res.status(400).send(errorPage('אי אפשר להפיק את הגזרה עם האפשרויות האלה', (r.warnings || []).join(' ') || 'חסרות מידות.', '/s/' + req.params.id, 'חזרה'));
    const M = models.MODELS[p.model];
    try {
      const buf = await withSlot(() => pdfBuffer(M.mode, r.built, format, p.watermark || ''));
      store.logDownload({ usage_id: p.usage_id, customer_id: p.customer && p.customer.id, model: p.model, format, options: r.params, ip: req.ip });
      const file = `${engine.MODE_INFO[M.mode].file}-${format.toUpperCase()}.pdf`;
      res.set({ 'Content-Type': 'application/pdf', 'Content-Disposition': `attachment; filename="${file}"`, 'Content-Length': buf.length });
      res.end(buf);
    } catch (e) {
      if (e.code === 'busy') return res.status(503).send(errorPage('יש עומס רגעי', 'נסי שוב בעוד חצי דקה.', '/s/' + req.params.id, 'חזרה'));
      log('pdf_error', { model: p.model, err: String(e && e.stack || e) });
      res.status(500).send(errorPage('משהו השתבש ביצירת הקובץ', 'נסי שוב. אם זה חוזר, פני אלינו ונבדוק.', '/s/' + req.params.id, 'חזרה'));
    }
  });

  // ---- 4. sewing instructions for the session's model (not counted as a download)
  app.get('/s/:id/instructions', (req, res) => {
    const p = load(req, res); if (!p) return;
    const kind = models.MODELS[p.model] && models.MODELS[p.model].kind;
    const file = path.join(__dirname, 'instructions', `${kind === 'design' ? 'photo-pattern' : p.model}.pdf`);
    if (!/^[a-z0-9-]+$/.test(p.model) || !fs.existsSync(file)) return res.status(404).send(errorPage('אין עדיין הוראות לדגם הזה', 'נוסיף אותן בקרוב.', '/s/' + req.params.id, 'חזרה'));
    res.download(file, `${p.model}-sewing-instructions.pdf`, { headers: { 'Cache-Control': 'private, max-age=3600' } });
  });

  const photoCtx = { store, load, withSlot, cfg, log, engine, yardage,
    vision: cfg.vision !== undefined ? cfg.vision : (cfg.anthropicKey ? claudeVision({ apiKey: cfg.anthropicKey, model: cfg.visionModel }) : null),
    charge: cfg.charge || wpCharge(cfg.secret) };
  photo.mount(app, photoCtx);
  mountAdmin(app, { store, cfg, photoEnabled: !!photoCtx.vision });

  app.use((req, res) => res.status(404).send(errorPage('הדף לא נמצא', 'חזרי לאתר והתחילי מהאזור האישי.', cfg.siteUrl)));
  app.use((err, req, res, next) => { log('error', { err: String(err && err.stack || err) }); res.status(500).send(errorPage('משהו השתבש', 'נסי שוב בעוד רגע.', cfg.siteUrl)); });

  const timer = setInterval(() => store.purge(), 10 * 60 * 1000); timer.unref();
  app.close = () => { clearInterval(timer); store.close(); };
  return app;
}

function log(event, data) { console.log(JSON.stringify(Object.assign({ t: new Date().toISOString(), event }, data))); }

// Hostinger loads the entry file as a module, so startup must not depend on require.main.
// The test runner requires this file and starts its own apps.
if (require.main === module || !process.env.NODE_TEST_CONTEXT) {
  const dataDir = process.env.DATA_DIR || path.join(__dirname, 'data');
  fs.mkdirSync(dataDir, { recursive: true });
  const app = createApp({
    secret: process.env.GZFQ_SECRET,
    adminPassword: process.env.GIZRA_ADMIN_PASSWORD || '',
    siteUrl: process.env.SITE_URL || '',
    dbFile: path.join(dataDir, 'generator.db'),
    sessionTtl: Number(process.env.SESSION_TTL || 3 * 3600),
    secureCookies: process.env.INSECURE_COOKIES !== '1',
    trustProxy: process.env.TRUST_PROXY !== '0',
    anthropicKey: process.env.ANTHROPIC_API_KEY || '',
    // development only: answer photo analyses with a fixture instead of calling the API
    vision: process.env.VISION_MOCK && process.env.NODE_ENV !== 'production'
      ? async () => ({ spec: JSON.parse(JSON.stringify(require('./test/fixtures/specs')[process.env.VISION_MOCK])), usage: {} }) : undefined,
    visionModel: process.env.VISION_MODEL || 'claude-sonnet-5-5',
    maxAnalysesPerDay: Number(process.env.MAX_ANALYSES_PER_DAY || 8),
  });
  const port = Number(process.env.PORT || 3000);
  app.listen(port, '0.0.0.0', () => log('listening', { port }));
}

module.exports = { createApp };
