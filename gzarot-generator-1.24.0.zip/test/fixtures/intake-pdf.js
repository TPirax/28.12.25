// A small multi-size pattern file like the designers' A0 sheets: three nested sizes in three colours, a printed
// 10 cm ruler, size names and notch ticks. Used by the intake tests instead of a real pattern.
'use strict';
const { jsPDF } = require('jspdf');

const SIZES = [['S', [230, 30, 30]], ['M', [30, 150, 40]], ['L', [30, 60, 230]]];
// outlines in points around their centre: a bodice (straight sides, a curved armhole) and a sleeve cap
const BODICE = { c: [300, 600], pts: [[-120, -260], [-40, -260], ['c', [-30, -200], [40, -170], [110, -160]], [130, 260], [-130, 260], [-110, 0]], notch: 5 };
const SLEEVE = { c: [700, 500], pts: [[-140, 150], ['c', [-120, -60], [-40, -170], [0, -170]], ['c', [40, -170], [120, -60], [140, 150]]], notch: null };

function pdf() {
  const doc = new jsPDF({ unit: 'pt', format: [1000, 1300], compress: true });
  doc.setFontSize(10);
  // ruler: the line between the labels is 10 cm
  doc.text('0 CM', 60, 1240, { align: 'center' }); doc.text('10 CM', 60 + 283.465, 1240, { align: 'center' });
  doc.setDrawColor(0, 0, 0); doc.setLineWidth(0.5); doc.line(60, 1250, 60 + 283.465, 1250);
  SIZES.forEach(([name, rgb], k) => {
    const f = 1 + 0.06 * k;
    doc.setDrawColor(...rgb); doc.setLineWidth(0.8); doc.setTextColor(...rgb);
    doc.text(name, 860, 1100 + 20 * k);
    for (const sh of [BODICE, SLEEVE]) {
      const at = p => [sh.c[0] + p[0] * f, sh.c[1] + p[1] * f];
      const abs = sh.pts.map(p => p[0] === 'c' ? ['c', ...p.slice(1).map(at)] : at(p));
      const start = abs[0], segs = []; let cur = start;
      for (const p of abs.slice(1).concat([start])) {
        if (p[0] === 'c') { segs.push([p[1][0] - cur[0], p[1][1] - cur[1], p[2][0] - cur[0], p[2][1] - cur[1], p[3][0] - cur[0], p[3][1] - cur[1]]); cur = p[3]; }
        else { segs.push([p[0] - cur[0], p[1] - cur[1]]); cur = p; }
      }
      doc.lines(segs, start[0], start[1], [1, 1], 'S', false);
      if (sh.notch !== null) {   // a tick across the middle of the left side
        const a = abs[sh.notch], b = abs[0], m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
        doc.line(m[0] - 4, m[1], m[0] + 8, m[1]);
      }
    }
  });
  return Buffer.from(doc.output('arraybuffer'));
}

module.exports = { pdf, SIZES };
