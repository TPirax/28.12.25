// Pattern intake: reading a multi-size pattern PDF, finding sizes and pieces, and the admin flow to a published model.
'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs'), os = require('os'), path = require('path');
const { readPdf } = require('../lib/intake/pdf');
const { analyse } = require('../lib/intake/auto');
const { traceWithRetries } = require('../lib/intake/run');
const IM = require('../lib/intake/model');
const models = require('../lib/models');
const { engine } = require('../lib/render');
const fixture = require('./fixtures/intake-pdf');
const { createApp } = require('../server');
const { signTicket } = require('../lib/ticket');

test('the analysis finds the ruler, which colour is which size, and the pieces; the trace follows every size', async () => {
  const pages = await readPdf(fixture.pdf());
  const a = analyse(pages);
  assert.deepStrictEqual(a.problems, []);
  assert.strictEqual(a.report.ruler, 10);
  assert.ok(Math.abs(a.cfg.scale - 1) < 0.01, 'the 10 cm ruler gives 1:1');
  assert.deepStrictEqual(a.cfg.sizes, ['S', 'M', 'L']);
  fixture.SIZES.forEach(([s, rgb]) => assert.ok(a.cfg.colors[s].every((v, i) => Math.abs(v - rgb[i] / 255) < 0.01), s + ' colour'));
  assert.strictEqual(a.cfg.pieces.length, 2);
  const { data, failed } = traceWithRetries(pages, a.cfg);
  assert.deepStrictEqual(failed, []);
  const bodice = data.pieces.find(p => p.key === 'p1');
  assert.strictEqual(bodice.notches.length, 1, 'the tick across the side is a notch');
  const width = P => Math.max(...P.map(p => p[0])) - Math.min(...P.map(p => p[0]));
  assert.ok(width(bodice.outline[0]) < width(bodice.outline[1]) && width(bodice.outline[1]) < width(bodice.outline[2]), 'sizes nest from small to large');
  assert.ok(Math.abs(width(bodice.outline[1]) - 260 * 1.06 * 25.4 / 72) < 2, 'outline in mm at full size');
});

test('a file without size names is turned away with a reason', async () => {
  const { jsPDF } = require('jspdf');
  const doc = new jsPDF({ unit: 'pt', format: [600, 600] }); doc.line(10, 10, 300, 300);
  const a = analyse(await readPdf(Buffer.from(doc.output('arraybuffer'))));
  assert.strictEqual(a.cfg, null);
  assert.match(a.problems[0], /שמות מידות/);
});

test('settings and trace become a model that grades by the chart', async () => {
  const pages = await readPdf(fixture.pdf()), a = analyse(pages), s = IM.initialSettings(a, 'A0-LUNA.pdf');
  assert.strictEqual(s.key, 'luna'); assert.strictEqual(s.name, 'LUNA');
  const { data, failed } = traceWithRetries(pages, IM.traceConfig(a, s));
  s.key = 'luna-test'; s.pieces.p1.zone = 'span'; s.pieces.p2.zone = 'const-B';
  const rec = { id: 901, analysis: a, settings: s, data, failed };
  assert.ok(IM.publishProblems(rec, []).some(p => /לוח המידות/.test(p)), 'the chart must be confirmed');
  s.chart_checked = true;
  assert.deepStrictEqual(IM.publishProblems(rec, []), []);
  assert.ok(IM.publishProblems(rec, ['luna-test']).length, 'a taken key is refused');
  IM.setIntakeModels([{ id: 901, settings: s, data }]);
  try {
    const M = models.MODELS['luna-test'];
    assert.deepStrictEqual(M.body, { B: 'bust', W: 'waist' }, 'span + bust-only pieces need bust and waist');
    const build = bust => engine.build(M.mode, models.params('luna-test', { bust, waist: bust - 20 }, {}));
    assert.strictEqual(build(90).pieces, 2);
    // total width of the cut outlines on the sheet
    const w = bust => build(bust).prims.filter(p => p.t === 'poly' && p.s === 'cut').reduce((t, p) => t + Math.max(...p.pts.map(q => q[0])) - Math.min(...p.pts.map(q => q[0])), 0);
    assert.ok(w(80) < w(100), 'a larger bust gives a larger piece');
  } finally { IM.setIntakeModels([]); }
  assert.strictEqual(models.MODELS['luna-test'], undefined, 'unpublishing removes the model');
});

test('admin flow: upload, review, publish hidden, instructions for the customer', async () => {
  const SECRET = 'b'.repeat(64), PASSWORD = 'admin-password-for-tests-1234', UA = 'test-agent';
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'gzintake-'));
  const app = createApp({ secret: SECRET, adminPassword: PASSWORD, dbFile: path.join(dir, 'db.sqlite'), sessionTtl: 3600, secureCookies: false });
  const server = await new Promise(r => { const s = app.listen(0, () => r(s)); });
  const base = 'http://127.0.0.1:' + server.address().port;
  try {
    const hdr = (c, extra) => Object.assign({ cookie: c, 'user-agent': UA, 'sec-fetch-site': 'same-origin' }, extra || {});
    const login = await fetch(base + '/admin/login', { method: 'POST', redirect: 'manual', headers: hdr('', { 'Content-Type': 'application/x-www-form-urlencoded' }), body: 'password=' + PASSWORD });
    const admin = login.headers.get('set-cookie').split(';')[0];
    const get = url => fetch(base + url, { redirect: 'manual', headers: hdr(admin) });
    const page = await (await get('/admin/intake')).text();
    const csrf = page.match(/data-csrf="([^"]+)"/)[1];
    const raw = (url, body, extra) => fetch(base + url, { method: 'POST', headers: hdr(admin, Object.assign({ 'x-csrf': csrf, 'Content-Type': 'application/octet-stream' }, extra)), body });

    assert.strictEqual((await raw('/admin/intake', fixture.pdf(), { 'x-csrf': 'nope' })).status, 403);
    assert.strictEqual((await raw('/admin/intake', Buffer.from('not a pdf at all, just text that is long enough to pass the size check of the upload'))).status, 400);
    const up = await (await raw('/admin/intake', fixture.pdf(), { 'x-file-name': encodeURIComponent('A0-NOVA.pdf') })).json();
    assert.ok(up.ok && up.id, JSON.stringify(up));
    assert.strictEqual((await raw(`/admin/intake/${up.id}/info`, fs.readFileSync(path.join(__dirname, '..', 'instructions', 'kaliya-dress.pdf')))).status, 200);

    const review = await (await get('/admin/intake/' + up.id)).text();
    assert.strictEqual((review.match(/class="in-svg"/g) || []).length, 2, 'both pieces drawn');
    assert.match(review, /סמנו שלוח המידות/);
    const form = { csrf: review.match(/name="csrf" value="([^"]+)"/)[1], name: 'שמלה NOVA', key: 'nova-dress', cat: 'women/dresses', picture: 'dress', seam_cm: '1', unit: 'in', lead: '', note: '' };
    ['B', 'W', 'H'].forEach((m, j) => [0, 1, 2].forEach(i => { form[`${m}_${i}`] = String(33 + 2 * i - 4 * j); }));
    for (const k of ['p1', 'p2']) Object.assign(form, { ['use_' + k]: 'on', ['name_' + k]: k === 'p1' ? 'קדמי' : 'שרוול', ['cut_' + k]: 'גזרו 2', ['zone_' + k]: k === 'p1' ? 'span' : 'const-B', ['fold_' + k]: '', ['grain_' + k]: 'v', ['notch_' + k]: '', ['lining_' + k]: '' });
    const send = extra => fetch(base + '/admin/intake/' + up.id, { method: 'POST', redirect: 'manual', headers: hdr(admin, { 'Content-Type': 'application/x-www-form-urlencoded' }), body: new URLSearchParams(Object.assign({}, form, extra)) });
    assert.match((await send({ action: 'publish' })).headers.get('location'), /m=blocked/, 'not without confirming the chart');
    assert.match((await send({ action: 'publish', chart_checked: 'on' })).headers.get('location'), /m=published/);

    const manifest = await (await fetch(base + '/models.json')).json();
    assert.ok(!manifest.models.some(m => m.key === 'nova-dress'), 'hidden from customers until shown in the catalogue');
    assert.match(await (await get('/admin')).text(), /שמלה NOVA[\s\S]*?מוסתר/, 'in the studio for testing');

    // a customer session for the model: preview, PDF and the uploaded instructions
    const now = Math.floor(Date.now() / 1000);
    const t = signTicket({ v: 1, iss: 'https://shop.test/', iat: now, exp: now + 600, jti: 'in' + Math.random(), usage_id: 3, model: 'nova-dress', customer: { id: 4, name: 'נועה', email: 'n@example.com' },
      profile: { id: 1, label: 'שלי' }, measurements: { bust: 90, waist: 70, hips: 98 }, watermark: 'נועה', return_url: 'https://shop.test/' }, SECRET);
    const g = await fetch(base + '/generate', { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'ticket=' + encodeURIComponent(t) });
    const loc = g.headers.get('location'), cookie = g.headers.get('set-cookie').split(';')[0];
    assert.match(await (await fetch(base + loc, { headers: { cookie } })).text(), /שמלה NOVA/);
    const ins = await fetch(base + loc + '/instructions', { headers: { cookie } });
    assert.strictEqual(ins.status, 200); assert.strictEqual(ins.headers.get('content-type'), 'application/pdf');

    // a published intake keeps its key and cannot be deleted; after unpublishing it can
    assert.match((await send({ action: 'delete' })).headers.get('location'), new RegExp(`/admin/intake/${up.id}`));
    await send({ action: 'unpublish' });
    assert.strictEqual(models.MODELS['nova-dress'], undefined);
    assert.strictEqual((await send({ action: 'delete' })).headers.get('location'), '/admin/intake');
  } finally { server.close(); app.close && app.close(); }
});
