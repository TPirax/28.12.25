// Fabric calculator box: fetched after each successful preview, latest request wins.
// Under the table, the cutting layout for the chosen fabric and width, as the calculator packed it.
(function () {
  var box = document.getElementById('fabric'), seq = 0; if (!box) return;
  var body = box.querySelector('tbody'), lay = document.getElementById('fabric-lay'), data = null, pick = { f: 0, w: 140 };
  var NS = 'http://www.w3.org/2000/svg';
  function el(tag, attrs, text) { var e = document.createElementNS(NS, tag); for (var k in attrs) e.setAttribute(k, attrs[k]); if (text != null) e.textContent = text; return e; }
  function cell(v, fi, w) {
    var td = document.createElement('td');
    if (v == null) { td.textContent = 'לא מתאים'; td.className = 'na'; td.title = 'יש חלק רחב מהבד. צריך בד רחב יותר או תפר נוסף.'; return td; }
    var b = document.createElement('button'); b.type = 'button'; b.className = 'lay-pick'; b.textContent = v.toFixed(1) + ' מ׳';
    b.title = 'הצגת סידור החלקים על הבד'; b.dataset.f = fi; b.dataset.w = w; td.appendChild(b); return td;
  }
  // one strip of fabric: length runs left to right, the fold (or a selvedge) along the top
  function section(s) {
    var W = s.w, L = Math.max(s.len, 300), pad = 40, svg = el('svg', { viewBox: (-pad) + ' ' + (-pad) + ' ' + (L + 2 * pad) + ' ' + (W + 2 * pad + 70), role: 'img' });
    svg.style.width = Math.max(300, Math.round((L + 2 * pad) * 0.25)) + 'px';
    svg.appendChild(el('rect', { x: 0, y: 0, width: L, height: W, 'class': 'lay-cloth' }));
    svg.appendChild(el('line', { x1: 0, y1: 0, x2: L, y2: 0, 'class': s.kind === 'fold' ? 'lay-fold' : 'lay-edge' }));
    for (var m = 0; m <= L; m += 100) {
      svg.appendChild(el('line', { x1: m, y1: W, x2: m, y2: W + (m % 1000 ? 12 : 26), 'class': 'lay-tick' }));
      if (m && m % 1000 === 0) svg.appendChild(el('text', { x: m, y: W + 90, 'class': 'lay-m' }, (m / 1000) + ' מ׳'));
    }
    s.pieces.forEach(function (p) {
      var g = el('g', { transform: 'matrix(0 1 1 0 ' + p.y + ' ' + p.x + ')' });
      g.appendChild(el('path', { d: p.d, 'class': 'lay-piece' + (p.fold ? ' is-fold' : '') }));
      svg.appendChild(g);
      var fs = Math.max(48, Math.min(90, Math.min(p.w, p.h) / 2.5));
      svg.appendChild(el('text', { x: p.y + p.h / 2, y: p.x + p.w / 2 + fs / 3, 'class': 'lay-no', 'font-size': fs }, String(p.no)));
    });
    var wrap = document.createElement('div'); wrap.className = 'lay-scroll'; wrap.appendChild(svg);
    var cap = document.createElement('p'); cap.className = 'lay-cap';
    cap.textContent = s.kind === 'fold' ? 'בד מקופל לאורך, שפה אל שפה: הקו המקווקו הוא הקיפול. כל חלק נגזר בשתי השכבות יחד.' : 'בד פתוח בשכבה אחת, לחלקים רחבים מהבד המקופל.';
    var frag = document.createDocumentFragment(); frag.appendChild(cap); frag.appendChild(wrap); return frag;
  }
  function draw() {
    if (!lay) return;
    var f = data && data.fabrics[pick.f], L = f && f.layouts && f.layouts[pick.w];
    lay.innerHTML = ''; lay.hidden = !L; if (!L) return;
    [].forEach.call(body.querySelectorAll('.lay-pick'), function (b) { b.setAttribute('aria-pressed', String(Number(b.dataset.f) === pick.f && Number(b.dataset.w) === pick.w)); });
    var h = document.createElement('h3'); h.textContent = 'סידור על הבד: ' + f.label + ', רוחב ' + pick.w + ' ס״מ'; lay.appendChild(h);
    L.sections.forEach(function (s) { lay.appendChild(section(s)); });
    var ul = document.createElement('ul'); ul.className = 'lay-legend';
    f.legend.forEach(function (x) { var li = document.createElement('li'); var b = document.createElement('b'); b.textContent = x[0]; li.appendChild(b); li.appendChild(document.createTextNode(' ' + x[1])); ul.appendChild(li); });
    lay.appendChild(ul);
    var note = document.createElement('small'); note.textContent = 'הסידור הוא הצעה שמראה שהחלקים נכנסים באורך הזה. חלקים מסומנים בכהה נגזרים על הקיפול. בד עם כיוון (הדפס, קטיפה) – כל החלקים באותו כיוון.';
    lay.appendChild(note);
  }
  body.addEventListener('click', function (e) {
    var b = e.target.closest('.lay-pick'); if (!b) return;
    pick = { f: Number(b.dataset.f), w: Number(b.dataset.w) }; draw();
  });
  window.gzFabric = function (url, payload) {
    var my = ++seq;
    if (!url) { box.hidden = true; return; }
    fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', body: JSON.stringify(payload) })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (d) {
        if (my !== seq) return;
        if (!d || !d.fabrics || !d.fabrics.length) { box.hidden = true; return; }
        data = d; body.innerHTML = '';
        var widths = d.widths || [110, 140, 150];
        d.fabrics.forEach(function (f, fi) {
          var tr = document.createElement('tr'), th = document.createElement('th'); th.scope = 'row'; th.textContent = f.label; tr.appendChild(th);
          widths.forEach(function (w) { tr.appendChild(cell(f.byWidth[w], fi, w)); });
          body.appendChild(tr);
        });
        // keep the choice across previews while it still exists
        if (!d.fabrics[pick.f] || !d.fabrics[pick.f].layouts || !d.fabrics[pick.f].layouts[pick.w]) pick = { f: 0, w: widths.indexOf(140) >= 0 ? 140 : widths[0] };
        box.hidden = false; draw();
      }).catch(function () { if (my === seq) box.hidden = true; });
  };
})();
