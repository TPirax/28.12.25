// Admin studio: catalogue model or photo pattern, showing only the measurements the pattern needs.
'use strict';
(() => {
  const form = document.getElementById('studio'), picker = document.getElementById('model-picker'); if (!form || !picker) return;
  const radios = [...picker.querySelectorAll('input[name=model]')];
  const all = document.getElementById('all'), count = document.getElementById('need-count');
  const photoModel = document.getElementById('photo-model'), submit = document.getElementById('studio-submit'), msg = document.getElementById('studio-msg');
  const file = document.getElementById('photo-file'), preview = document.getElementById('photo-preview'), hint = document.getElementById('photo-hint');
  let mode = 'catalog';
  document.getElementById('all-wrap').hidden = false;
  const say = text => { msg.textContent = text || ''; msg.hidden = !text; };

  const update = () => {
    const src = mode === 'photo' ? photoModel : (radios.find(r => r.checked) || radios[0]);
    const list = name => (src.dataset[name] || '').split(' ').filter(Boolean);
    const need = list('fields'), optional = list('optional');
    for (const f of document.querySelectorAll('.af')) {
      const req = need.includes(f.dataset.f), opt = optional.includes(f.dataset.f);
      f.querySelector('input').required = req;
      f.classList.toggle('opt', opt);
      f.hidden = !req && !opt && !all.checked;
    }
    for (const g of document.querySelectorAll('.admin-group')) g.hidden = !g.querySelector('.af:not([hidden])');
    count.textContent = need.length ? `(${need.length} מידות נדרשות${optional.length ? `, ${optional.length} רשות` : ''})` : '(הדגם הזה לפי מידה, בלי מידות גוף)';
  };

  const setMode = m => {
    mode = m;
    for (const b of document.querySelectorAll('.admin-mode')) { const on = b.dataset.mode === m; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); }
    for (const el of document.querySelectorAll('.catalog-only')) el.hidden = m !== 'catalog';
    for (const el of document.querySelectorAll('.photo-only')) el.hidden = m !== 'photo';
    for (const r of radios) r.disabled = m === 'photo';
    photoModel.disabled = m !== 'photo';
    if (file) file.required = m === 'photo';
    submit.textContent = submit.dataset[m];
    submit.disabled = m === 'photo' && !!submit.dataset.photoOff;
    say(''); update();
  };

  if (photoModel) {
    document.getElementById('modes').hidden = false;
    for (const b of document.querySelectorAll('.admin-mode')) b.addEventListener('click', () => setMode(b.dataset.mode));
  }
  if (file) file.addEventListener('change', () => {
    const f = file.files[0]; if (!f) return;
    preview.src = URL.createObjectURL(f); preview.hidden = false; hint.hidden = true; say('');
  });

  // Same downscale as the customer upload page: longest side 1600px, JPEG.
  const encode = f => new Promise((resolve, reject) => {
    const im = new Image();
    im.onload = () => {
      const s = Math.min(1, 1600 / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement('canvas');
      c.width = Math.round(im.naturalWidth * s); c.height = Math.round(im.naturalHeight * s);
      const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(im, 0, 0, c.width, c.height);
      resolve(c.toDataURL('image/jpeg', 0.88).split(',')[1]);
    };
    im.onerror = () => reject(new Error('הדפדפן לא הצליח לקרוא את הקובץ. נסו JPG או PNG.'));
    im.src = URL.createObjectURL(f);
  });

  form.addEventListener('submit', async e => {
    if (mode !== 'photo') return;
    e.preventDefault();
    submit.disabled = true; say('מנתח את התמונה. זה לוקח עד דקה…');
    try {
      const image = await encode(file.files[0]);
      // Open an admin test session for the photo pattern, then hand it the image.
      const s = await fetch(form.action, { method: 'POST', credentials: 'same-origin', body: new URLSearchParams(new FormData(form)) });
      if (!s.ok || !/\/s\/[^/]+$/.test(new URL(s.url).pathname)) throw new Error('לא הצלחנו לפתוח את הגזרה. בדקו את המידות ונסו שוב.');
      const r = await fetch(s.url + '/photo', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ image, note: document.getElementById('photo-note').value }) });
      const d = await r.json().catch(() => ({}));
      if (!d.url) throw new Error(d.error || 'ניתוח התמונה נכשל. נסו שוב.');
      location.href = new URL(d.url, s.url).href;
    } catch (err) { say(err.message || 'ניתוח התמונה נכשל. נסו שוב.'); submit.disabled = false; }
  });

  picker.addEventListener('change', update);
  all.addEventListener('change', update);
  update();
})();

// Backup page: restore uploads the file as-is; the server keeps a copy of the current data first.
(() => {
  const form = document.getElementById('restore-form'); if (!form) return;
  const file = document.getElementById('restore-file'), msg = document.getElementById('restore-msg'), btn = form.querySelector('button');
  const say = (text, ok) => { msg.textContent = text; msg.hidden = !text; msg.classList.toggle('ok', !!ok); };
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const f = file.files[0]; if (!f) return;
    if (!confirm('השחזור יחליף את כל הנתונים הנוכחיים בנתונים מהקובץ. להמשיך?')) return;
    btn.disabled = true; say('משחזר…');
    try {
      const r = await fetch('/admin/backup/restore', { method: 'POST', credentials: 'same-origin', headers: { 'x-csrf': form.dataset.csrf, 'Content-Type': 'application/octet-stream' }, body: f });
      const d = await r.json().catch(() => ({}));
      if (d.ok) { say('הנתונים שוחזרו בהצלחה.', true); setTimeout(() => location.reload(), 1200); }
      else { say(d.error || 'השחזור נכשל.'); btn.disabled = false; }
    } catch (err) { say('השחזור נכשל. נסו שוב.'); btn.disabled = false; }
  });
})();


// New pattern from a file: the PDF goes up as-is, then the instructions PDF if one was chosen.
(() => {
  const up = (url, csrf, f, extra) => fetch(url, { method: 'POST', credentials: 'same-origin', headers: Object.assign({ 'x-csrf': csrf, 'Content-Type': 'application/octet-stream' }, extra || {}), body: f })
    .then(r => r.json().catch(() => ({ error: 'השרת לא ענה כמצופה.' })));
  const wire = (form, run) => {
    if (!form) return;
    const msg = form.querySelector('#intake-msg'), btn = form.querySelector('button[type=submit]');
    const say = (text, ok) => { msg.textContent = text; msg.hidden = !text; msg.classList.toggle('ok', !!ok); };
    form.addEventListener('submit', async e => {
      e.preventDefault(); btn.disabled = true;
      try { await run(form, say); } catch { say('ההעלאה נכשלה. נסו שוב.'); }
      btn.disabled = false;
    });
  };
  wire(document.getElementById('intake-form'), async (form, say) => {
    const pdf = document.getElementById('intake-pdf').files[0], info = document.getElementById('intake-info').files[0];
    if (!pdf) return;
    say('מעלה ומנתח את הקובץ… זה לוקח עד דקה.', true);
    const d = await up('/admin/intake', form.dataset.csrf, pdf, { 'x-file-name': encodeURIComponent(pdf.name) });
    if (!d.ok) return say(d.error || 'הניתוח נכשל.');
    if (info) { say('מעלה את קובץ ההוראות…', true); const i = await up(`/admin/intake/${d.id}/info`, form.dataset.csrf, info); if (!i.ok) alert(i.error || 'קובץ ההוראות לא הועלה. אפשר להעלות אותו שוב בדף הגזרה.'); }
    location.href = '/admin/intake/' + d.id;
  });
  wire(document.getElementById('intake-info-form'), async (form, say) => {
    const f = document.getElementById('intake-info').files[0]; if (!f) return;
    say('מעלה…', true);
    const d = await up(`/admin/intake/${form.dataset.id}/info`, form.dataset.csrf, f);
    if (!d.ok) return say(d.error || 'ההעלאה נכשלה.');
    location.reload();
  });
  document.addEventListener('click', e => { const b = e.target.closest('button[data-confirm]'); if (b && !confirm(b.dataset.confirm)) e.preventDefault(); });
})();
