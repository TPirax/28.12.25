# Draws the catalogue pictures in public/models/<key>.svg as fashion flats: front and back view side by side,
# fine outline, seams, topstitching and a soft fabric shade. Run: python3 tools/draw-models.py public/models
#
# A garment is drawn on a centre line x = 50 with long fashion proportions: neck 0, bust 22, waist 38, hip 52,
# knee 88, floor 128. Outlines are given as their right half [(dx, y[, corner])] from the top centre to the
# bottom centre and mirrored; points are joined by smooth curves except at corners (third value 0).
import pathlib, sys

out = pathlib.Path(sys.argv[1])

def hx(c): c = c.lstrip('#'); return tuple(int(c[i:i + 2], 16) / 255 for i in (0, 2, 4))
def mix(c, t):  # t > 0 towards white, t < 0 towards black
    r, g, b = hx(c); f = (lambda v: v + (1 - v) * t) if t > 0 else (lambda v: v * (1 + t))
    return '#%02x%02x%02x' % tuple(round(max(0, min(1, f(v))) * 255) for v in (r, g, b))

INK, SEAM = '#222B32', '#626D73'

def curve(pts, closed):
    """Catmull-Rom through the points as cubic Beziers; a corner point gets no tangent."""
    P = [(p[0], p[1], p[2] if len(p) > 2 else 1) for p in pts]
    n = len(P)
    if n < 2: return ''
    at = lambda i: P[i % n] if closed else P[max(0, min(n - 1, i))]
    d = f'M{P[0][0]:.2f} {P[0][1]:.2f}'
    for i in range(n if closed else n - 1):
        a, b, p0, p3 = at(i - 1), at(i + 2), at(i), at(i + 1)
        c1 = (p0[0] + (p3[0] - a[0]) / 6, p0[1] + (p3[1] - a[1]) / 6) if p0[2] else p0
        c2 = (p3[0] - (b[0] - p0[0]) / 6, p3[1] - (b[1] - p0[1]) / 6) if p3[2] else p3
        d += f' C{c1[0]:.2f} {c1[1]:.2f} {c2[0]:.2f} {c2[1]:.2f} {p3[0]:.2f} {p3[1]:.2f}'
    return d + (' Z' if closed else '')

def R(pts): return [(50 + p[0], p[1]) + tuple(p[2:]) for p in pts]
def L(pts): return [(50 - p[0], p[1]) + tuple(p[2:]) for p in pts]

class View:
    """One view of a garment: filled shapes, then lines on top."""
    def __init__(self): self.items, self.pts = [], []
    def _keep(self, pts): self.pts += [(p[0], p[1]) for p in pts]
    def body(self, right, fill='f1'):
        """A symmetric shape from its right half (top centre -> bottom centre)."""
        right = list(right)
        full = R(right) + L(right[::-1])[1:-1] if right[0][0] == 0 and right[-1][0] == 0 else R(right) + L(right[::-1])
        self._keep(full); self.items.append(('fill', curve(full, True), fill))
    def shape(self, pts, fill='f1', mirror=False):
        """A free shape in dx coordinates; mirror=True draws it on both sides."""
        for side in ([R, L] if mirror else [R]):
            q = side(pts); self._keep(q); self.items.append(('fill', curve(q, True), fill))
    def line(self, pts, kind='seam', mirror=True):
        for side in ([R, L] if mirror else [R]):
            q = side(pts); self.items.append(('line', curve(q, False), kind))
    def dots(self, pts, r=.55, fill='#F7F1E3', mirror=True):
        for side in ([R, L] if mirror else [R]):
            for x, y in side(pts): self.items.append(('dot', (x, y, r), fill))

STYLE = {'seam': f'stroke="{SEAM}" stroke-width=".3"', 'stitch': f'stroke="{SEAM}" stroke-width=".22" stroke-dasharray=".9 .7"',
  'fold': 'stroke="#000" stroke-opacity=".22" stroke-width=".25"', 'edge': f'stroke="{INK}" stroke-width=".45"',
  'gold': 'stroke="#B08A3E" stroke-width=".5"', 'lace': f'stroke="{SEAM}" stroke-width=".22"', 'zip': f'stroke="{SEAM}" stroke-width=".32"',
  'cord': f'stroke="{SEAM}" stroke-width=".3"'}

def render(views, c1, c2=None, lace=False):
    """Front and back side by side, scaled together to fit the card (100 x 140)."""
    # Editorial technical-fashion flats: neutral fabrics, no faux-shiny gradients.
    # Retain dark pieces as dark so critical garment construction stays legible.
    r, g, b = hx(c1)
    dark_fabric = .2126*r + .7152*g + .0722*b < .36
    c1 = '#343C44' if dark_fabric else '#EEECE7'
    c2 = '#48515A' if dark_fabric else '#E2E2DF'
    xs = [p[0] for v in views for p in v.pts]; ys = [p[1] for v in views for p in v.pts]
    half = max(max(xs) - 50, 50 - min(xs)); top, bottom = min(ys), max(ys)
    k = min(23.5 / half, 128 / (bottom - top), 1.45)   # short garments stay in proportion
    grad = lambda gid, c: f'<linearGradient id="{gid}"><stop offset="0" stop-color="{c}"/><stop offset="1" stop-color="{c}"/></linearGradient>'
    body = ''
    for cx, v in zip((26, 74), views):
        g = ''
        for kind, d, st in v.items:
            if kind == 'fill':
                fill = {'f1': 'url(#f1)', 'f2': 'url(#f2)', 'in': mix(c1, -.1), 'skin': '#E7E1D8', 'dark': '#2E2E33', 'white': '#FAF8F4', 'gold': '#A79C86'}.get(st, st)
                g += f'<path d="{d}" fill="{fill}" stroke="{INK}" stroke-width=".42" stroke-linejoin="round"/>'
                if lace and st == 'f1': g += f'<path d="{d}" fill="url(#lace)" stroke="none"/>'
            elif kind == 'line':
                g += f'<path d="{d}" fill="none" {STYLE[st]} stroke-linecap="round"/>'
            else:
                x, y, r = d; g += f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{r}" fill="{st}" stroke="#A8925F" stroke-width=".15"/>'
        body += f'<g transform="translate({cx} {70 - (top + bottom) / 2 * k:.2f}) scale({k:.3f}) translate(-50 0)">{g}</g>'
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 140" role="img">
<defs>{grad('f1', c1)}{grad('f2', c2)}
<pattern id="lace" width="3" height="3" patternUnits="userSpaceOnUse"><g fill="none" stroke="#989E9C" stroke-width=".10" opacity=".30"><circle cx="1.5" cy="1.5" r=".55"/><path d="M0 0 Q1.5 .8 3 0 M0 3 Q1.5 2.2 3 3"/></g></pattern>
</defs>
{body}
</svg>
'''

# ---------- shared pieces
def bell_sleeve(v, side_pts=None):
    """A long bell sleeve hanging from the shoulder (right side, mirrored)."""
    v.shape([(9.4, 5, 0), (11.6, 9), (13.6, 30), (16, 46), (19.5, 58, 0), (13.4, 60, 0), (11.2, 44), (9.8, 26), (8.6, 17, 0)], 'f1', mirror=True)
    v.line([(12.2, 34), (15.8, 58)], 'fold'); v.line([(13.8, 44), (17.8, 58.6)], 'fold')
def long_sleeve(v, cuff=True):
    v.shape([(9.4, 5, 0), (11.4, 9), (12.6, 28), (13.4, 52, 0), (10.6, 53, 0), (10.4, 30), (8.8, 17, 0)], 'f1', mirror=True)
    if cuff: v.line([(13.2, 49.5), (10.5, 50.2)], 'stitch')

M = {}

# KIM: fitted sleeveless maxi; halter collar band with a button, two straps to an open back, CB zip
f, b = View(), View()
for v in (f, b): v.shape([(-4.4, -3.5, 0), (4.4, -3.5, 0), (4.6, 1.5, 0), (-4.6, 1.5, 0)], 'f1')
f.body([(0, 3.2), (3.9, 1.6, 0), (7.6, 14), (8.6, 22), (6.6, 38), (9.2, 52), (8.4, 86), (8.9, 128, 0), (0, 128.6, 0)])
f.line([(3.6, 24), (4, 35), (4.4, 24)], 'seam'); f.line([(3.8, 40), (4.2, 52), (4.6, 40)], 'seam')
f.line([(5.5, 60), (5.2, 100), (5.8, 127)], 'fold'); f.dots([(0, -1)], .5, '#E8E1D2', mirror=False)
b.body([(0, 32, 0), (5.2, 27), (8.6, 23, 0), (6.6, 38), (9.2, 52), (8.4, 86), (8.9, 128, 0), (0, 128.6, 0)])
b.shape([(3.3, 1.5, 0), (4.6, 1.5, 0), (8.4, 23.4, 0), (7.1, 24, 0)], 'f1', mirror=True)
b.line([(0, 32), (0, 64)], 'zip', mirror=False); b.line([(3.6, 40), (4, 54), (4.4, 40)], 'seam')
b.line([(0, 64), (0, 128)], 'seam', mirror=False)
M['kim-dress'] = render([f, b], '#2F7A63')

# ALIX: boned lace bridal mini, sweetheart, princess seams, scalloped hem; CB zip
def alix(v, front):
    hem = [(9.8, 62, 0)] + [(9.8 - i * 1.4, 62.6 + (i % 2) * .9, 0) for i in range(1, 7)] + [(0, 63, 0)]
    top = [(0, 19.5, 0), (2.4, 16), (4.6, 15.2), (7, 16.4), (8.8, 18.4, 0)] if front else [(0, 19, 0), (8.8, 18.6, 0)]
    v.body(top + [(8.6, 22), (6.7, 38), (9.3, 52)] + hem)
    v.line([(4.6, 15.4 if front else 18.8), (4.2, 26), (4.1, 38), (5, 52), (5.6, 62)], 'seam')
    v.line([(7.4, 17.4 if front else 18.7), (6.6, 28), (5.9, 38), (7.6, 52), (8.2, 62)], 'seam')
    if front: v.line([(0, 19.5), (0, 62.8)], 'seam', mirror=False)
    else: v.line([(0, 19), (0, 44)], 'zip', mirror=False); v.line([(0, 44), (0, 63)], 'seam', mirror=False)
f, b = View(), View(); alix(f, True); alix(b, False)
M['alix-dress'] = render([f, b], '#F3EDE1', lace=True)

# POLLA: flared midi skirt on an elastic waistband
def polla(v, front):
    v.shape([(-7, 31, 0), (7, 31, 0), (7, 37, 0), (-7, 37, 0)], 'f2')
    for x in range(-6, 7): v.line([(x, 31.6), (x + .15, 36.4)], 'fold', mirror=False)
    v.body([(0, 37, 0), (7.2, 37, 0), (10.4, 56), (16.2, 100, 0), (8, 101.2), (0, 101.6, 0)])
    v.line([(15.2, 98.4), (8, 99.6), (0, 100)], 'stitch')
    for x0, x1 in ((2.2, 4.2), (4.8, 9.6), (6.4, 13.6)): v.line([(x0, 39), (x1, 100)], 'fold')
    if not front: v.line([(0, 37), (0, 101.6)], 'seam', mirror=False)
f, b = View(), View(); polla(f, True); polla(b, False)
M['polla-skirt'] = render([f, b], '#C98C92')

# PAYPAY: corset over the hip with contrast cups and a gold front busk; laced back
f, b = View(), View()
f.body([(0, 21.5, 0), (8.4, 22, 0), (6.6, 38), (8.9, 50), (8.2, 56.5, 0), (0, 58, 0)])
f.shape([(0, 21.5, 0), (.6, 18), (2.4, 15.2), (4.6, 14.6), (7, 15.8), (8.6, 18.4, 0), (8.4, 22, 0), (6, 25), (3, 25.4), (0, 23, 0)], 'f2', mirror=True)
f.line([(4.6, 14.8), (4.4, 25)], 'seam'); f.line([(4.3, 25.2), (4, 38), (4.8, 57.4)], 'seam'); f.line([(7.2, 23.8), (6, 38), (7.3, 56.6)], 'seam')
f.line([(0, 23), (0, 58)], 'gold', mirror=False)
for y in range(26, 57, 4): f.line([(-.8, y), (.8, y)], 'gold', mirror=False)
b.body([(0, 19.5, 0), (8.6, 19, 0), (8.4, 22), (6.6, 38), (8.9, 50), (8.2, 56.5, 0), (0, 56.6, 0)])
b.line([(4.2, 19.3), (4, 38), (4.8, 56.6)], 'seam'); b.line([(7.2, 19.2), (6, 38), (7.3, 56.6)], 'seam')
b.line([(1.1, 19.4), (1.1, 56.6)], 'stitch'); b.dots([(1.1, y) for y in range(21, 56, 3)], .32, '#D8D8D8')
b.line([(-1.1, 21), (1.1, 24), (-1.1, 27), (1.1, 30), (-1.1, 33), (1.1, 36), (-1.1, 39), (1.1, 42), (-1.1, 45), (1.1, 48), (-1.1, 51), (1.1, 54)], 'cord', mirror=False)
M['paypay-corset'] = render([f, b], '#3A3840', '#E7D2B5')

# MARINA: strapless lace band, mesh waist with a front V, mermaid skirt in princess panels
def marina(v, front):
    v.body([(0, 18, 0), (8.6, 18, 0), (8.6, 22), (6.6, 38), (9.2, 52), (7.6, 82), (8.4, 92), (13, 112), (19, 128, 0), (0, 129.4, 0)])
    v.shape([(0, 18, 0), (8.6, 18, 0), (8.6, 25.6, 0), (0, 25.6, 0)], '#E9E3F0', mirror=True)
    v.line([(0, 18.4), (8.4, 18.4)], 'lace'); [v.line([(x, 19), (x + .6, 25)], 'lace') for x in (1.5, 3.5, 5.5, 7.5)]
    if front: v.shape([(0, 25.6, 0), (8.6, 25.6, 0), (7.2, 34, 0)], 'f2', mirror=True); v.line([(8.6, 25.6), (0, 40)], 'seam')
    v.line([(4.4, 25.6), (4.2, 40), (5, 54), (4.3, 84), (6.4, 128.6)], 'seam'); v.line([(6.4, 98), (12.2, 128.4)], 'fold')
    if not front: v.line([(0, 18), (0, 50)], 'zip', mirror=False); v.line([(0, 50), (0, 129.4)], 'seam', mirror=False)
f, b = View(), View(); marina(f, True); marina(b, False)
M['lace-mermaid'] = render([f, b], '#2D426F', '#7C8AA8')

# PERLA: pearl halter with a deep V, bodice ending in a low V on the hips, short balloon front skirt and a long train
f, b = View(), View()
f.body([(0, 56, 0), (9.4, 50, 0), (15.6, 88), (19, 128, 0), (0, 129, 0)], 'in')
f.line([(11.6, 70), (15.4, 126)], 'fold')
f.body([(0, 57, 0), (9.4, 50, 0), (12.8, 60), (12.4, 69, 0), (6, 71.6), (0, 72.4, 0)], 'f2')
f.line([(2.6, 60), (3.2, 71.8)], 'fold'); f.line([(6.4, 58), (8.4, 70.6)], 'fold'); f.line([(12.2, 67.4), (0, 70.6)], 'stitch')
f.body([(0, 30, 0), (3.4, -1.5, 0), (4.6, -1.5, 0), (8.2, 16), (8.6, 22), (6.6, 38), (9.4, 50, 0), (0, 58, 0)])
f.line([(4.2, -1), (4.4, 22), (4.2, 38), (4.8, 53.6)], 'seam')
f.dots([(4.35, y) for y in range(3, 53, 4)] + [(.4 + i * .43, 30 - i * 4.1) for i in range(0, 8)])
b.body([(0, 52, 0), (9.4, 50, 0), (16.4, 88), (20, 128, 0), (0, 134, 0)], 'f2')
b.line([(11.8, 70), (16, 127)], 'fold'); b.line([(4, 60), (6, 132)], 'fold')
b.body([(0, 40, 0), (4.4, 28), (8.6, 22, 0), (6.6, 38), (9.4, 50, 0), (0, 52, 0)])
b.shape([(3.4, -1.5, 0), (4.6, -1.5, 0), (8.8, 22, 0), (7.6, 22.4, 0)], 'f1', mirror=True)
for y in (27, 32): b.dots([(i * .9 - 4.4 * 0, y + (i / 8) ** 2 * 2) for i in range(0, 9)], .45)
M['pearl-halter'] = render([f, b], '#E6D3B4', '#F1E7D6')

# CORALIE: strapless sweetheart in a contrast fabric, boned basque bodice to a point, mermaid skirt with train
def coralie(v, front):
    v.body([(0, 49, 0), (9.2, 46, 0), (7.4, 84), (11, 104), (19.5, 128, 0), (0, 133 if not front else 129.4, 0)])
    v.line([(4.4, 50), (4, 84), (6, 128.6)], 'seam'); v.line([(6.6, 92), (13.2, 128.4)], 'fold'); v.line([(3, 94), (3.4, 128.8)], 'fold')
    top = [(0, 20, 0), (2.4, 16), (4.7, 15.4), (7, 16.4), (8.7, 18.4, 0)] if front else [(0, 18.6, 0), (8.7, 18.4, 0)]
    v.body(top + [(8.6, 22), (6.6, 38), (9.2, 46, 0), (0, 49, 0)])
    if front:
        v.shape([(0, 20, 0), (2.4, 16), (4.7, 15.4), (7, 16.4), (8.7, 18.4, 0), (8.6, 22.4, 0), (5, 25.4), (1.4, 24.4), (0, 23, 0)], 'f2', mirror=True)
        v.line([(4.7, 15.6), (4.6, 25)], 'seam')
    else: v.line([(0, 18.6), (0, 47)], 'zip', mirror=False)
    v.line([(4.5, 25 if front else 18.6), (4.1, 38), (4.6, 47.8)], 'seam'); v.line([(7.2, 23), (6, 38), (7.2, 46.6)], 'seam')
f, b = View(), View(); coralie(f, True); coralie(b, False)
M['corset-mermaid'] = render([f, b], '#7C2A3E', '#E8B9B7')

# MIRA: sweetheart bustier in five panels a side, front hooks; laced back
def mira(v, front):
    top = [(0, 20, 0), (2.4, 16.2), (4.7, 15.4), (7, 16.4), (8.8, 18.4, 0)] if front else [(0, 18.6, 0), (8.8, 18.6, 0)]
    v.body(top + [(8.6, 22), (6.6, 38), (8.6, 50), (8.4, 53.6, 0), (0, 54.2, 0)])
    for p in ([(2.1, 16.6 if front else 18.6), (2, 38), (2.4, 54)], [(4.5, 15.6 if front else 18.6), (4.1, 38), (4.8, 54)], [(6.6, 16.4 if front else 18.6), (5.6, 38), (6.8, 53.9)]): v.line(p, 'seam')
    if front:
        v.line([(0, 20), (0, 54.2)], 'seam', mirror=False); v.dots([(.9, y) for y in range(23, 54, 4)], .38, '#C9A35A', mirror=False)
    else:
        v.line([(-1, 20), (1, 23), (-1, 26), (1, 29), (-1, 32), (1, 35), (-1, 38), (1, 41), (-1, 44), (1, 47), (-1, 50), (1, 53)], 'cord', mirror=False)
f, b = View(), View(); mira(f, True); mira(b, False)
M['corset-bustier'] = render([f, b], '#E1AFA6')

# KARDI: halter cups rising to the neck, boned princess bodice, long skirt with front pleats and a high slit; back zip
f, b = View(), View()
f.body([(0, 38, 0), (6.6, 38, 0), (9.2, 52), (8.4, 90), (9, 128, 0), (0, 128.6, 0)])
f.shape([(-3, 72, 0), (-1.2, 128.6, 0), (-5.4, 128.4, 0)], '#E9D7C6')
f.line([(-3, 72), (-1.2, 128.6)], 'seam', mirror=False); f.line([(-3, 72), (-5.4, 128.4)], 'seam', mirror=False)
for y in (41, 44.5, 48): f.line([(-6.4, y), (0, y + 3.4), (6.6, y + .8)], 'fold', mirror=False)
f.body([(0, 24, 0), (8.6, 22, 0), (6.6, 38, 0), (0, 38.4, 0)])
f.shape([(.4, 23.6, 0), (2.2, -1, 0), (3.2, -1, 0), (8.6, 22.2, 0), (4.4, 25)], 'f2', mirror=True)
f.line([(2.2, -1), (2.2, -1), (-2.2, -1)], 'seam', mirror=False)
f.line([(2.4, 25), (2.2, 38.2)], 'seam'); f.line([(5.6, 23.6), (4.8, 38.2)], 'seam'); f.line([(0, 38.4), (6.6, 38)], 'seam')
b.body([(0, 24, 0), (8.6, 22.4, 0), (6.6, 38), (9.2, 52), (8.4, 90), (9, 128, 0), (0, 128.6, 0)])
b.line([(0, 24), (0, 60)], 'zip', mirror=False); b.line([(0, 60), (0, 128.6)], 'seam', mirror=False)
b.line([(0, 38.4), (6.6, 38)], 'seam'); b.line([(3.2, 38.4), (3.6, 50), (4, 38.4)], 'seam'); b.line([(4.4, 24), (4, 38.2)], 'seam')
M['kardi-dress'] = render([f, b], '#B41F35', '#C3324A')

# KALIYA: knit mini, boat neck, bell sleeves; deep scoop back crossed by two ties
f, b = View(), View()
for v in (f, b): bell_sleeve(v)
f.body([(0, 2.2, 0), (3, 1.7), (5.8, .7, 0), (9.4, 5, 0), (8.8, 17), (8.4, 24), (6.6, 38), (9.6, 52), (14, 68, 0), (0, 69, 0)])
f.line([(0, 3.2), (3, 2.7), (5.6, 1.7)], 'stitch'); f.line([(13.4, 66.4), (0, 67.4)], 'stitch')
for x0, x1 in ((3, 4.2), (6, 9.4)): f.line([(x0, 52), (x1, 68.4)], 'fold')
b.body([(0, 36, 0), (4.6, 30), (5.6, 14), (5.6, .6, 0), (9.4, 5, 0), (8.8, 17), (8.4, 24), (6.6, 38), (9.6, 52), (14, 68, 0), (0, 69, 0)])
b.line([(13.4, 66.4), (0, 67.4)], 'stitch')
b.line([(5.4, 20), (2, 21.6), (0, 22.2), (-2, 21.6), (-5.4, 20)], 'cord', mirror=False)
b.line([(0, 22.2), (-1.6, 27.5)], 'cord', mirror=False); b.line([(0, 22.2), (1.4, 27.8)], 'cord', mirror=False)
b.line([(0, 22.2), (-2.2, 21), (-1.4, 23.4), (0, 22.2), (2.2, 21), (1.4, 23.4), (0, 22.2)], 'cord', mirror=False)
M['kaliya-dress'] = render([f, b], '#7B80C4')

# MANOLO: stretch halter mini; deep V to the waist tied at the neck, open back down to the low waist, bound edges
f, b = View(), View()
f.body([(0, 30, 0), (1.6, 1.4, 0), (2.8, .8, 0), (8.6, 19.6, 0), (8.2, 24), (6.6, 38), (9.4, 52), (9.2, 66, 0), (0, 66.6, 0)])
f.line([(.5, 28.6), (1.9, 2.4)], 'stitch'); f.line([(3.2, 2.2), (7.8, 18.8)], 'stitch'); f.line([(8.8, 64.4), (0, 65)], 'stitch')
f.line([(1.6, 1.4), (1.2, -2.6), (0, -3.6)], 'cord'); f.line([(2.8, .8), (2.2, -2.2), (0, -3.6)], 'cord')
f.line([(0, 30), (0, 66.6)], 'fold', mirror=False)
b.body([(0, 46, 0), (4.4, 38), (8.6, 21, 0), (8.2, 24), (6.6, 38), (9.4, 52), (9.2, 66, 0), (0, 66.6, 0)])
b.line([(.6, 44.6), (4.6, 36.8), (7.9, 21.8)], 'stitch'); b.line([(8.8, 64.4), (0, 65)], 'stitch')
b.line([(0, 46), (0, 66.6)], 'fold', mirror=False)
M['manolo-dress'] = render([f, b], '#1E1E22')

# APOLINE corset: three-part cups, four boned panels a side, pointed front; laced back
f, b = View(), View()
f.body([(0, 21, 0), (8.6, 21.6, 0), (6.6, 38), (8.6, 47.6, 0), (0, 57, 0)])
f.shape([(0, 21, 0), (.6, 17.4), (2.6, 14.6), (5, 14.2), (7.4, 15.4), (8.8, 17.6, 0), (8.6, 21.6, 0), (5.4, 24.2), (2, 23.6), (0, 22, 0)], 'f2', mirror=True)
f.line([(.8, 17.4), (4, 17.8), (8.6, 17.8)], 'seam'); f.line([(4.6, 17.8), (4.6, 24)], 'seam')
f.line([(0, 22), (0, 57)], 'seam', mirror=False); f.line([(4.6, 24), (4.2, 38), (4.4, 51.6)], 'seam'); f.line([(7.4, 22.6), (6.2, 38), (7.6, 48.6)], 'seam')
f.line([(8.4, 47.4), (0, 56.2)], 'stitch')
b.body([(0, 19.6, 0), (8.6, 19.4, 0), (8.6, 22), (6.6, 38), (8.6, 47.4, 0), (0, 47.8, 0)])
b.line([(4.2, 19.6), (4, 38), (4.4, 47.6)], 'seam'); b.line([(7.2, 19.4), (6.1, 38), (7.6, 47.4)], 'seam')
b.line([(1.2, 19.6), (1.2, 47.6)], 'stitch'); b.dots([(1.2, y) for y in range(21, 47, 3)], .3, '#D8D8D8')
b.line([(-1.2, 21), (1.2, 24), (-1.2, 27), (1.2, 30), (-1.2, 33), (1.2, 36), (-1.2, 39), (1.2, 42), (-1.2, 45)], 'cord', mirror=False)
M['apoline-corset'] = render([f, b], '#6F98AF', '#93B3C5')

# APOLINE skirt: gathered ball-gown skirt on a waistband, overlapping fronts with a slit; back zip
def apo_skirt(v, front):
    v.shape([(-7, 33, 0), (7, 33, 0), (7, 38, 0), (-7, 38, 0)], 'f2')
    v.body([(0, 38, 0), (7.2, 38, 0), (11, 50), (21, 100), (25, 128, 0), (0, 130, 0)])
    for x in range(-6, 7, 2): v.line([(x, 38.4), (x * 1.05, 41)], 'fold', mirror=False)
    for x0, x1 in ((2, 3), (5, 10), (6.6, 17)): v.line([(x0, 42), (x1, 128.8)], 'fold')
    if front: v.line([(-3, 38), (-6, 80), (-9.6, 129.6)], 'edge', mirror=False)
    else: v.line([(0, 38), (0, 54)], 'zip', mirror=False); v.line([(0, 54), (0, 130)], 'seam', mirror=False)
f, b = View(), View(); apo_skirt(f, True); apo_skirt(b, False)
M['apoline-skirt'] = render([f, b], '#6F98AF', '#8CAEC1')

# LEON: one-button tuxedo jacket with satin peak lapels, trousers with a satin side stripe
def leon(v, front):
    v.body([(0, 56, 0), (6.6, 56, 0), (7, 90), (6.4, 128, 0), (1.4, 128, 0), (.4, 66, 0)], 'f2')
    v.line([(6.9, 58), (6.5, 127.6)], 'gold' if False else 'seam'); v.shape([(6.2, 58, 0), (6.9, 58, 0), (6.5, 127.6, 0), (5.8, 127.6, 0)], 'dark', mirror=True)
    v.shape([(10.4, 4, 0), (12.4, 8), (13.2, 30), (13.6, 56, 0), (10.8, 57, 0), (10.4, 32), (9.4, 18, 0)], 'f1', mirror=True)
    v.body([(0, 3, 0), (4, 1, 0), (10.4, 4, 0), (9.6, 18), (8.8, 38), (9.8, 58, 0), (0, 58 if not front else 56, 0)])
    if front:
        v.shape([(0, 34, 0), (-4, 1, 0), (-2.6, 1, 0), (0, 12, 0), (2.6, 1, 0), (4, 1, 0), (0, 34, 0)], 'white')
        v.shape([(4, 1, 0), (5.6, 10, 0), (8.2, 9, 0), (6.2, 15, 0), (0, 34, 0), (2.6, 1, 0)], 'dark', mirror=True)
        v.shape([(-1.4, 4, 0), (1.4, 4, 0), (1.4, 6, 0), (-1.4, 6, 0)], 'dark'); v.dots([(0, 38)], .6, '#2E2E33', mirror=False)
        v.line([(0, 34), (0, 58)], 'seam', mirror=False); v.line([(4.6, 46), (8.4, 46)], 'seam')
    else: v.line([(0, 3), (0, 58)], 'seam', mirror=False); v.line([(0, 48), (0, 58)], 'edge', mirror=False)
f, b = View(), View(); leon(f, True); leon(b, False)
M['leon-tuxedo'] = render([f, b], '#3D424A', '#33373E')

# SIELO: bell sleeve with a ruffle, flat front and back
def sielo(v, front):
    v.shape([(-11, 90, 0), (-14, 120), (-16, 128, 0), (16, 128, 0), (14, 120), (11, 90, 0)], 'f2')
    for x in range(-13, 15, 4): v.line([(x * .8, 92), (x * 1.1, 127.6)], 'fold', mirror=False)
    v.line([(-16, 128), (-12, 126.6), (-8, 128.4), (-4, 126.8), (0, 128.4), (4, 126.8), (8, 128.4), (12, 126.6), (16, 128)], 'stitch', mirror=False)
    v.shape([(0, 10, 0), (-5, 11.4), (-9, 17), (-10.4, 24, 0), (-11, 90, 0), (11, 90, 0), (10.4, 24, 0), (9, 17), (5, 11.4)], 'f1')
    v.line([(-11, 89), (11, 89)], 'stitch', mirror=False)
    if not front: v.line([(0, 24), (0, 90)], 'seam', mirror=False)
    v.line([(-3, 26), (-4, 88)], 'fold', mirror=False)
f, b = View(), View(); sielo(f, True); sielo(b, False)
M['sielo-sleeve'] = render([f, b], '#9BB6D4', '#B5CAE2')

# VENESA: strappy V-neck maxi with a waist seam and a front slit
f, b = View(), View()
for v, front in ((f, True), (b, False)):
    v.body([(0, 37, 0), (6.6, 38, 0), (9.2, 52), (9.4, 90), (10.4, 128, 0), (0, 128.6, 0)])
    if front: v.shape([(3, 84, 0), (4.4, 128.6, 0), (1.6, 128.6, 0)], '#E9D7C6'); v.line([(3, 84), (4.4, 128.6)], 'seam')
    else: v.line([(0, 38), (0, 128.6)], 'seam', mirror=False)
    v.body([(0, 24 if front else 30, 0), (5.4, 14, 0), (8.6, 20), (8.4, 24), (6.6, 38, 0), (0, 38.2, 0)])
    v.line([(5, 14.4), (4.4, 2, 0)], 'cord'); v.line([(0, 38.2), (6.6, 38)], 'seam'); v.line([(3.6, 24), (4, 34), (4.4, 24)], 'seam')
    v.line([(6, 60), (6.4, 126)], 'fold')
M['venesa-dress'] = render([f, b], '#B65C42')

# RIVA: bridal gown, fitted strapless bodice in princess seams, full skirt with a train
def riva(v, front):
    v.body([(0, 38, 0), (6.6, 38, 0), (11, 56), (20, 100), (24, 128, 0), (0, 129 if front else 136, 0)], 'f1')
    for x0, x1 in ((2, 3), (4.6, 10), (6, 18)): v.line([(x0, 40), (x1, 128.4)], 'fold')
    top = [(0, 19.6, 0), (2.4, 16.4), (4.6, 15.8), (7, 16.6), (8.8, 18.4, 0)] if front else [(0, 18.6, 0), (8.8, 18.6, 0)]
    v.body(top + [(8.6, 22), (6.6, 38, 0), (0, 38.4, 0)], 'f2')
    v.line([(4.5, 16 if front else 18.6), (4.2, 38.2)], 'seam'); v.line([(0, 38.4), (6.6, 38)], 'seam')
    if not front: v.dots([(0, y) for y in range(21, 52, 3)], .42, '#FAF8F4', mirror=False); v.line([(0, 38.4), (0, 136)], 'seam', mirror=False)
f, b = View(), View(); riva(f, True); riva(b, False)
M['riva-dress'] = render([f, b], '#F4EFE6', '#FBF8F2')

# JENEVA: maxi with a deep V, gathered waist and long sleeves
f, b = View(), View()
for v, front in ((f, True), (b, False)):
    long_sleeve(v)
    v.body([(0, 38, 0), (6.6, 38, 0), (10, 54), (12.6, 100), (13.6, 128, 0), (0, 128.6, 0)])
    for x0, x1 in ((1.6, 2.4), (4, 7), (5.8, 11)): v.line([(x0, 40), (x1, 128.2)], 'fold')
    v.body([(0, 30 if front else 4, 0), (4.2, 1.2, 0), (9.4, 5, 0), (8.8, 17), (8.6, 24), (6.6, 38, 0), (0, 38.4, 0)])
    for x in range(-6, 7): v.line([(x, 36.2), (x * 1.05, 40)], 'fold', mirror=False)
    v.line([(0, 38.4), (6.6, 38)], 'stitch')
    if not front: v.line([(0, 4), (0, 52)], 'zip', mirror=False)
M['jeneva-dress'] = render([f, b], '#A68FCC', '#B9A6D9')

# Generic pictures by garment type, for customer designs added to the catalogue (the customer's photo is never shown there).
SAGE = '#86A396'
f, b = View(), View()
for v, front in ((f, True), (b, False)):
    v.body([(0, 3 if front else 2, 0), (4.4, 1, 0), (7.4, 3, 0), (8.4, 16), (8.6, 22), (6.6, 38), (9.4, 52), (13, 100, 0), (0, 101, 0)])
    v.line([(0, 38.2), (6.6, 38)], 'seam'); v.line([(3.8, 24), (4, 34), (4.2, 24)], 'seam'); v.line([(5, 54), (8, 99)], 'fold')
    if not front: v.line([(0, 2), (0, 54)], 'zip', mirror=False)
M['_dress'] = render([f, b], SAGE)
f, b = View(), View()
for v, front in ((f, True), (b, False)):
    v.shape([(-7, 32, 0), (7, 32, 0), (7, 37, 0), (-7, 37, 0)], 'f2')
    v.body([(0, 37, 0), (7.2, 37, 0), (10, 56), (13.4, 100, 0), (0, 101, 0)]); v.line([(4, 40), (8, 99)], 'fold')
    if not front: v.line([(0, 32), (0, 52)], 'zip', mirror=False)
M['_skirt'] = render([f, b], SAGE)
f, b = View(), View()
for v, front in ((f, True), (b, False)):
    v.shape([(9.4, 5, 0), (11.6, 9), (14.4, 26, 0), (11.4, 27.6, 0), (8.8, 17, 0)], 'f1', mirror=True)
    v.body([(0, 4 if front else 2, 0), (4.2, 1.2, 0), (9.4, 5, 0), (8.8, 17), (8.6, 24), (7.4, 38), (8.6, 52, 0), (0, 52.6, 0)])
    v.line([(8.4, 50), (0, 50.6)], 'stitch')
M['_top'] = render([f, b], SAGE)
f, b = View(), View()
for v, front in ((f, True), (b, False)):
    v.shape([(-7, 32, 0), (7, 32, 0), (7, 37, 0), (-7, 37, 0)], 'f2')
    v.body([(0, 37, 0), (7.2, 37, 0), (9.2, 52), (8.4, 90), (7.6, 128, 0), (1.4, 128, 0), (.4, 60, 0)])
    v.line([(0, 37), (0, 60)], 'seam' if not front else 'zip', mirror=False); v.line([(4.6, 64), (4.4, 127)], 'fold')
M['_pants'] = render([f, b], SAGE)

for k, v in M.items(): (out / f'{k}.svg').write_text(v)
print(len(M), 'drawings')
