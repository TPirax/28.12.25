// Sample specs as the vision step would return them, used by tests (no API key needed).
const up = (o = {}) => Object.assign({ construction: 'shoulders', neckline_front: 'round', neckline_back: 'round', v_depth_cm: 0, sleeve_type: 'none', sleeve_shape: 'fitted', closure: 'back_zip', top_length: 'hip' }, o);
const sk = (o = {}) => Object.assign({ silhouette: 'none', length: 'knee', slit: 'none' }, o);
const pa = (o = {}) => Object.assign({ leg: 'straight', length: 'full', waist: 'zip_fly' }, o);
const S = (o) => Object.assign({ supported: true, unsupported_reason: '', title_he: '', description_he: '', fabric: 'woven', fabric_suggestion_he: '', fit: 'semi', upper: up(), waist_seam: false, skirt: sk(), pants: pa(), approximations_he: [], confidence: 'high' }, o);
module.exports = {
  'mermaid-gown': S({ category: 'dress', title_he: 'שמלת ערב מרמייד מתחרה', fabric: 'stretch', fit: 'fitted', upper: up({ construction: 'straps', neckline_front: 'straight', closure: 'back_zip' }), skirt: sk({ silhouette: 'mermaid', length: 'floor' }) }),
  'jeneva-like': S({ category: 'dress', title_he: 'שמלת מקסי עם מחשוף V ושרוולים ארוכים', fabric: 'woven', fit: 'fitted', upper: up({ neckline_front: 'v', v_depth_cm: 26, sleeve_type: 'long', sleeve_shape: 'straight' }), skirt: sk({ silhouette: 'pencil', length: 'maxi', slit: 'cb' }) }),
  'corset-flare': S({ category: 'dress', title_he: 'שמלת סטרפלס עם חצאית מתרחבת', fabric: 'woven', fit: 'fitted', upper: up({ construction: 'strapless', neckline_front: 'sweetheart' }), waist_seam: true, skirt: sk({ silhouette: 'circle_full', length: 'knee' }), approximations_he: ['שולי החצאית בתמונה לא אחידים: בגזרה המכפלת ישרה'] }),
  'shirt-dress': S({ category: 'dress', fit: 'semi', upper: up({ closure: 'front_buttons', sleeve_type: 'short', sleeve_shape: 'straight' }), waist_seam: true, skirt: sk({ silhouette: 'gathered', length: 'midi' }) }),
  'sheath': S({ category: 'dress', fit: 'fitted', upper: up({ neckline_front: 'boat', sleeve_type: 'three_quarter' }), skirt: sk({ silhouette: 'pencil', length: 'knee' }) }),
  'blouse': S({ category: 'top', fit: 'semi', upper: up({ neckline_front: 'v', v_depth_cm: 18, sleeve_type: 'long', sleeve_shape: 'bell', closure: 'pullover', top_length: 'hip' }) }),
  'tee': S({ category: 'top', fabric: 'stretch', fit: 'fitted', upper: up({ neckline_front: 'scoop', sleeve_type: 'short', closure: 'pullover' }) }),
  'pencil-skirt': S({ category: 'skirt', fit: 'fitted', skirt: sk({ silhouette: 'pencil', length: 'knee', slit: 'cb' }) }),
  'circle-skirt': S({ category: 'skirt', skirt: sk({ silhouette: 'circle_half', length: 'midi' }) }),
  'wide-pants': S({ category: 'pants', pants: pa({ leg: 'wide', waist: 'side_zip' }) }),
  'leggings': S({ category: 'pants', fabric: 'stretch', pants: pa({ leg: 'skinny', waist: 'elastic' }) }),
};
