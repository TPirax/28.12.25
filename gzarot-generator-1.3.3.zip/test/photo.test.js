// Photo-to-pattern flow with a mocked vision step and a mocked WordPress charge endpoint.
'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs'), os = require('os'), path = require('path');
const { createCanvas } = require('canvas');
const { createApp } = require('../server');
const { signTicket } = require('../lib/ticket');
const specs = require('./fixtures/specs');
const { draftFromSpec } = require('../lib/draft');

const SECRET = 'z'.repeat(64);
const M = { height: 168, bust: 92, underbust: 76, waist: 72, hips: 100, waist_to_hip: 20, waist_to_knee: 58, waist_to_floor: 105 };
let server, base, dir, n = 0;
const charges = [];
let chargeAnswer = () => ({ ok: true, usage_id: 100 + charges.length, source: 'plan' });

function jpeg() { const c = createCanvas(400, 600), g = c.getContext('2d'); g.fillStyle = '#eee'; g.fillRect(0, 0, 400, 600); g.fillStyle = '#222'; g.fillRect(150, 50, 100, 500); return c.toBuffer('image/jpeg').toString('base64'); }

function ticket(over = {}) {
  const now = Math.floor(Date.now() / 1000);
  return signTicket(Object.assign({ v: 1, iss: 'https://shop.test/', iat: now, exp: now + 600, jti: 'p' + (++n) + Math.random(), usage_id: 0, source: 'photo', model: 'photo-pattern',
    customer: { id: 7, name: 'נועה כהן', email: 'noa@example.com' }, profile: { id: 3, label: 'המידות שלי' }, product: { id: 55, name: 'גזרה מתמונה' },
    measurements: M, watermark: 'נועה כהן · noa@example.com', return_url: 'https://shop.test/my-account/custom-fit/' }, over), SECRET);
}
async function session(t) {
  const r = await fetch(base + '/generate', { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'ticket=' + encodeURIComponent(t) });
  return { loc: r.headers.get('location'), cookie: (r.headers.get('set-cookie') || '').split(';')[0] };
}
const J = (s, url, body) => fetch(base + url, { method: 'POST', headers: { cookie: s.cookie, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'gzphoto-'));
  const app = createApp({
    secret: SECRET, siteUrl: 'https://shop.test/', dbFile: path.join(dir, 'db.sqlite'), sessionTtl: 3600, secureCookies: false, maxAnalysesPerDay: 6,
    vision: async (jpg, note) => { assert.ok(jpg.subarray(0, 2).equals(Buffer.from([0xff, 0xd8]))); return { spec: JSON.parse(JSON.stringify(specs[note] || specs['jeneva-like'])), usage: { input_tokens: 1700, output_tokens: 600 } }; },
    charge: async (site, body) => { charges.push({ site, body }); return chargeAnswer(body); },
  });
  await new Promise(r => { server = app.listen(0, r); });
  base = 'http://127.0.0.1:' + server.address().port;
  server.on('close', () => app.close());
});
test.after(() => server.close());

test('every sample spec drafts without errors', () => {
  for (const [k, sp] of Object.entries(specs)) {
    const r = draftFromSpec(sp, M);
    assert.ok(r.pieces.length >= 3, k);
  }
});

test('upload, confirm (charged once), download A4 and A0', async () => {
  const s = await session(ticket());
  const up = await (await fetch(base + s.loc, { headers: { cookie: s.cookie } })).text();
  assert.match(up, /גזרה מתמונה/);
  const r = await (await J(s, s.loc + '/photo', { image: jpeg(), note: 'mermaid-gown' })).json();
  assert.ok(r.url, JSON.stringify(r));
  const page = await (await fetch(base + r.url, { headers: { cookie: s.cookie } })).text();
  assert.match(page, /מרמייד/);
  const pv = await (await J(s, r.url + '/preview', { spec: {}, over: {} })).json();
  assert.ok(pv.img && pv.img.startsWith('data:image/png'), JSON.stringify(pv).slice(0, 200));
  // no PDF before confirming
  const early = await fetch(base + r.url + '/pdf', { method: 'POST', headers: { cookie: s.cookie, 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'f=a4' });
  assert.strictEqual(early.status, 402);
  const before = charges.length;
  const c = await (await J(s, r.url + '/confirm', { spec: {}, over: {} })).json();
  assert.ok(c.ok, JSON.stringify(c));
  assert.strictEqual(charges.length, before + 1);
  assert.strictEqual(charges[charges.length - 1].site, 'https://shop.test/');
  assert.strictEqual(charges[charges.length - 1].body.user_id, 7);
  for (const f of ['a4', 'a0']) {
    const pdf = await fetch(base + r.url + '/pdf', { method: 'POST', headers: { cookie: s.cookie, 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'f=' + f + '&length_cm=110' });
    assert.strictEqual(pdf.status, 200);
    const buf = Buffer.from(await pdf.arrayBuffer());
    assert.strictEqual(buf.subarray(0, 5).toString(), '%PDF-');
    fs.writeFileSync(path.join(dir, 'photo-' + f + '.pdf'), buf);
  }
  assert.strictEqual(charges.length, before + 1, 'downloads do not charge again');
  // after charging the garment type is locked
  await J(s, r.url + '/preview', { spec: { category: 'pants' }, over: {} });
  const again = await (await fetch(base + r.url, { headers: { cookie: s.cookie } })).text();
  assert.match(again, /PDF להדפסה/);
});

test('editing the spec before confirming changes the pattern', async () => {
  const s = await session(ticket());
  const r = await (await J(s, s.loc + '/photo', { image: jpeg(), note: 'pencil-skirt' })).json();
  const a = await (await J(s, r.url + '/preview', { spec: {}, over: {} })).json();
  const b = await (await J(s, r.url + '/preview', { spec: { skirt: { silhouette: 'circle_full' } }, over: {} })).json();
  assert.ok(a.img && b.img && a.img !== b.img);
});

test('refused charge shows the plugin message and blocks the PDF', async () => {
  chargeAnswer = () => ({ ok: false, message: 'גזרות מתמונה זמינות במנוי זהב ופלטינום.' });
  const s = await session(ticket());
  const r = await (await J(s, s.loc + '/photo', { image: jpeg(), note: 'blouse' })).json();
  const c = await J(s, r.url + '/confirm', { spec: {}, over: {} });
  assert.strictEqual(c.status, 402);
  assert.match((await c.json()).error, /זהב/);
  const pdf = await fetch(base + r.url + '/pdf', { method: 'POST', headers: { cookie: s.cookie, 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'f=a4' });
  assert.strictEqual(pdf.status, 402);
  chargeAnswer = () => ({ ok: true, usage_id: 500, source: 'regen' });
});

test("another customer's design is not reachable", async () => {
  const s = await session(ticket());
  const r = await (await J(s, s.loc + '/photo', { image: jpeg(), note: 'tee' })).json();
  const did = r.url.split('/d/')[1];
  const other = await session(ticket({ customer: { id: 99, name: 'אחרת', email: 'x@example.com' } }));
  assert.strictEqual((await fetch(base + other.loc + '/d/' + did, { headers: { cookie: other.cookie } })).status, 404);
  const viaTicket = await session(ticket({ customer: { id: 99, name: 'אחרת', email: 'x@example.com' }, design: did }));
  assert.strictEqual((await fetch(base + viaTicket.loc, { headers: { cookie: viaTicket.cookie } })).status, 404);
});

test('re-download ticket opens the design and confirms for free', async () => {
  const s = await session(ticket());
  const r = await (await J(s, s.loc + '/photo', { image: jpeg(), note: 'wide-pants' })).json();
  await J(s, r.url + '/confirm', {});
  const did = r.url.split('/d/')[1];
  const s2 = await session(ticket({ design: did }));
  const g = await fetch(base + s2.loc, { headers: { cookie: s2.cookie }, redirect: 'manual' });
  assert.strictEqual(g.status, 303);
  const page = await (await fetch(base + g.headers.get('location'), { headers: { cookie: s2.cookie } })).text();
  assert.match(page, /הורדה חוזרת \(ללא חיוב\)/);
});

test('unsupported garments cannot be confirmed', async () => {
  const s = await session(ticket());
  specs['coat'] = Object.assign({}, specs['blouse'], { supported: false, unsupported_reason: 'מעיל עם דש עדיין לא נתמך.' });
  const r = await (await J(s, s.loc + '/photo', { image: jpeg(), note: 'coat' })).json();
  const html = await (await fetch(base + r.url, { headers: { cookie: s.cookie } })).text();
  assert.match(html, /מעיל עם דש/);
  assert.strictEqual((await J(s, r.url + '/confirm', {})).status, 400);
});

test('daily analysis limit', async () => {
  const s = await session(ticket({ customer: { id: 42, name: 'בדיקה', email: 'l@example.com' } }));
  let last;
  for (let i = 0; i < 7; i++) last = await J(s, s.loc + '/photo', { image: jpeg(), note: 'tee' });
  assert.strictEqual(last.status, 429);
});

test('bad images are refused', async () => {
  const s = await session(ticket({ customer: { id: 43, name: 'ב', email: 'b@example.com' } }));
  assert.strictEqual((await J(s, s.loc + '/photo', { image: Buffer.from('not an image at all, just some text padding padding padding padding padding padding padding padding').toString('base64') })).status, 400);
});
