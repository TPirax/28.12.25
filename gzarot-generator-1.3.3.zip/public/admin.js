// Admin studio: show only the measurements the chosen model needs.
'use strict';
(() => {
  const sel = document.getElementById('model'); if (!sel) return;
  const all = document.getElementById('all'), count = document.getElementById('need-count');
  document.getElementById('all-wrap').hidden = false;
  const update = () => {
    const need = (sel.selectedOptions[0].dataset.fields || '').split(' ').filter(Boolean);
    for (const f of document.querySelectorAll('.af')) {
      const req = need.includes(f.dataset.f);
      f.querySelector('input').required = req;
      f.hidden = !req && !all.checked;
    }
    for (const g of document.querySelectorAll('.admin-group')) g.hidden = !g.querySelector('.af:not([hidden])');
    count.textContent = need.length ? `(${need.length} מידות נדרשות לדגם הזה)` : '';
  };
  sel.addEventListener('change', update);
  all.addEventListener('change', update);
  update();
})();
