(function(){
  var main=document.querySelector('.gen');if(!main)return;
  var id=main.getAttribute('data-id'),form=document.getElementById('f'),img=document.getElementById('pv'),msg=document.getElementById('pvmsg');
  var warn=document.getElementById('warn'),btns=form.querySelectorAll('button[name=f]'),seq=0,timer=0;
  function options(){var o={};form.querySelectorAll('[name^="o_"]').forEach(function(el){o[el.name.slice(2)]=el.value;});return o;}
  function setWarn(list){warn.innerHTML='';(list||[]).forEach(function(w){var li=document.createElement('li');li.textContent=w;warn.appendChild(li);});}
  function refresh(){
    var my=++seq;msg.textContent='מעדכנת…';
    fetch('/s/'+id+'/preview',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({options:options()})})
      .then(function(r){if(r.status===403){location.reload();throw 0;}return r.json();})
      .then(function(d){
        if(my!==seq)return;setWarn(d.warnings);
        var ok=!!d.img;btns.forEach(function(b){b.disabled=!ok;});
        if(!ok){msg.textContent='תקני את הערכים כדי לראות את הגזרה.';return;}
        img.src=d.img;img.hidden=false;msg.textContent='';
        document.getElementById('n4').textContent='('+d.a4+' דפים)';document.getElementById('n0').textContent='('+d.a0+' גיליונות)';
      }).catch(function(e){if(e!==0&&my===seq)msg.textContent='לא הצלחנו לטעון תצוגה מקדימה. אפשר עדיין להוריד את הקובץ.';});
  }
  form.addEventListener('input',function(){clearTimeout(timer);timer=setTimeout(refresh,250);});
  form.addEventListener('submit',function(e){
    var b=e.submitter;if(!b)return;
    setTimeout(function(){btns.forEach(function(x){x.disabled=true;});},0);msg.textContent='מכינה את הקובץ, זה לוקח כמה שניות…';
    setTimeout(function(){btns.forEach(function(x){x.disabled=false;});msg.textContent='';},6000);
  });
  refresh();
})();
