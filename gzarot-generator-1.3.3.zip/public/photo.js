(function () {
  var main = document.querySelector('main.photo'); if (!main) return;
  var id = main.getAttribute('data-id'), img = document.getElementById('pv'), msg = document.getElementById('pvmsg');
  function post(url, body) {
    return fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', body: JSON.stringify(body) })
      .then(function (r) { if (r.status === 403) { location.reload(); throw 0; } return r.json().then(function (d) { d._status = r.status; return d; }); });
  }

  // ---------- upload
  var up = document.getElementById('up');
  if (up) {
    var file = document.getElementById('file'), out = document.getElementById('msg'), btn = up.querySelector('button');
    file.addEventListener('change', function () { if (file.files[0]) { img.src = URL.createObjectURL(file.files[0]); img.hidden = false; msg.textContent = ''; } });
    up.addEventListener('submit', function (e) {
      e.preventDefault(); var f = file.files[0]; if (!f) return;
      btn.disabled = true; out.textContent = 'מנתחת את התמונה. זה לוקח עד דקה…';
      var im = new Image();
      im.onload = function () {
        var s = Math.min(1, 1600 / Math.max(im.naturalWidth, im.naturalHeight)), c = document.createElement('canvas');
        c.width = Math.round(im.naturalWidth * s); c.height = Math.round(im.naturalHeight * s);
        var g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(im, 0, 0, c.width, c.height);
        var data = c.toDataURL('image/jpeg', 0.88).split(',')[1];
        post('/s/' + id + '/photo', { image: data, note: document.getElementById('note').value })
          .then(function (d) { if (d.url) location.href = d.url; else { out.textContent = d.error || 'הניתוח נכשל.'; btn.disabled = false; } })
          .catch(function (e) { if (e !== 0) { out.textContent = 'הניתוח נכשל. נסי שוב.'; btn.disabled = false; } });
      };
      im.onerror = function () { out.textContent = 'הדפדפן לא הצליח לקרוא את הקובץ. נסי JPG או PNG.'; btn.disabled = false; };
      im.src = URL.createObjectURL(f);
    });
    return;
  }

  // ---------- design confirmation
  var form = document.getElementById('f'); if (!form) return;
  var did = main.getAttribute('data-did'), warn = document.getElementById('warn'), seq = 0, timer = 0;
  function collect() {
    var spec = {}, over = {};
    form.querySelectorAll('select[name], input[name]').forEach(function (el) {
      var n = el.name, v = el.value;
      if (n === 'f') return;
      if (/_cm$/.test(n)) { if (v) over[n] = v; return; }
      if (n === 'waist_seam') { spec.waist_seam = v === 'true'; return; }
      var p = n.split('.');
      if (p.length === 2) { spec[p[0]] = spec[p[0]] || {}; spec[p[0]][p[1]] = v; } else spec[n] = v;
    });
    return { spec: spec, over: over };
  }
  function groups() {
    var c = (form.querySelector('[name=category]') || {}).value || main.getAttribute('data-category');
    var show = function (sel, on) { form.querySelectorAll(sel).forEach(function (el) { el.hidden = !on; }); };
    show('.g-upper', c === 'top' || c === 'dress'); show('.g-skirt', c === 'skirt' || c === 'dress'); show('.g-pants', c === 'pants');
    show('.only-dress', c === 'dress'); show('.only-top', c === 'top');
  }
  function setWarn(list) { warn.innerHTML = ''; (list || []).forEach(function (w) { var li = document.createElement('li'); li.textContent = w; warn.appendChild(li); }); }
  function refresh() {
    var my = ++seq; msg.textContent = 'משרטטת…';
    post('/s/' + id + '/d/' + did + '/preview', collect()).then(function (d) {
      if (my !== seq) return;
      if (d.error) { setWarn([d.error]); msg.textContent = ''; img.hidden = true; return; }
      setWarn(d.warnings); img.src = d.img; img.hidden = false; msg.textContent = '';
      var n4 = document.getElementById('n4'), n0 = document.getElementById('n0');
      if (n4) n4.textContent = '(' + d.a4 + ' דפים)'; if (n0) n0.textContent = '(' + d.a0 + ' גיליונות)';
    }).catch(function (e) { if (e !== 0 && my === seq) msg.textContent = 'התצוגה המקדימה לא נטענה.'; });
  }
  form.addEventListener('input', function () { groups(); clearTimeout(timer); timer = setTimeout(refresh, 300); });
  var confirmBtn = document.getElementById('confirm');
  if (confirmBtn) confirmBtn.addEventListener('click', function () {
    confirmBtn.disabled = true; setWarn(['מאשרת את הגזרה…']);
    post('/s/' + id + '/d/' + did + '/confirm', collect()).then(function (d) {
      if (d.ok) location.reload(); else { setWarn([d.error || 'האישור נכשל.']); confirmBtn.disabled = false; }
    }).catch(function (e) { if (e !== 0) { setWarn(['האישור נכשל. נסי שוב.']); confirmBtn.disabled = false; } });
  });
  form.addEventListener('submit', function (e) { var b = e.submitter; if (!b) return; msg.textContent = 'מכינה את הקובץ…'; setTimeout(function () { msg.textContent = ''; }, 6000); });
  groups(); refresh();
})();
