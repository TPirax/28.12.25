// Hostinger deployment: verify the already bundled, generated engine.
// Re-generating requires the original corset-pattern.html (not distributed here).
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const filename = path.resolve(__dirname, '../lib/engine.js');
if (!fs.existsSync(filename)) throw new Error('Missing compiled lib/engine.js');
const stat = fs.statSync(filename);
if (stat.size < 100000) throw new Error('Compiled engine looks incomplete');
const createEngine = require(filename);
if (typeof createEngine !== 'function') throw new Error('Compiled engine has invalid export');
console.log('Bundled pattern engine verified (' + stat.size + ' bytes)');
