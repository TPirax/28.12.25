// Admin studio: customer design inbox, opening a design for review, and adding it to the catalogue.
'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs'), os = require('os'), path = require('path');
const { createCanvas } = require('canvas');
const { createApp } = require('../server');
const { signTicket } = require('../lib/ticket');
const specs = require('./fixtures/specs');

const SECRET = 'a'.repeat(64), PASSWORD = 'admin-password-for-tests-1234', UA = 'test-agent';
const M = { height: 168, bust: 92, underbust: 76, waist: 72, hips: 100, waist_to_hip: 20, waist_to_knee: 58, waist_to_floor: 105 };
let server, base, n = 0, admin, dir;
const charges = [];

function jpeg() { const c = createCanvas(300, 400), g = c.getContext('2d'); g.fillStyle = '#eee'; g.fillRect(0, 0, 300, 400); g.fillStyle = '#222'; g.fillRect(120, 40, 60, 320); return c.toBuffer('image/jpeg').toString('base64'); }
function ticket(over = {}) {
  const now = Math.floor(Date.now() / 1000);
  return signTicket(Object.assign({ v: 1, iss: 'https://shop.test/', iat: now, exp: now + 600, jti: 'a' + (++n) + Math.random(), usage_id: 0, source: 'photo', model: 'photo-pattern',
    customer: { id: 9, name: 'דנה לוי', email: 'dana@example.com' }, profile: { id: 1, label: 'שלי' }, measurements: M, watermark: 'דנה לוי', return_url: 'https://shop.test/' }, over), SECRET);
}
async function session(t) {
  const r = await fetch(base + '/generate', { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'ticket=' + encodeURIComponent(t) });
  return { loc: r.headers.get('location'), cookie: (r.headers.get('set-cookie') || '').split(';')[0] };
}
const cookieOf = r => (r.headers.get('set-cookie') || '').split(';')[0];
const get = (url, cookie) => fetch(base + url, { redirect: 'manual', headers: { cookie: cookie || admin, 'user-agent': UA } });
const post = (url, form, cookie) => fetch(base + url, { method: 'POST', redirect: 'manual', headers: { cookie: cookie || admin, 'user-agent': UA, 'sec-fetch-site': 'same-origin', 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(form) });
const csrf = async () => (await (await get('/admin')).text()).match(/name="csrf" value="([^"]+)"/)[1];

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'gzadmin-'));
  const app = createApp({ secret: SECRET, adminPassword: PASSWORD, dbFile: path.join(dir, 'db.sqlite'), sessionTtl: 3600, secureCookies: false,
    vision: async (jpg, note) => ({ spec: JSON.parse(JSON.stringify(specs[note] || specs['jeneva-like'])), usage: {} }),
    charge: async (site, body) => { charges.push(body); return { ok: true, usage_id: 500 + charges.length, source: 'plan' }; } });
  await new Promise(r => { server = app.listen(0, r); });
  base = 'http://127.0.0.1:' + server.address().port;
  server.on('close', () => app.close());
  admin = cookieOf(await post('/admin/login', { password: PASSWORD }, ''));
  assert.match(admin, /^gizra_admin=/);
});
test.after(() => server.close());

test('customer designs reach the admin inbox, open as a copy, and can join the catalogue', async () => {
  assert.strictEqual((await get('/admin/designs', 'x=1')).status, 303, 'inbox needs an admin login');

  // a customer analyses a photo but never confirms it
  const s = await session(ticket());
  await fetch(base + s.loc, { headers: { cookie: s.cookie } });
  const up = await (await fetch(base + s.loc + '/photo', { method: 'POST', headers: { cookie: s.cookie, 'Content-Type': 'application/json' }, body: JSON.stringify({ image: jpeg(), note: 'mermaid-gown' }) })).json();
  const did = up.url.split('/d/')[1];

  assert.match(await (await get('/admin')).text(), /עיצובים מלקוחות<b>1<\/b>/);
  const inbox = await (await get('/admin/designs')).text();
  assert.ok(inbox.includes(`/admin/designs/${did}`) && inbox.includes('לא אושרה'));
  assert.doesNotMatch(await (await get('/admin')).text(), /עיצובים מלקוחות<b>/, 'visiting the inbox marks designs as seen');
  assert.match(await (await get(`/admin/designs/${did}`)).text(), /פתיחת העמוד המלא/);
  assert.strictEqual((await get(`/admin/designs/${did}/thumb.jpg`)).headers.get('content-type'), 'image/jpeg');

  // open the full page as an admin copy: preview and approval work, the customer's record stays untouched
  const token = await csrf();
  const open = await post(`/admin/designs/${did}/open`, { csrf: token, m_bust: 92, m_waist: 74, m_hips: 100 });
  assert.strictEqual(open.status, 303);
  const page = open.headers.get('location'), sc = cookieOf(open);
  assert.ok(!page.endsWith(did));
  assert.match(await (await fetch(base + page, { headers: { cookie: sc } })).text(), /בדיקת מנהל, ללא חיוב/);
  const ok = await (await fetch(base + page + '/confirm', { method: 'POST', headers: { cookie: sc, 'Content-Type': 'application/json' }, body: JSON.stringify({ spec: {}, over: {} }) })).json();
  assert.ok(ok.ok); assert.strictEqual(charges.length, 0);
  assert.match(await (await get('/admin/designs')).text(), /לא אושרה/);

  // publish: the design becomes a catalogue model drafted for each customer's measurements
  await post(`/admin/designs/${did}/publish`, { csrf: token, name: 'שמלה TESTA', cat: 'women/evening' });
  const listed = (await (await fetch(base + '/models.json')).json()).models.find(m => m.name === 'שמלה TESTA');
  assert.ok(listed && listed.kind === 'design' && listed.image === '/static/models/_dress.svg', JSON.stringify(listed));
  assert.deepStrictEqual(listed.cats, ['women/evening']);
  const c = await session(ticket({ model: listed.key, usage_id: 77, source: 'plan' }));
  const r1 = await fetch(base + c.loc, { redirect: 'manual', headers: { cookie: c.cookie } });
  const dpage = r1.headers.get('location');
  assert.match(dpage, /\/d\//);
  assert.strictEqual((await fetch(base + c.loc, { redirect: 'manual', headers: { cookie: c.cookie } })).headers.get('location'), dpage, 'reloading keeps the same copy');
  const html = await (await fetch(base + dpage, { headers: { cookie: c.cookie } })).text();
  assert.match(html, /שמלה TESTA/); assert.match(html, /PDF להדפסה/); assert.doesNotMatch(html, /thumb\.jpg/);
  const pdf = await fetch(base + dpage + '/pdf', { method: 'POST', headers: { cookie: c.cookie, 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'f=a4' });
  assert.strictEqual(pdf.headers.get('content-type'), 'application/pdf');
  assert.match(pdf.headers.get('content-disposition'), /testa/);
  assert.strictEqual(charges.length, 0, 'the ticket already counted the pattern');
  assert.strictEqual((await fetch(base + c.loc + '/instructions', { headers: { cookie: c.cookie } })).headers.get('content-type'), 'application/pdf');

  // dashboard: the customer's catalogue download and photo analysis count; admin tests do not
  const dash = await (await get('/admin/stats?days=7')).text();
  assert.match(dash, /הורדות גזרות<\/span><b class="stat-value">1</);
  assert.match(dash, /ניתוחי תמונה<\/span><b class="stat-value">1</);
  assert.match(dash, /גזרה מתמונה: <b|title="גזרה מתמונה: 1 הורדות"/);
  assert.match(dash, /A4: <b>1<\/b>/);
  assert.strictEqual((await get('/admin/stats', 'x=1')).status, 303);

  await post(`/admin/designs/${did}/unpublish`, { csrf: token });
  assert.ok(!(await (await fetch(base + '/models.json')).json()).models.some(m => m.kind === 'design'));
});

test('backup: daily snapshot, download, restore round trip', async () => {
  assert.ok(fs.readdirSync(path.join(dir, 'backups')).some(f => /^auto-\d{4}-\d{2}-\d{2}\.db$/.test(f)), 'a daily snapshot is taken at startup');
  assert.match(await (await get('/admin')).text(), /admin-banner/, 'reminder until a backup is downloaded');

  const r = await get('/admin/backup/download');
  assert.match(r.headers.get('content-disposition'), /gizra-backup-\d{4}-\d{2}-\d{2}\.db/);
  const file = Buffer.from(await r.arrayBuffer());
  assert.strictEqual(file.subarray(0, 15).toString(), 'SQLite format 3');
  assert.doesNotMatch(await (await get('/admin')).text(), /admin-banner/);
  const before = (await (await fetch(base + '/models.json')).json()).models.length;

  // change the data after the backup: add a catalogue design
  const s = await session(ticket());
  await fetch(base + s.loc, { headers: { cookie: s.cookie } });
  const up = await (await fetch(base + s.loc + '/photo', { method: 'POST', headers: { cookie: s.cookie, 'Content-Type': 'application/json' }, body: JSON.stringify({ image: jpeg(), note: 'pencil-skirt' }) })).json();
  const did = up.url.split('/d/')[1], token = await csrf();
  await post(`/admin/designs/${did}/publish`, { csrf: token, name: 'חצאית AFTER', cat: 'women/modest' });
  assert.strictEqual((await (await fetch(base + '/models.json')).json()).models.length, before + 1);

  const restore = (body, headers = {}) => fetch(base + '/admin/backup/restore', { method: 'POST', headers: Object.assign({ cookie: admin, 'user-agent': UA, 'sec-fetch-site': 'same-origin', 'x-csrf': token, 'Content-Type': 'application/octet-stream' }, headers), body });
  assert.strictEqual((await restore(file, { 'x-csrf': 'wrong' })).status, 403);
  assert.strictEqual((await restore(Buffer.from('not a database'.repeat(20)))).status, 400);
  assert.deepStrictEqual(await (await restore(file)).json(), { ok: true });
  const after = (await (await fetch(base + '/models.json')).json()).models;
  assert.strictEqual(after.length, before, 'restored catalogue drops the design added after the backup');
  assert.strictEqual((await get(`/admin/designs/${did}`)).status, 404, 'and the design itself');
  assert.match(await (await get('/admin/backup')).text(), /לפני שחזור/, 'the replaced data was kept');
});


test('catalogue settings: hide, rename, move, reorder and mark new, live in the manifest without a new version', async () => {
  const page = await (await get('/admin/catalog')).text();
  const token = page.match(/name="csrf" value="([^"]+)"/)[1];
  const form = { csrf: token };
  for (const [, key] of page.matchAll(/name="sort_([a-z0-9-]+)"/g)) { form['sort_' + key] = 500; form['show_' + key] = 'on'; form['name_' + key] = ''; }
  delete form['show_polla-skirt'];
  Object.assign(form, { 'name_kaliya-dress': 'שמלה KALIYA חדשה', 'cat_kaliya-dress': 'women/evening', 'sort_kaliya-dress': 1, 'new_kaliya-dress': 'on' });
  assert.strictEqual((await post('/admin/catalog', Object.assign({}, form, { csrf: 'wrong' }))).status, 403);
  assert.strictEqual((await post('/admin/catalog', form)).status, 303);
  const m = await (await fetch(base + '/models.json')).json();
  assert.ok(!m.models.some(x => x.key === 'polla-skirt'), 'hidden model left the catalogue');
  assert.strictEqual(m.models[0].key, 'kaliya-dress');
  assert.deepStrictEqual([m.models[0].name, m.models[0].cats[0], m.models[0].new], ['שמלה KALIYA חדשה', 'women/evening', true]);
  const studio = await (await get('/admin')).text();
  assert.match(studio, /value="polla-skirt"/, 'hidden models stay testable in the studio');
  assert.match(studio, /מוסתר/);
  // back to the defaults
  const reset = { csrf: token };
  for (const k of Object.keys(form)) if (k.startsWith('sort_')) { const key = k.slice(5); reset[k] = ''; reset['show_' + key] = 'on'; }
  await post('/admin/catalog', reset);
  const m2 = await (await fetch(base + '/models.json')).json();
  assert.ok(m2.models.some(x => x.key === 'polla-skirt'));
  assert.strictEqual(m2.models.find(x => x.key === 'kaliya-dress').name, 'שמלה KALIYA');
});
