// Interactive sewing guide: ticked steps live in this browser only (localStorage), per pattern download.
(() => {
  const root = document.getElementById('guide'); if (!root) return;
  const key = 'gz-guide:' + root.dataset.key, total = Number(root.dataset.total);
  const boxes = [...document.querySelectorAll('.gd-step input')];
  const read = () => { try { return new Set(JSON.parse(localStorage.getItem(key) || '[]')); } catch { return new Set(); } };
  const write = s => { try { localStorage.setItem(key, JSON.stringify([...s])); } catch { /* private mode: the ticks just won't stay */ } };
  let done = read();
  const paint = () => {
    for (const b of boxes) { b.checked = done.has(b.dataset.step); b.closest('.gd-step').classList.toggle('is-done', b.checked); }
    document.getElementById('gd-fill').style.width = (total ? done.size / total * 100 : 0) + '%';
    document.getElementById('gd-count').textContent = `${done.size} מתוך ${total} שלבים`;
  };
  const set = (step, on) => { on ? done.add(String(step)) : done.delete(String(step)); write(done); paint(); };
  for (const b of boxes) b.addEventListener('change', () => set(b.dataset.step, b.checked));
  document.getElementById('gd-reset').addEventListener('click', () => { if (confirm('לאפס את כל הסימונים?')) { done = new Set(); write(done); paint(); } });

  // one step at a time, large, with the screen kept awake
  const view = document.getElementById('gd-view'); let at = 1, lock = null;
  const show = () => {
    const li = document.querySelector(`.gd-step[data-step="${at}"]`); if (!li) return;
    const group = li.closest('.gd-group'), h = group.querySelector('h2');
    document.getElementById('gd-fv-pos').textContent = `שלב ${at} מתוך ${total}`;
    document.getElementById('gd-fv-group').textContent = h ? h.textContent : '';
    document.getElementById('gd-fv-text').innerHTML = li.querySelector('.gd-text').innerHTML;
    const ph = document.getElementById('gd-fv-photos'); ph.innerHTML = '';
    for (const p of group.querySelectorAll('.gd-photos .gd-ph')) ph.appendChild(p.cloneNode(true));
    document.getElementById('gd-done').textContent = at === total ? 'סיימתי' : 'סיימתי, הבא';
    document.getElementById('gd-prev').disabled = at === 1;
  };
  const open = async () => {
    at = 1; while (at < total && done.has(String(at))) at++;   // the first step not ticked yet
    view.hidden = false; document.body.classList.add('gd-locked'); show();
    try { lock = await navigator.wakeLock.request('screen'); } catch { lock = null; }
  };
  const close = () => { view.hidden = true; document.body.classList.remove('gd-locked'); if (lock) lock.release().catch(() => {}); lock = null; };
  document.getElementById('gd-focus').addEventListener('click', open);
  document.getElementById('gd-close').addEventListener('click', close);
  document.getElementById('gd-prev').addEventListener('click', () => { if (at > 1) { at--; show(); } });
  document.getElementById('gd-done').addEventListener('click', () => { set(at, true); if (at < total) { at++; show(); } else close(); });

  // photos open full size
  const box = document.getElementById('gd-lightbox');
  document.addEventListener('click', e => {
    const b = e.target.closest('.gd-ph'); if (!b) return;
    box.querySelector('img').src = b.dataset.full; box.hidden = false;
  });
  box.addEventListener('click', () => { box.hidden = true; });
  paint();
})();
