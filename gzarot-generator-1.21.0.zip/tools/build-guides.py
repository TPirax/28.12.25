"""Builds the interactive sewing guides (instructions/guides/<model>.json, photos in instructions/guides/<model>/).

A model with a source page in tools/instructions-src/<model>.html is read from it (sections, steps and photos);
the older models, whose instructions exist only as PDF, are read from instructions/<model>.pdf. Chromium writes the
Hebrew in logical order but lays out the runs visually, so each line is put back in reading order here.

Run: python3 tools/build-guides.py            (needs: pip install pymupdf)
"""
import html, json, os, re, shutil, sys, unicodedata
import pymupdf

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
SRC, PDFS, OUT = (os.path.join(ROOT, p) for p in ('tools/instructions-src', 'instructions', 'instructions/guides'))

# ---------- from the HTML sources
def strip(s): return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', s))).strip()
def keep_b(s):
    """Inner HTML reduced to text with <b> kept (the only markup the guide page shows)."""
    s = re.sub(r'<br\s*/?>', ' · ', s)
    s = re.sub(r'<(?!/?b>)[^>]+>', '', s)
    return re.sub(r'\s+', ' ', html.unescape(s)).strip()

def blocks_of(chunk):
    """Paragraphs, notes, boxes, lists and tables of an information section, in order."""
    out = []
    for m in re.finditer(r'<(p|div|ul|table)([^>]*)>(.*?)</\1>', chunk, re.S):
        tag, attrs, inner = m.groups()
        cls = re.search(r'class="([^"]+)"', attrs); cls = cls.group(1) if cls else ''
        if tag == 'div' and cls == 'photos': out.append({'t': 'photos', 'src': re.findall(r'src="([^"]+)"', inner)})
        elif tag == 'div' and cls == 'cols': out += [{'t': 'box', 'html': keep_b(b)} for b in re.findall(r'<div class="box">(.*?)</div>', inner, re.S)]
        elif tag == 'div' and cls in ('note', 'box'): out.append({'t': cls, 'html': keep_b(inner)})
        elif tag == 'ul': out.append({'t': 'list', 'items': [keep_b(li) for li in re.findall(r'<li>(.*?)</li>', inner, re.S)]})
        elif tag == 'table': out.append({'t': 'table', 'rows': [[keep_b(c) for c in re.findall(r'<t[hd]>(.*?)</t[hd]>', tr, re.S)] for tr in re.findall(r'<tr>(.*?)</tr>', inner, re.S)]})
        elif tag == 'p' and 'legal' not in cls: out.append({'t': 'small' if 'small' in cls else 'p', 'html': keep_b(inner)})
    return out

def from_html(model):
    s = open(os.path.join(SRC, model + '.html'), encoding='utf-8').read()
    body = s[s.index('</header>') + 9:s.index('</body>')]
    title = strip(re.search(r'<h1>(.*?)</h1>', s, re.S).group(1)).replace('הוראות תפירה · ', '')
    head, steps_part = body.split('<h2>שלבי תפירה</h2>', 1)
    intro = re.split(r'<h2>', head, maxsplit=1)
    sections = [{'title': '', 'blocks': blocks_of(intro[0])}] + [
        {'title': strip(part.split('</h2>', 1)[0]), 'blocks': blocks_of(part.split('</h2>', 1)[1])} for part in ('<h2>' + intro[1]).split('<h2>')[1:]]
    groups, n = [], 0
    for part in steps_part.split('<h3>')[1:]:
        t, rest = part.split('</h3>', 1)
        steps = [keep_b(li) for li in re.findall(r'<li>(.*?)</li>', rest, re.S)]
        after = [b for b in blocks_of(re.sub(r'<div class="step">.*?</div>', '', rest, flags=re.S)) if b['t'] != 'photos']
        groups.append({'title': re.sub(r'^\d+\.\s*', '', strip(t)), 'steps': steps, 'photos': re.findall(r'src="([^"]+)"', rest), 'after': after})
        n += len(steps)
    return {'model': model, 'title': title, 'sections': [x for x in sections if x['blocks']], 'groups': groups, 'source': 'html'}

# ---------- from the older PDFs
def logical(chars):
    """Characters in right-to-left visual order -> logical text of an RTL line (Chromium keeps logical code points).
    A small part of the Unicode bidi algorithm: numbers with their % and separators, Latin words and the neutrals
    between two of them are shown left to right, so those runs are reversed back; everything else reads as is."""
    chars = [c for c in chars if not unicodedata.combining(c)]   # vowel points: their position comes out unreliable
    t = [unicodedata.bidirectional(c) for c in chars]
    t = ['R' if x in ('R', 'AL') else 'L' if x == 'L' else 'EN' if x in ('EN', 'AN') else x for x in t]
    n = len(t)
    for i in range(n):
        if t[i] == 'ET' and ((i and t[i - 1] == 'EN') or (i + 1 < n and t[i + 1] == 'EN')): t[i] = 'EN'
    for i in range(1, n - 1):
        if t[i] in ('CS', 'ES') and t[i - 1] == 'EN' and t[i + 1] == 'EN': t[i] = 'EN'
    k = []
    for i in range(n):
        if t[i] in ('L', 'R', 'EN'): k.append(t[i]); continue
        a = next((t[j] for j in range(i - 1, -1, -1) if t[j] in ('L', 'R', 'EN')), 'R')
        b = next((t[j] for j in range(i + 1, n) if t[j] in ('L', 'R', 'EN')), 'R')
        k.append('L' if a == 'L' and b == 'L' else 'R')
    out, i = [], 0
    while i < n:
        if k[i] == 'R': out.append(chars[i]); i += 1; continue
        j = i
        while j + 1 < n and k[j + 1] != 'R': j += 1
        out.append(''.join(reversed(chars[i:j + 1]))); i = j + 1
    return ''.join(out)

# words that had vowel points come out with a gap where the points were
FIXES = {'ה בסק': 'הבסק', 'ה יי־ל ו': 'היי־לו'}
def fix(text):
    for a, b in FIXES.items(): text = text.replace(a, b)
    return text

def rows(path):
    """Visual rows: (y, right edge, size, bold, [cells]); cells split where a wide gap separates text (tables)."""
    for p in pymupdf.open(path):
        byy = {}
        for b in p.get_text('rawdict')['blocks']:
            for l in b.get('lines', []):
                for sp in l['spans']:
                    for ch in sp['chars']:
                        y = round((ch['bbox'][1] + ch['bbox'][3]) / 2)
                        key = next((yy for yy in byy if abs(yy - y) <= 2), y)
                        byy.setdefault(key, []).append((ch['bbox'][0], ch['bbox'][2], ch['c'], sp['size'], bool(sp['flags'] & 16)))
        for y in sorted(byy):
            cs = sorted(byy[y], key=lambda t: -t[0])
            cells, cur, last = [], [], None
            for c in cs:
                if last is not None and last - c[1] > 14: cells.append(cur); cur = []
                cur.append(c); last = c[0]
            cells.append(cur)
            texts = [fix(logical([c[2] for c in cell]).strip()) for cell in cells]
            yield y, round(cs[0][1]), max(c[3] for c in cs), cs[0][4], [t for t in texts if t]

def bold_label(text, bold):
    """A paragraph that opens in bold ("קריאת הגזרה." / "חומרים:") keeps its label bold."""
    m = re.match(r'^([^.:]{2,40}[.:])\s*(.*)$', text)
    return f'<b>{html.escape(m.group(1))}</b> {html.escape(m.group(2))}'.strip() if bold and m else html.escape(text)

def from_pdf(model):
    rs = [r for r in rows(os.path.join(PDFS, model + '.pdf'))
          if r[2] < 20 and r[2] > 7 and not re.fullmatch(r'\d+ / \d+', ' '.join(r[4])) and 'סטודיו לתפירה' not in ' '.join(r[4])]
    title = ''
    for r in rows(os.path.join(PDFS, model + '.pdf')):
        if r[2] >= 20: title = ' '.join(r[4]).replace('הוראות תפירה · ', ''); break
    sections, cur, groups, mode, para = [], None, [], 'info', None
    def flush():
        nonlocal para
        if para is None: return
        txt = re.sub(r'\s+', ' ', para['text']).strip()
        if para['t'] == 'step': groups[-1]['steps'].append(html.escape(re.sub(r'^\d+\.\s*', '', txt)))
        else:
            target = groups[-1]['after'] if mode == 'after' else cur['blocks']
            if para['t'] == 'li':
                if target and target[-1]['t'] == 'list': target[-1]['items'].append(html.escape(txt))
                else: target.append({'t': 'list', 'items': [html.escape(txt)]})
            else: target.append({'t': 'note' if txt.startswith('טיפ') else 'p', 'html': bold_label(txt, para['bold'])})
        para = None
    prev_y = None
    for y, x, size, bold, cells in rs:
        text = ' '.join(cells)
        if 'הגזרה וההוראות לשימוש אישי' in text: continue
        if text.startswith('שלבי תפירה'):               # a group of steps; "שלבי תפירה – ז׳קט:" names it
            flush(); mode = 'steps'; prev_y = y
            groups.append({'title': (text.split('–', 1)[1] if '–' in text else 'שלבי תפירה').strip(' :'), 'steps': [], 'photos': [], 'after': []}); continue
        step = re.match(r'^\d+\.\s', text)
        if mode in ('steps', 'after'):
            if step and mode == 'steps': flush(); para = {'t': 'step', 'text': text, 'bold': bold, 'x': x}
            elif mode == 'steps' and not bold and para and para['t'] == 'step': para['text'] += ' ' + text   # a wrapped step
            else:                                        # after the steps: a tip or a closing note
                if mode == 'steps' or bold or (prev_y is not None and y - prev_y > size * 2.1): flush(); mode = 'after'; para = {'t': 'p', 'text': text, 'bold': bold, 'x': x}
                else: para['text'] += ' ' + text
            prev_y = y; continue
        if size >= 12.5 and bold:                       # a heading: general rules, or the model's own section
            flush(); cur = {'title': text.rstrip(':'), 'blocks': []}; sections.append(cur); prev_y = y; continue
        if cur is None: cur = {'title': '', 'blocks': []}; sections.append(cur)
        if len(cells) >= 2:                              # a table row (a header row repeated on a new page is dropped)
            flush()
            if cur['blocks'] and cur['blocks'][-1]['t'] == 'table':
                if cells != cur['blocks'][-1]['rows'][0]: cur['blocks'][-1]['rows'].append(cells)
            else: cur['blocks'].append({'t': 'table', 'rows': [cells]})
            prev_y = y; continue
        new = para is None or bold or (prev_y is not None and y - prev_y > size * 2.1) or para['x'] != x \
            or (para['t'] == 'li' and y - prev_y > size * 1.75)   # list items sit further apart than wrapped lines
        if new:
            flush(); para = {'t': 'li' if x < 530 and not bold and size < 10.5 else 'p', 'text': text, 'bold': bold, 'x': x}
        else: para['text'] += ' ' + text
        prev_y = y
    flush()
    sections = [s for s in sections if s['blocks']]
    for s in sections:                                  # old branding in the general rules
        for b in s['blocks']:
            for k in ('html',):
                if k in b: b[k] = b[k].replace('gzarot', 'gizra')
    if len(groups) == 1: groups[0]['title'] = ''
    return {'model': model, 'title': title, 'sections': sections, 'groups': groups, 'source': 'pdf'}

def main(models):
    os.makedirs(OUT, exist_ok=True)
    for model in models:
        g = from_html(model) if os.path.exists(os.path.join(SRC, model + '.html')) else from_pdf(model)
        # photos: copied next to the guide, referenced by file name only
        dst = os.path.join(OUT, model); shutil.rmtree(dst, ignore_errors=True)
        def take(src):
            name = os.path.basename(src); os.makedirs(dst, exist_ok=True)
            shutil.copy(os.path.join(SRC, src), os.path.join(dst, name)); return name
        for grp in g['groups']: grp['photos'] = [take(p) for p in grp['photos']]
        for s in g['sections']:
            for b in s['blocks']:
                if b['t'] == 'photos': b['src'] = [take(p) for p in b['src']]
        json.dump(g, open(os.path.join(OUT, model + '.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        print(f"{model}: {g['source']}, {len(g['sections'])} sections, {sum(len(x['steps']) for x in g['groups'])} steps, {sum(len(x['photos']) for x in g['groups'])} photos")

if __name__ == '__main__':
    names = sys.argv[1:] or sorted(f[:-4] for f in os.listdir(PDFS) if f.endswith('.pdf') and f != 'photo-pattern.pdf')
    main(names)
