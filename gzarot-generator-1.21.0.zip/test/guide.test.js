'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs'), path = require('path');
const { guideData, guidePhoto } = require('../lib/guide');
const { MODELS } = require('../lib/models');

test('every catalogue model with instructions has an interactive guide that reads right', () => {
  for (const key of Object.keys(MODELS).filter(k => MODELS[k].kind !== 'photo')) {
    if (!fs.existsSync(path.join(__dirname, '..', 'instructions', key + '.pdf'))) continue;
    const g = guideData(key);
    assert.ok(g, key + ': guide');
    const steps = g.groups.flatMap(x => x.steps);
    assert.ok(steps.length >= 5, key + ': steps');
    const text = JSON.stringify(g);
    assert.doesNotMatch(text, /\)[א-ת][^()]*\(/, key + ': brackets in reading order');
    assert.doesNotMatch(text, /%\d/, key + ': percent after the number');
    assert.doesNotMatch(text, /gzarot/, key + ': branding');
    for (const gr of g.groups) for (const f of gr.photos) assert.ok(guidePhoto(key, f), key + ': photo ' + f);
  }
  assert.strictEqual(guidePhoto('kim-dress', '../package.json'), null);
});
