'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { gradePiece, DEFS, build } = require('../lib/traced');
const { engine } = require('../lib/render');

for (const name of ['kardi', 'apoline']) {
  test(`${name}: grading at a chart size reproduces the traced size exactly`, () => {
    const data = require(`../lib/patterns/${name}.json`), mid = Math.floor(data.sizes.length / 2);
    for (let s = 0; s < data.sizes.length; s++) for (const pc of data.pieces) {
      const g = gradePiece(pc, { B: s, W: s, H: s }, 0, mid);
      g.cut.forEach((p, i) => assert.ok(Math.hypot(p[0] - pc.outline[s][i][0], p[1] - pc.outline[s][i][1]) < 0.01, `${pc.key} ${data.sizes[s]} #${i}`));
    }
  });
}

test('apoline: corset and skirt take their own pieces; skirt length moves the hem only', () => {
  const data = require('../lib/patterns/apoline.json');
  const corset = build(data, DEFS.apoline, engine, { B: 91, W: 71, H: 99 });
  const skirt = build(data, DEFS.apolineskirt, engine, { W: 71, H: 99, dL: 0 });
  assert.strictEqual(corset.pieces, data.pieces.filter(p => p.group === 'corset').length + 1);
  assert.strictEqual(skirt.pieces, data.pieces.filter(p => p.group === 'skirt').length + 1);
  const pc = data.pieces.find(p => p.key === 'fskirt2'), T = { W: 3, H: 3 };
  const a = gradePiece(pc, T, 0, 3).cut, b = gradePiece(pc, T, 10, 3).cut;
  const ext = c => [Math.min(...c.map(p => p[0])), Math.max(...c.map(p => p[0]))];
  assert.ok(Math.abs(ext(b)[1] - ext(a)[1] - 100) < 0.5 && Math.abs(ext(b)[0] - ext(a)[0]) < 0.5, 'the horizontal front panel lengthens at its hem end');
  assert.deepStrictEqual(engine.validate('apolineskirt', { W: 0, H: 99 }).length, 1);
});
