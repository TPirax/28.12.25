# Sewing knowledge base

What we learn from each pattern's original sewing instructions. It feeds three things:
the catalogue instructions (`tools/instructions-src/`), new building blocks for photo patterns (`lib/draft/`),
and what the photo analysis (`lib/vision.js`) is asked to recognise. Add a section per pattern.

## KIM (source: Kim_information, GZAROT, 44 steps)

**Garment:** fitted sleeveless dress, maxi or mini. Halter collar band closing with one button at the nape,
two straps from the collar ends down to the back, open back with invisible zip, fully lined.

**Pieces:** front (on fold), back (pair), strap (×2, main only), collar (on fold, main + lining).
Size chart in inches, 7 sizes XS–3X, matches `CH` in `lib/engine.js` exactly. Seam allowance 1.5 cm on all pieces (confirmed by the designer).

**Techniques**
| Technique | How KIM does it | Reusable for |
|---|---|---|
| Bag lining (sleeveless) | Shell and lining sewn separately, joined right sides together along armholes and sides, turned through the open back | any lined sleeveless bodice or dress |
| Understitching | seam allowance stitched to the lining after joining, so the lining does not roll out | every lined edge |
| Loop-turned straps | fold lengthwise RST, stitch, trim, turn with loop turner / safety pin | spaghetti straps, ties, button loops |
| Straps sandwiched | strap basted to the back notch pointing down, caught between shell and lining | any strap that exits a lined edge |
| Collar band | main + lining RST, sew top and sides, bottom only outside the notches; attach main layer to neckline, fold lining over and topstitch | halter collars, stand collars, waistbands |
| Invisible zip in lined back | zip to shell first (teeth away from CB), then lining to the zip tape RST, zip sandwiched | any lined dress with CB zip |
| Fitting last | strap length set on the body at the very end | any strap or halter |
| Rolled hem | fold twice, hide raw edge; shell and lining separately | light wovens |

**Building blocks this suggests for photo patterns:** halter collar band with button (`upper.neckline_front: 'halter'`),
straps from collar to back, full lining as an option, invisible CB zip with lining.

**Issues found in the source document** (fixed in our version): fabric "33 m" (3 m); seam allowance given as both
1.5 cm and 0.5″ (1.5 cm is correct); step 18 says both layers right side up (must be right sides together);
"MOTTUB" (BUTTON, reversed text); mixed grammatical gender.

## KARDI (source: INFO_KARDI + A0 pattern, GZAROT, 55 steps)

**Garment:** evening gown with a boned corset bodice: separate cups rising into a halter, princess-seamed bodice
(centre front on fold, side front, side back, centre back), long skirt with front pleats and a high slit,
back darts, CB zip, fully lined. Same size chart as KIM. Seam allowance ½″ (1.27 cm). Skirt drafted for 173 cm.

**Pattern data:** traced from the A0 file with `tools/trace-pattern.py` (config `tools/patterns/kardi.json`),
graded per point by `lib/traced.js`: cups by bust, bodice from bust (top) to waist (bottom), skirt from waist to
hip (20 cm) then hips. Skirt length adjusts below the hip line.

**Techniques**
| Technique | How KARDI does it | Reusable for |
|---|---|---|
| Interfaced corset bodice | light–medium fusible on all shell bodice pieces before sewing | any structured bodice |
| Princess seams as boning channels | seams pressed away from CF, topstitched to form channels; bones only in the shell | corsets, bustiers |
| Bone length | each bone ¾″ (2 cm) shorter than the channel at both ends; ends taped or melted | all boned garments |
| Pleats into a waist seam | fold pleats upward per marks, baste across, press | draped skirts |
| Asymmetric slit with lining | lining front skirt cut mirrored; slit edges joined shell-to-lining and understitched | any lined slit |
| Lined cups sandwiched | cup shell + lining joined on the sides only, turned, basted to the bodice, caught between shell and lining at the top edge | halter / sweetheart cups |
| Matching the waistline at the zip | sew one side of the zip, close it, chalk the waistline on the other side, then sew | any zip crossing a seam |
| Halter fitted last | strap ends joined at the nape at the very end, length set on the body | halters |

**Building blocks this suggests for photo patterns:** boned princess corset bodice, separate cups with halter,
pleated front skirt, asymmetric front slit (lining mirrored).

**Issues found in the source document** (fixed in our version): step range "35–3N"; "להפוך שמלה לצד שמאל"
(means: turn inside out); the zip is listed without a type.

## APOLINE (source: APOLINE-INFO 57 steps + info-apolin 21 steps + A0 set, GZAROT)

**Garment:** set of a boned corset and a gathered ball-gown skirt. Corset: four panels per side (centre front,
side front, side back, centre back), three-part cups (front, back, top) with optional foam and underwire, 7 bones,
bias-bound cups and bottom, back lacing through 16–20 grommets, optional modesty panel cut on the fold.
Skirt: shell gathered onto a separate, narrower lining; two overlapping fronts with a slit; back with CB zip;
interfaced waistband. Size chart in inches (corset chart = KIM chart; hips differ slightly). Seam allowance ½″ (1.27 cm).
Materials: corset 0.75 m shell + 0.75 m lining; skirt 3 yd shell + 2.5 yd lining, zip 15–20 cm.

**Pattern data:** one A0 set file at ¼ scale (`scale` in `tools/patterns/apoline.json`), 6 sheets whose pieces cross
sheet edges (`sheet_offsets_mm`), size S drawn with a dash that has a zero gap (classified by colour), shared edges
drawn once in solid black (`shared_solid`). Corset panels graded bust → waist (at the narrowest point) → hips; cups by
bust; skirt waist → hip over 20 cm then hips, waist end found automatically (front 2 lies across the sheet).
Waistband lengths measured per size (XS 67.3 … XXXL 97.8 cm, 6.35 cm wide); modesty panel 8.9 × 22.9 cm on fold.

**Techniques**
| Technique | How APOLINE does it | Reusable for |
|---|---|---|
| Shell + lining as two complete bodies | all panels of each layer joined into a full "top" first, then the layers joined | corsets, lined bodices |
| Bones in the seam allowance | bone centred on the seam, one side stitched to the allowance only: no stitching on the face | any boned seam without channels |
| Bone clearance | ¾″ (2 cm) short of the top and bottom; ends taped or melted | all boned garments |
| Back bones in a stitched channel | ½″ from the back edge through both layers, after the lining is joined | lace-up backs |
| Three-part cup | front + back cup joined, pressed towards the larger part over a ham, topstitched; top cup added with its high side at the larger side | sweetheart / balconette cups |
| Cup foam | foam cut from the cup pieces, placed behind the shell, sewn into the top seam only | moulded cups |
| Bias over the cup seam | bias sewn to the cup allowance, allowances trimmed, bias folded over: forms an underwire channel | underwired cups |
| Bias-bound bottom | bias on the face, trimmed, turned fully inside so it does not show | corset hems, curved edges |
| Modesty panel | shell + lining sewn on three sides, turned, stitched behind the lacing along the bone channel | any laced back |
| Grommet spacing | first 6 mm from the top, then every 2.5 cm | lacing |
| Gathered shell on a fitted lining | top of each shell piece 75 % longer than its lining, gathered to the lining length | ball-gown and bubble skirts |
| Overlapping fronts with a slit | each half (front + back) finished with its lining, then front 1 laid over front 2 to a mark | wrap / slit skirts |
| Waistband | interfaced shell + lining sewn along the top, shell allowance pressed under, lining side sewn to the skirt, shell stitched in the ditch | any waistband |
| Hem set on the body | length decided while wearing; lining hemmed shorter; rolled hems | long skirts |

**Building blocks this suggests for photo patterns:** separate three-part cups on a boned bodice, lace-up back with
modesty panel, gathered skirt on a lining, overlapping slit fronts.

**Issues found in the source documents** (fixed in our version): "8 pattern pieces" while the cups are named right/left
(they are front/back halves); "שלבים 4-6" vs the actual 4–9 range; "חולצה" for the corset body; mixed grammatical
gender and person; "חוט תחתון" (bobbin thread) where an underwire is meant; skirt cut list says "1 doubled" for
pieces cut once; step numbers out of order (17/19).

**Tracing lessons (now automatic in `tools/trace-pattern.py`):** a size's outline can retrace a shared edge there and
back, or take a long detour along a neighbouring size's line; one size with a stray kink must not be the corner template.

