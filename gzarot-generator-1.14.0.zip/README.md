<div dir="rtl">

# gzarot · מחולל הגזרות

שירות קטן שמקבל לקוחה מהאתר (עם כרטיס חתום מהתוסף Gzarot Fit Quota), מציג לה תצוגה מקדימה ובחירות עיצוב, ומפיק PDF ל־A4 או A0 עם השם והאימייל שלה בכל עמוד.

הנוסחאות של הגזרות רצות רק כאן, בשרת. הלקוחה רואה תצוגה מקדימה ברזולוציה נמוכה (תמונה, לא קובץ וקטורי), ומקבלת רק PDF עם סימן מים.

## איך זה עובד

1. באזור האישי באתר הלקוחה לוחצת "צרי את הגזרה". התוסף בודק מכסה ושולח POST ל־`/generate` עם `ticket` חתום (HMAC-SHA256, תקף 10 דקות, שימוש אחד).
2. המחולל מאמת את החתימה, את התוקף ושהכרטיס לא נוצל, ופותח חלון עבודה שקשור לדפדפן שלה (עוגייה) לשלוש שעות.
3. היא רואה את המידות מהפרופיל (נעולות), משנה בחירות עיצוב אם יש, ומורידה PDF.

## כתובות

| כתובת | מה |
|---|---|
| `GET /health` | בדיקת חיים |
| `GET /models.json` | רשימת הדגמים, הקטגוריות והמידות שכל דגם צריך. התוסף משתמש בה לבחירת קטגוריה ודגם ולבדיקת מידות חסרות |
| `POST /generate` | קבלת הכרטיס מהאתר |
| `/s/<id>` | עמוד הלקוחה, תצוגה מקדימה והורדה |
| `POST /s/<id>/fabric` | מחשבון בד: כמה מטר מכל בד לרוחב 110, 140 ו־150 ס״מ, לפי האפשרויות שנבחרו |
| `/s/<id>/instructions` | הוראות התפירה של הדגם (PDF). רק בחלון הפעיל של הלקוחה, ולא נספר כהורדה |

## הגדרות (משתני סביבה)

| משתנה | חובה | הסבר |
|---|---|---|
| `GZFQ_SECRET` | כן | מפתח החתימה מעמוד ההגדרות של התוסף. השירות לא עולה בלעדיו |
| `SITE_URL` | מומלץ | לאן להחזיר לקוחה כשמשהו לא תקין, למשל `https://www.gzarot.co.il/my-account/custom-fit/` |
| `DATA_DIR` | מומלץ | תיקייה **קבועה** (דיסק שלא נמחק בהפעלה מחדש) לקובץ ה־SQLite |
| `PORT` | לא | ברירת מחדל 3000 |
| `SESSION_TTL` | לא | תוקף חלון ההורדה בשניות, ברירת מחדל 10800 (3 שעות) |
| `ANTHROPIC_API_KEY` | לגזרה מתמונה | מפתח API של Claude (platform.claude.com). בלעדיו העמוד "גזרה מתמונה" מודיע שהשירות לא הופעל |
| `VISION_MODEL` | לא | ברירת מחדל `claude-sonnet-5-5` |
| `MAX_ANALYSES_PER_DAY` | לא | ניתוחי תמונה ללקוחה ביום, ברירת מחדל 8 (שומר על עלויות) |

## גזרה מתמונה

הלקוחה מעלה תמונה או שרטוט. התמונה מוקטנת בדפדפן, מקודדת מחדש בשרת (בלי מידע מיקום), ונשלחת ל־Claude עם סכמת JSON קבועה. התשובה היא "מפרט בגד": קטגוריה, בד, גזרה, מחשוף, שרוול, צללית, אורך ועוד.
הלקוחה רואה את מה שזוהה, מתקנת אם צריך, ורואה תצוגה מקדימה. רק כשהיא לוחצת "צרי את הגזרה" המחולל מבקש מהאתר לחייב (`POST /wp-json/gzfq/v1/charge`, חתום ב־HMAC). האתר מחליט: מכסה, הורדה חוזרת חינם, או סירוב אם המנוי לא כולל גזרה מתמונה.

אבני הבניין נמצאות ב־`lib/draft`:
- חצאיות: ישרה, עיפרון, A (עם פנסים), פאנלים מתרחבים, חצוצרה, מרמייד, חצי עיגול, עיגול מלא, מכווצת.
- חלק עליון: גזרת בסיס עם כתפיים, פנס חזה ופנסי מותן, 7 סוגי מחשוף, רוכסן בגב או כפתורים, ושרוול שהכיפה שלו מחושבת כך שתתאים לאורך פתח השרוול.
- שמלות: חלק עליון + חצאית בתפר מותן, שמלה ישרה בלי תפר מותן, או סטרפלס וכתפיות עם תפרי נסיכה.
- מכנסיים: צרים, ישרים, רחבים, מתרחבים, עם רוכסן מקדימה, רוכסן בצד או גומי.

מידות שחסרות בפרופיל מחושבות לפי פרופורציות סטנדרטיות, והלקוחה רואה אילו מידות חושבו כך.

## הרצה

דרישות: Node.js 22.5 ומעלה (בגלל `node:sqlite`).

```
npm ci --omit=dev
GZFQ_SECRET=... DATA_DIR=/data npm start
```

או עם Docker: `docker build -t gzarot-generator .` ואז `docker run -p 3000:3000 -v gzdata:/data -e GZFQ_SECRET=... gzarot-generator`.
(קובץ ה־Dockerfile לא נבנה בסביבת הפיתוח, כי לא הייתה גישה ל־Docker Hub. כדאי לבנות פעם אחת לפני ההעלאה.)

השירות חייב לרוץ מאחורי HTTPS, כי העוגיות מסומנות Secure.

## מחשבון הבד

`lib/yardage.js` מחשב כמה בד לקנות. הוא מוצא את חלקי הגזרה מתוך קווי הגזירה (גם בדגמים המיובאים), מסובב כל חלק לכיוון הבד ומסדר את החלקים על בד מקופל לאורך. חלק רחב מדי עובר לבד פתוח בשכבה אחת. לכל דגם יש ב־`CUTS` רשימת גזירה: איזה חלק, מאיזה בד, כמה, והאם על קיפול. גזרה מתמונה נקראת אוטומטית מהשורה "גזרו …" שעל כל חלק. דגם חדש צריך שורה ב־`CUTS`. הבדיקות נכשלות אם דגם לא מחזיר טבלת בד.

## עדכון גזרות

הוראות התפירה נמצאות בתיקייה `instructions/`, קובץ PDF אחד לכל דגם בשם המפתח שלו (למשל `kim-dress.pdf`). דגם חדש צריך גם קובץ כזה. בלי קובץ, הכפתור מציג "אין עדיין הוראות לדגם הזה".


הקוד של הגזרות (`lib/engine.js`) נבנה אוטומטית מאפליקציית העיצוב (`corset-pattern.html`), כך שיש מקור אחד לנוסחאות:

```
npm run build:engine -- /path/to/corset-pattern.html
npm test
```

הקטגוריות מוגדרות ב־`CATEGORIES` שב־`lib/models.js`, וכל דגם מציין ב־`cats` לאילו קטגוריות הוא שייך (למשל `women/evening`). דגם יכול להופיע ביותר מקטגוריה אחת. באפליקציית העיצוב יש אותה רשימה (`CATS` ו־`MODEL_CATS`).

דגם חדש: מוסיפים אותו לאפליקציה, ואז מוסיפים שורה ב־`lib/models.js` עם המידות מהפרופיל שהוא צריך ובחירות העיצוב שמותר לשנות. הרשימה בתוסף מתעדכנת לבד תוך שעה.

## בדיקות

`npm test` מריץ 27 בדיקות. ניתוח התמונה מוחלף בתשובות קבועות (`test/fixtures/specs.js`), כך שהבדיקות לא צריכות מפתח API. 18 מהן הן: כל אחד מ־10 הדגמים מקצה לקצה (כרטיס, עמוד, תצוגה, PDF ב־A4 וב־A0), כרטיס שנוצל, פג תוקף, זויף או נחתם במפתח אחר, חלון בלי עוגייה, מידות חסרות, דגם לא מוכר, וניסיון לשנות מידות גוף דרך בחירות העיצוב.

</div>


## Hostinger
Entry file: `server.js` (Node.js 22.x). `npm run build` only verifies the bundled `lib/engine.js`; regenerating it from `corset-pattern.html` is `npm run build:engine -- /path/to/corset-pattern.html`.
Set `GZFQ_SECRET` and `DATA_DIR`; leave `PORT` to the host. Persist and back up `DATA_DIR` outside the redeployed application directory.
Admin test login: set `GIZRA_ADMIN_PASSWORD` (20+ characters) and open `/admin/login`. See `ADMIN-HOSTINGER-SETUP.md`.

## Backups and dashboard
The admin studio has a backup page (`/admin/backup`): download a full snapshot of `generator.db`, daily snapshots kept next to the database (`backups/`, last 7), and restore from a file (the current data is saved first). Download a backup before every Redeploy.
The dashboard (`/admin/stats`) counts customer downloads and photo analyses (admin tests excluded) and estimates the analysis cost from the token counts. Prices default to the `VISION_MODEL` list price; override with `VISION_PRICE_IN` / `VISION_PRICE_OUT` (USD per million tokens).


## Sewing instructions
`instructions/<model>.pdf` is rendered from `tools/instructions-src/<model>.html` by `node tools/build-instructions.js <model>` (needs Playwright).
What we learn from each pattern's source instructions is collected in `docs/sewing-knowledge.md`.

## Traced multi-size patterns
A pattern that comes as nested sizes in a vector PDF (one colour per size) is traced, not redrawn:
`python3 tools/trace-pattern.py tools/patterns/<name>.json <A0.pdf>` (needs `pip install pymupdf`) writes `lib/patterns/<mode>.json`
with every piece's cut line in every size, point for point. `lib/traced.js` grades between the sizes per body zone and registers the
model with the engine; add the model to `lib/models.js` and its texts to `DEFS` in `lib/traced.js`. KARDI was the first such model.
One file can feed several models: APOLINE's set file holds a corset and a skirt, split by each piece's `group`
(`DEFS.apoline`, `DEFS.apolineskirt`). A piece with no cut line on the sheet in every size (a waistband, the modesty panel)
is added as a measured rectangle in `extra`. Zones: `const`, `span` (top to bottom), `levels` (bust, waist at the narrowest
point, hips) and `skirt` (waist end `top`/`bottom`/`auto`). Pieces longer than an A0 sheet are laid across it.
The tracer drops lines retraced there and back and long detours along a neighbouring size's line, and takes as template
the size whose corners agree with most sizes; check `lib/patterns/<mode>.json` for sizes whose points do not progress
smoothly before adding a model.

