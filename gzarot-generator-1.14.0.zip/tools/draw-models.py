# Draws the model illustrations in public/models/<key>.svg. Run: python3 tools/draw-models.py public/models
import pathlib, sys, colorsys
out = pathlib.Path(sys.argv[1])

def hx(c): c = c.lstrip('#'); return tuple(int(c[i:i+2], 16) / 255 for i in (0, 2, 4))
def mix(c, t):  # t>0 towards white, t<0 towards black
    r, g, b = hx(c); f = (lambda v: v + (1 - v) * t) if t > 0 else (lambda v: v * (1 + t))
    return '#%02x%02x%02x' % tuple(round(max(0, min(1, f(v))) * 255) for v in (r, g, b))

def svg(body, c1, c2=None, sheer=False):
    c2 = c2 or mix(c1, .35)
    ink, det = mix(c1, -.55), mix(c1, -.35)
    op = ' fill-opacity=".82"' if sheer else ''
    grad = lambda gid, c: f'''<linearGradient id="{gid}" x1="0" x2="1" y1="0" y2="0">
<stop offset="0" stop-color="{mix(c, -.30)}"/><stop offset=".22" stop-color="{mix(c, -.05)}"/><stop offset=".40" stop-color="{mix(c, .22)}"/>
<stop offset=".55" stop-color="{c}"/><stop offset=".80" stop-color="{mix(c, -.12)}"/><stop offset="1" stop-color="{mix(c, -.34)}"/></linearGradient>'''
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 140" role="img">
<defs>{grad('g1', c1)}{grad('g2', c2)}
<linearGradient id="v" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".10"/><stop offset=".6" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".12"/></linearGradient>
<pattern id="lace" width="6" height="6" patternUnits="userSpaceOnUse"><g fill="none" stroke="{det}" stroke-width=".35" opacity=".6"><circle cx="3" cy="3" r="1"/><path d="M3 1.2 Q4.2 .2 4.8 1.6 M4.8 3 Q6 3.4 5.2 4.6 M3 4.8 Q1.8 6 1.2 4.4 M1.2 3 Q0 2.6 .8 1.4"/></g></pattern>
<pattern id="mesh" width="2.4" height="2.4" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 0H2.4M0 0V2.4" stroke="{mix(c2, -.4)}" stroke-width=".25"/></pattern>
<filter id="sh" x="-20%" y="-10%" width="140%" height="130%"><feDropShadow dx="1.2" dy="2" stdDeviation="1.6" flood-color="#3a2a1a" flood-opacity=".22"/></filter>
</defs>
<g filter="url(#sh)" stroke="{ink}" stroke-width=".9" stroke-linejoin="round" stroke-linecap="round" fill="url(#g1)"{op}>{body.replace('DET', det).replace('INK', ink)}</g>
</svg>
'''
d = lambda p, w=.6, c='DET', extra='': f'<path d="{p}" fill="none" stroke="{c}" stroke-width="{w}"{extra}/>'
fold = lambda p, w=1.6: f'<path d="{p}" fill="none" stroke="#000" stroke-opacity=".10" stroke-width="{w}"/>'
shine = lambda p, w=1.4: f'<path d="{p}" fill="none" stroke="#fff" stroke-opacity=".38" stroke-width="{w}"/>'
dash = lambda p: d(p, .5, 'DET', ' stroke-dasharray="1.6 1.2"')
pearls = lambda pts: ''.join(f'<circle cx="{x}" cy="{y}" r="1.15" fill="#FBF4E4" stroke="#B8893B" stroke-width=".45"/><circle cx="{x-.35}" cy="{y-.35}" r=".35" fill="#fff" stroke="none"/>' for x, y in pts)
vshade = lambda p: f'<path d="{p}" fill="url(#v)" stroke="none"/>'

M = {}
KIM = 'M43 20 C40 27 35 31 34 37 C33 45 36 52 37 58 C35 72 33 92 30 130 Q50 133 70 130 C67 92 65 72 63 58 C64 52 67 45 66 37 C65 31 60 27 57 20 Q50 24 43 20 Z'
M['kim-dress'] = svg(f'<path d="{KIM}"/>' + vshade(KIM) + '<path d="M42 13 Q50 17 58 13 L58 20 Q50 24 42 20 Z" fill="url(#g2)"/>'
  + d('M43 38 L44.5 50 L46 38') + d('M57 38 L55.5 50 L54 38') + d('M44 60 L45 74 L46 60') + d('M56 60 L55 74 L54 60')
  + fold('M42 80 C41 96 40 112 38 129') + fold('M57 82 C58 98 60 114 62 129') + shine('M46 62 C45 82 44 104 43 128', 1.8) + shine('M40 40 C39 46 40 52 41 56', 1),
  '#1F6B57', '#174F41')
ALIX = 'M32 36 Q35 28 42 30 Q48 32 50 37 Q52 32 58 30 Q65 28 68 36 L66 54 Q66 62 69 74 L72 96 Q50 100 28 96 L31 74 Q34 62 34 54 Z'
M['alix-dress'] = svg(f'<path d="{ALIX}"/><path d="{ALIX}" fill="url(#lace)" stroke="none"/>' + vshade(ALIX)
  + d('M41.5 30.5 C40.5 46 40 60 38 98') + d('M58.5 30.5 C59.5 46 60 60 62 98')
  + d('M36 40 L36 60', .4) + d('M64 40 L64 60', .4) + d('M47 38 L47 60', .4) + d('M53 38 L53 60', .4)
  + shine('M44 40 C44 60 43 78 42 94', 1.8)
  + d('M28 96 Q30 99 32 96.6 Q34 99.6 36 97.2 Q38 100 40 97.6 Q42 100.3 44 97.9 Q46 100.5 48 98 Q50 100.6 52 98 Q54 100.5 56 97.9 Q58 100.3 60 97.6 Q62 100 64 97.2 Q66 99.6 68 96.6 Q70 99 72 96', .6, 'INK'),
  '#F1E8D8')
POLLA = 'M34 34 L66 34 C72 60 78 90 84 118 Q50 126 16 118 C22 90 28 60 34 34 Z'
M['polla-skirt'] = svg(f'<path d="{POLLA}"/>' + vshade(POLLA) + '<rect x="33" y="24" width="34" height="10" rx="1" fill="url(#g2)"/>'
  + ''.join(d(f'M{x} 25.5 L{x} 32.5', .4) for x in range(35, 66, 2))
  + fold('M40 40 C37 66 32 94 27 121', 2.2) + fold('M50 38 L50 123', 1.8) + fold('M60 40 C63 66 68 94 73 121', 2.2)
  + shine('M45 40 C44 66 42 94 40 122', 2) + shine('M56 40 C57 66 59 94 61 122', 1.2)
  + dash('M18.5 114 Q50 121.5 81.5 114'), '#C9868B')
PAY = 'M30 46 Q32 34 41 34 Q48 35 50 44 Q52 35 59 34 Q68 34 70 46 L67 66 Q66 72 73 92 Q50 99 27 92 Q34 72 33 66 Z'
M['paypay-corset'] = svg(f'<path d="{PAY}"/>' + vshade(PAY)
  + '<path d="M30 46 Q32 34 41 34 Q48 35 50 44 L50 52 Q40 49 30 52 Z" fill="url(#g2)"/><path d="M70 46 Q68 34 59 34 Q52 35 50 44 L50 52 Q60 49 70 52 Z" fill="url(#g2)"/>'
  + d('M40 35 Q41 44 40 50.5', .5) + d('M60 35 Q59 44 60 50.5', .5)
  + d('M50 52 L50 96', .8, '#B8893B') + d('M42 51 C42 64 41 76 38 95') + d('M58 51 C58 64 59 76 62 95')
  + d('M35 52 C36 64 34 78 31 93', .5) + d('M65 52 C64 64 66 78 69 93', .5)
  + shine('M45 54 C45 66 44 80 43 94', 1.8) + shine('M37 38 Q40 36 44 38', 1.2), '#2C2A31', '#E2C6A2')
MAR = 'M33 30 L67 30 L66 42 C64 52 64 58 66 66 C67 78 64 88 63 98 C70 114 78 126 85 134 Q50 139 15 134 C22 126 30 114 37 98 C36 88 33 78 34 66 C36 58 36 52 34 42 Z'
M['lace-mermaid'] = svg(f'<path d="{MAR}"/>' + vshade(MAR)
  + '<path d="M34 42 C36 52 36 58 34 66 L50 64 L66 66 C64 58 64 52 66 42 Z" fill="url(#g2)" stroke="none"/><path d="M34 42 C36 52 36 58 34 66 L50 64 L66 66 C64 58 64 52 66 42 Z" fill="url(#mesh)" stroke="none"/>'
  + '<path d="M34.5 44 L50 64 L65.5 44 L66 66 C67 78 64 88 63 98 L37 98 C36 88 33 78 34 66 Z" fill="url(#g1)" stroke="none"/>'
  + '<path d="M33 30 L67 30 L66 42 L34 42 Z" fill="url(#lace)" stroke="none"/>'
  + d('M34 42 L66 42', .7, 'INK') + d('M34.5 44 L50 64 L65.5 44', .8, 'INK')
  + d('M42 66 C42 82 41 92 40 100 C36 114 32 126 29 136') + d('M58 66 C58 82 59 92 60 100 C64 114 68 126 71 136')
  + fold('M46 104 C44 116 41 126 38 136', 2) + fold('M54 104 C56 116 59 126 62 136', 2) + shine('M45 68 C45 84 44 96 44 104 C42 116 40 126 37 135', 1.6)
  + d('M37 98 Q50 101 63 98', .5), '#22396B', '#D9BCA3')
M['pearl-halter'] = svg('<path d="M34 92 C26 108 18 122 12 134 Q50 141 88 134 C82 122 74 108 66 92 Z" fill="url(#g2)"/>'
  + fold('M30 104 C26 116 22 126 18 134', 2) + fold('M70 104 C74 116 78 126 82 134', 2)
  + '<path d="M36 64 C30 74 27 84 30 96 Q50 103 70 96 C73 84 70 74 64 64 L50 78 Z"/>' + vshade('M36 64 C30 74 27 84 30 96 Q50 103 70 96 C73 84 70 74 64 64 L50 78 Z')
  + shine('M38 72 C35 80 35 88 37 95', 2) + d('M33 92 Q50 98 67 92', .5)
  + '<path d="M43 10 L35 30 C34 44 37 54 36 64 L50 78 L64 64 C63 54 66 44 65 30 L57 10 L50 42 Z"/>' + d('M43 10 Q50 6 57 10', 1.4, 'INK')
  + d('M41 22 C40 40 42 54 43 70') + d('M59 22 C60 40 58 54 57 70') + shine('M38 32 C37 44 39 54 39 62', 1.2)
  + pearls([(41, 26), (40.6, 32), (40.6, 38), (41, 44), (41.6, 50), (42.2, 56), (42.7, 62), (59, 26), (59.4, 32), (59.4, 38), (59, 44), (58.4, 50), (57.8, 56), (57.3, 62), (50, 48), (50, 54), (50, 60), (50, 66), (50, 72)]),
  '#E4CFAE', '#EFE2CB')
COR = 'M32 36 Q35 27 42 29 Q48 31 50 36 Q52 31 58 29 Q65 27 68 36 L66 52 Q65 60 66 66 C67 78 64 88 63 98 C71 114 80 126 88 136 Q50 140 12 136 C20 126 29 114 37 98 C36 88 33 78 34 66 Q35 60 34 52 Z'
M['corset-mermaid'] = svg(f'<path d="{COR}"/>' + vshade(COR)
  + '<path d="M32 36 Q35 27 42 29 Q48 31 50 36 L50 44 Q41 42 33 44 Z" fill="url(#g2)"/><path d="M68 36 Q65 27 58 29 Q52 31 50 36 L50 44 Q59 42 67 44 Z" fill="url(#g2)"/>'
  + d('M34 62 L50 72 L66 62', .8, 'INK')
  + d('M41.5 44 C41 54 41 62 42 68') + d('M58.5 44 C59 54 59 62 58 68') + d('M37 45 L37 63', .45) + d('M63 45 L63 63', .45) + d('M50 44 L50 72', .45)
  + d('M42 70 C42 84 41 92 40 100 C35 114 30 126 26 137') + d('M58 70 C58 84 59 92 60 100 C65 114 70 126 74 137')
  + fold('M47 104 C45 116 42 126 39 138', 2.2) + fold('M53 104 C55 116 58 126 61 138', 2.2) + shine('M45 74 C45 86 44 96 43 104 C40 116 36 126 32 137', 1.6) + shine('M36 32 Q40 30 44 32', 1),
  '#7A1F35', '#E8B4B0')
MIRA = 'M28 38 Q39 28 50 36 Q61 28 72 38 L67 62 Q68 72 74 88 Q50 95 26 88 Q32 72 33 62 Z'
M['corset-bustier'] = svg(f'<path d="{MIRA}"/>' + vshade(MIRA) + d('M50 36 L50 93', .9, 'INK')
  + d('M42 32.5 C42 52 41 70 39 92') + d('M35 35 C36 52 35 70 32 90') + d('M46 35 C46 54 46 72 45 93')
  + d('M58 32.5 C58 52 59 70 61 92') + d('M65 35 C64 52 65 70 68 90') + d('M54 35 C54 54 54 72 55 93')
  + ''.join(f'<circle cx="51.6" cy="{y}" r=".75" fill="#C9A15A" stroke="none"/>' for y in range(42, 90, 8))
  + shine('M38.5 38 C39 54 38 72 36 90', 1.8) + shine('M60.5 38 C61 54 62 72 64 90', .9) + dash('M33 62 Q50 66 67 62'), '#DDA79E')
M['leon-tuxedo'] = svg('<path d="M34 76 L66 76 L64 134 L53 134 L50 88 L47 134 L36 134 Z" fill="url(#g2)"/>'
  + '<path d="M36.2 80 L37 133" stroke="#0E0F11" stroke-width="1.6" fill="none"/><path d="M63.8 80 L63 133" stroke="#0E0F11" stroke-width="1.6" fill="none"/>'
  + fold('M42 92 L42.5 132', 1.4) + fold('M58 92 L57.5 132', 1.4)
  + '<path d="M28 22 L20 74 L26 76 L33 40 Z"/><path d="M72 22 L80 74 L74 76 L67 40 Z"/>'
  + '<path d="M28 22 L42 17 L50 30 L58 17 L72 22 L71 80 Q60 84 51 78 L50 78 L49 78 Q40 84 29 80 Z"/>'
  + '<path d="M42 17 L50 30 L58 17 L55 16 L50 24 L45 16 Z" fill="#FBF6EE"/>'
  + '<path d="M47.6 19.6 L50 22 L52.4 19.6 L52.4 23 L50 21.8 L47.6 23 Z" fill="#0E0F11" stroke-width=".5"/>'
  + '<path d="M42 17 L50 30 L49 56 L40 36 L36 30 L41 27 Z" fill="#141518"/><path d="M58 17 L50 30 L51 56 L60 36 L64 30 L59 27 Z" fill="#141518"/>'
  + shine('M41 28 L46 46', 1.1) + shine('M59 28 L54 46', .7)
  + '<circle cx="50" cy="60" r="1.6" fill="#0E0F11"/>' + d('M33 66 L42 65', .8, '#5A6068') + d('M58 65 L67 66', .8, '#5A6068')
  + fold('M24 46 L22 70', 1.2) + shine('M33 30 L33 74', 1.4), '#3A3F46', '#30343A')
M['sielo-sleeve'] = svg('<path d="M26 92 Q20 112 12 126 Q20 130 26 127 Q32 132 38 128 Q44 133 50 129 Q56 133 62 128 Q68 132 74 127 Q80 130 88 126 Q80 112 74 92 Z" fill="url(#g2)"/>'
  + '<path d="M30 26 Q50 10 70 26 L75 92 Q50 98 25 92 Z"/>' + vshade('M30 26 Q50 10 70 26 L75 92 Q50 98 25 92 Z')
  + d('M25 92 Q50 98 75 92', .9, 'INK') + d('M50 16 L50 95', .5)
  + fold('M36 96 Q32 112 26 127', 2) + fold('M44 97 Q42 113 38 128', 1.6) + fold('M56 97 Q58 113 62 128', 1.6) + fold('M64 96 Q68 112 74 127', 2)
  + shine('M40 24 C39 50 38 72 37 92', 2) + shine('M40 100 Q38 114 33 127', 1.4)
  + ''.join(d(f'M{x} 93 L{x+.4} 96.5', .4) for x in range(28, 74, 3)), '#8FB0D2', '#A9C3DE', sheer=True)
M['venesa-dress'] = svg('<path d="M34 54 L66 54 C68 80 70 106 72 132 Q50 135 28 132 C30 106 32 80 34 54 Z" fill="url(#g2)"/>'
  + '<path d="M57 98 L61 133 L66 133 Z" fill="#000" fill-opacity=".18" stroke="none"/>'
  + fold('M42 58 C41 82 40 108 38 132', 2) + shine('M45 58 C44 82 43 108 42 132', 1.8)
  + '<path d="M39 14 L36 30 C34 38 35 46 34 54 L66 54 C65 46 66 38 64 30 L61 14 Q56 26 50 27 Q44 26 39 14 Z"/>' + vshade('M39 14 L36 30 C34 38 35 46 34 54 L66 54 C65 46 66 38 64 30 L61 14 Q56 26 50 27 Q44 26 39 14 Z')
  + d('M34 54 L66 54', .9, 'INK') + d('M57 98 L61 133', .7, 'INK') + d('M41 34 L42.5 46 L44 34') + d('M59 34 L57.5 46 L56 34') + shine('M39 30 C38 38 38 46 38 52', 1.2),
  '#B35A3F', '#A64F36')
M['riva-dress'] = svg('<path d="M37 58 C24 86 14 112 8 134 Q50 141 92 134 C86 112 76 86 63 58 Z"/>' + vshade('M37 58 C24 86 14 112 8 134 Q50 141 92 134 C86 112 76 86 63 58 Z')
  + fold('M44 61 C38 84 30 110 24 137', 2.2) + fold('M56 61 C62 84 70 110 76 137', 2.2) + fold('M50 62 L50 139', 1.4)
  + shine('M41 64 C34 88 27 112 20 136', 2) + shine('M53 64 C56 90 59 114 61 138', 1.2)
  + '<path d="M36 28 Q43 25 50 30 Q57 25 64 28 L63 58 Q50 61 37 58 Z"/>' + vshade('M36 28 Q43 25 50 30 Q57 25 64 28 L63 58 Q50 61 37 58 Z')
  + d('M37 58 Q50 61 63 58', .9, 'INK') + d('M43 27 C43 40 43 50 44 59') + d('M57 27 C57 40 57 50 56 59') + shine('M40 32 L40.5 56', 1.4)
  + d('M10 131 Q50 137 90 131', .4), '#F4EEE3')
M['jeneva-dress'] = svg('<path d="M33 22 L22 74 Q22 79 27 79 L31 77 L36 34 Z" fill="url(#g2)" fill-opacity=".72"/><path d="M67 22 L78 74 Q78 79 73 79 L69 77 L64 34 Z" fill="url(#g2)" fill-opacity=".72"/>'
  + '<path d="M37 54 C31 80 27 108 22 134 Q50 138 78 134 C73 108 69 80 63 54 Z"/>' + vshade('M37 54 C31 80 27 108 22 134 Q50 138 78 134 C73 108 69 80 63 54 Z')
  + fold('M44 57 C40 82 36 108 32 136', 2.2) + fold('M56 57 C60 82 64 108 68 136', 2.2) + shine('M47 58 C45 84 43 110 41 136', 1.8)
  + '<path d="M41 14 L33 22 L36 34 C36 42 37 48 37 54 L63 54 C63 48 64 42 64 34 L67 22 L59 14 L50 42 Z"/>'
  + d('M37 54 Q50 57 63 54', 1.1, 'INK') + ''.join(d(f'M{x} 51.5 L{x} 57.5', .4) for x in range(39, 62, 2))
  + d('M50 57 L50 137', .45) + d('M22.5 74 Q26 77 30.5 75.5', .6) + shine('M40 24 C39 34 39 44 40 50', 1.2), '#9C7FBF', '#B7A0D2')

# KARDI: halter corset gown with cups, boned princess bodice, front pleats and a high slit
KAR = 'M35 40 L65 40 L66 58 Q50 60 34 58 Z'
M['kardi-dress'] = svg('<path d="M34 58 Q50 61 66 58 C67 76 66 96 68 134 Q49 137 30 134 C32 100 33 76 34 58 Z"/>'
  + vshade('M34 58 Q50 61 66 58 C67 76 66 96 68 134 Q49 137 30 134 C32 100 33 76 34 58 Z')
  + '<path d="M57 84 L62 134.5 L53 135 Z" fill="#E8C9B5" stroke="none"/>' + d('M57 84 L53 135', .8, 'INK') + d('M57 84 L62 134.5', .8, 'INK')
  + fold('M38 62 Q50 70 62 64', 1.6) + fold('M37 68 Q50 78 63 70', 1.6) + fold('M37 75 Q48 84 60 77', 1.4)
  + shine('M40 86 C39 100 38 116 37 132', 1.8)
  + f'<path d="{KAR}"/>' + vshade(KAR)
  + '<path d="M44 10 L35 40 Q42 44 49 40 L48 22 Z" fill="url(#g2)"/><path d="M56 10 L65 40 Q58 44 51 40 L52 22 Z" fill="url(#g2)"/>'
  + d('M44 10 Q50 6 56 10', 1.3, 'INK') + d('M41 41 L41 57') + d('M46 41 L46 58') + d('M54 41 L54 58') + d('M59 41 L59 57') + d('M34 58 Q50 61 66 58', .9, 'INK')
  + shine('M40 20 L37 36', 1.1), '#B3122B', '#C3243B')

# APOLINE: corset with three-part cups and a pointed front, and the gathered ball-gown skirt worn with it
APO = 'M33 40 Q35 30 41 31 Q47 32 50 38 Q53 32 59 31 Q65 30 67 40 L66 66 Q65 80 66 92 Q58 97 50 106 Q42 97 34 92 Q35 80 34 66 Z'
M['apoline-corset'] = svg(f'<path d="{APO}"/>' + vshade(APO)
  + '<path d="M33 40 Q35 30 41 31 Q47 32 50 38 L49 47 Q41 44 34 48 Z" fill="url(#g2)"/><path d="M67 40 Q65 30 59 31 Q53 32 50 38 L51 47 Q59 44 66 48 Z" fill="url(#g2)"/>'
  + d('M34 48 Q41 44 49 47', .8, 'INK') + d('M66 48 Q59 44 51 47', .8, 'INK') + d('M41 31.5 Q41 40 42 46') + d('M59 31.5 Q59 40 58 46')
  + d('M50 38 L50 106', .6) + d('M43 46 C42 62 42 80 44 99') + d('M57 46 C58 62 58 80 56 99') + d('M37.5 47 C38 62 38 80 38 95', .45) + d('M62.5 47 C62 62 62 80 62 95', .45)
  + shine('M40 50 C40 64 40 80 41 94', 1.6) + shine('M38 34 Q41 32 44 34', 1), '#6E97AD', '#8FB0C2')
SKT = 'M38 30 L62 30 C74 56 86 92 94 132 Q50 141 6 132 C14 92 26 56 38 30 Z'
M['apoline-skirt'] = svg('<rect x="37" y="22" width="26" height="8" rx="1" fill="url(#g2)"/>' + f'<path d="{SKT}"/>' + vshade(SKT)
  + d('M37 30 L63 30', .9, 'INK') + d('M54 30 C58 64 63 100 66 136', .9, 'INK')
  + fold('M42 33 C36 62 28 98 20 134', 2.2) + fold('M48 33 C46 66 42 100 38 137', 1.8) + fold('M59 33 C66 64 74 98 82 134', 2.2)
  + shine('M45 33 C41 64 34 100 29 135', 2) + shine('M57 34 C61 66 67 100 72 136', 1.2)
  + ''.join(d(f'M{x} 30 L{x + .3} 33.5', .4) for x in range(39, 62, 2)), '#6E97AD', '#7FA4B8')

# Generic pictures by garment type, for customer designs added to the catalogue (the customer's photo is never shown there).
SAGE = '#7C9A8E'
M['_dress'] = svg('<path d="M41 16 L34 30 C33 42 36 50 36 58 C32 80 28 106 24 132 Q50 137 76 132 C72 106 68 80 64 58 C64 50 67 42 66 30 L59 16 Q50 24 41 16 Z"/>' + vshade('M41 16 L34 30 C33 42 36 50 36 58 C32 80 28 106 24 132 Q50 137 76 132 C72 106 68 80 64 58 C64 50 67 42 66 30 L59 16 Q50 24 41 16 Z')
  + d('M36 58 Q50 61 64 58', .8, 'INK') + fold('M43 62 C40 84 36 108 32 133', 2) + fold('M57 62 C60 84 64 108 68 133', 2) + shine('M46 62 C45 86 43 110 41 134', 1.8), SAGE)
M['_skirt'] = svg('<rect x="34" y="26" width="32" height="7" rx="1" fill="url(#g2)"/><path d="M34 33 L66 33 C71 58 76 88 80 116 Q50 122 20 116 C24 88 29 58 34 33 Z"/>' + vshade('M34 33 L66 33 C71 58 76 88 80 116 Q50 122 20 116 C24 88 29 58 34 33 Z')
  + fold('M42 36 C40 62 36 90 32 118', 2) + fold('M58 36 C60 62 64 90 68 118', 2) + shine('M46 36 C45 62 43 90 41 119', 1.8), SAGE)
M['_top'] = svg('<path d="M40 24 L28 30 L18 54 L26 58 L33 44 L34 80 Q50 84 66 80 L67 44 L74 58 L82 54 L72 30 L60 24 Q50 32 40 24 Z"/>' + vshade('M40 24 L28 30 L18 54 L26 58 L33 44 L34 80 Q50 84 66 80 L67 44 L74 58 L82 54 L72 30 L60 24 Q50 32 40 24 Z')
  + d('M33 44 L33.5 46', .6) + fold('M44 40 C43 56 43 68 42 80', 1.8) + shine('M40 38 C39 54 39 68 39 80', 1.6), SAGE)
M['_pants'] = svg('<path d="M34 24 L66 24 L70 130 L56 130 L50 60 L44 130 L30 130 Z"/>' + vshade('M34 24 L66 24 L70 130 L56 130 L50 60 L44 130 L30 130 Z')
  + d('M34 30 L66 30', .8, 'INK') + d('M50 30 L50 58', .6) + fold('M39 40 L37 128', 1.8) + fold('M61 40 L63 128', 1.8) + shine('M42 40 L40 128', 1.6), SAGE)
for k, v in M.items(): (out / f'{k}.svg').write_text(v)
print(len(M), 'drawings')
