// End-to-end tests for the generator. Run: npm test
'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs'), os = require('os'), path = require('path');
const { createApp } = require('../server');
const { signTicket } = require('../lib/ticket');
const { MODELS } = require('../lib/models');

const SECRET = 'x'.repeat(64);
const FULL = { height: 168, bust: 92, underbust: 76, waist: 72, hips: 100, knees: 82, waist_to_underbust: 9, waist_to_bust: 17, waist_to_hip: 20, waist_to_knee: 58, waist_to_floor: 105 };
let server, base, dir, n = 0;

function ticket(over = {}) {
  const now = Math.floor(Date.now() / 1000);
  return signTicket(Object.assign({ v: 1, iat: now, exp: now + 600, jti: 'j' + (++n) + '-' + Math.random(), usage_id: n, source: 'plan', model: 'kim-dress',
    customer: { id: 4, name: 'רותם לב', email: 'rotem@example.com' }, profile: { id: 4, label: 'המידות של רותם' }, unit: 'cm',
    measurements: FULL, watermark: 'רותם לב · rotem@example.com · gzarot #' + n, return_url: 'https://shop.test/my-account/custom-fit/' }, over), SECRET);
}
async function handoff(t) {
  const r = await fetch(base + '/generate', { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'ticket=' + encodeURIComponent(t) });
  return { status: r.status, loc: r.headers.get('location'), cookie: (r.headers.get('set-cookie') || '').split(';')[0], text: r.status === 303 ? '' : await r.text() };
}

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'gzgen-'));
  const app = createApp({ secret: SECRET, siteUrl: 'https://shop.test/', dbFile: path.join(dir, 'db.sqlite'), sessionTtl: 3600, secureCookies: false });
  await new Promise(r => { server = app.listen(0, r); });
  base = 'http://127.0.0.1:' + server.address().port;
  server.on('close', () => app.close());
});
test.after(() => server.close());

test('manifest lists every model with required fields', async () => {
  const m = await (await fetch(base + '/models.json')).json();
  assert.strictEqual(m.models.length, Object.keys(MODELS).length);
  const mer = m.models.find(x => x.key === 'lace-mermaid');
  assert.ok(mer.required.includes('waist_to_floor'));
});

for (const key of Object.keys(MODELS).filter(k => MODELS[k].kind !== 'photo')) {
  test('full flow: ' + key, async () => {
    const h = await handoff(ticket({ model: key }));
    assert.strictEqual(h.status, 303, h.text);
    const page = await fetch(base + h.loc, { headers: { cookie: h.cookie } });
    assert.strictEqual(page.status, 200);
    const html = await page.text();
    assert.match(html, new RegExp(MODELS[key].name.replace(/[()]/g, '.')));
    const pv = await (await fetch(base + h.loc + '/preview', { method: 'POST', headers: { cookie: h.cookie, 'Content-Type': 'application/json' }, body: '{"options":{}}' })).json();
    assert.ok(pv.img && pv.img.startsWith('data:image/png;base64,') && pv.img.length > 5000, 'preview for ' + key + ': ' + JSON.stringify(pv.warnings));
    assert.ok(pv.w <= 1500 && pv.h <= 1500);
    const fab = await (await fetch(base + h.loc + '/fabric', { method: 'POST', headers: { cookie: h.cookie, 'Content-Type': 'application/json' }, body: '{"options":{}}' })).json();
    assert.ok(fab.fabrics && fab.fabrics.length, 'fabric for ' + key);
    for (const f of fab.fabrics) {
      const v = [110, 140, 150].map(w => f.byWidth[w]);
      assert.ok(v[2] != null && v[2] > 0.2 && v[2] < 8, key + ' ' + f.label + ' ' + JSON.stringify(v));
      for (let i = 1; i < 3; i++) if (v[i - 1] != null) assert.ok(v[i] <= v[i - 1], key + ' wider fabric needs no more: ' + JSON.stringify(v));
    }
    for (const f of ['a4', 'a0']) {
      const r = await fetch(base + h.loc + '/pdf', { method: 'POST', headers: { cookie: h.cookie, 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'f=' + f });
      assert.strictEqual(r.status, 200);
      assert.strictEqual(r.headers.get('content-type'), 'application/pdf');
      const buf = Buffer.from(await r.arrayBuffer());
      assert.strictEqual(buf.subarray(0, 5).toString(), '%PDF-');
      fs.writeFileSync(path.join(dir, key + '-' + f + '.pdf'), buf);
    }
    assert.match(html, /\/instructions"/);
    const ins = await fetch(base + h.loc + '/instructions', { headers: { cookie: h.cookie } });
    assert.strictEqual(ins.status, 200, 'instructions for ' + key);
    assert.strictEqual(Buffer.from(await ins.arrayBuffer()).subarray(0, 5).toString(), '%PDF-');
    assert.strictEqual((await fetch(base + h.loc + '/instructions')).status, 403);
  });
}

test('replayed ticket is refused', async () => {
  const t = ticket();
  assert.strictEqual((await handoff(t)).status, 303);
  const again = await handoff(t);
  assert.strictEqual(again.status, 403);
  assert.match(again.text, /כבר נוצל/);
});

test('expired, tampered and foreign-key tickets are refused', async () => {
  const now = Math.floor(Date.now() / 1000);
  assert.strictEqual((await handoff(ticket({ exp: now - 5 }))).status, 403);
  const t = ticket(); const [b, s] = t.split('.');
  const body = JSON.parse(Buffer.from(b, 'base64url')); body.measurements.waist = 50;
  assert.strictEqual((await handoff(Buffer.from(JSON.stringify(body)).toString('base64url') + '.' + s)).status, 403);
  const other = signTicket(JSON.parse(Buffer.from(b, 'base64url')), 'y'.repeat(64));
  assert.strictEqual((await handoff(other)).status, 403);
  assert.strictEqual((await handoff('garbage')).status, 403);
});

test('session needs its cookie', async () => {
  const h = await handoff(ticket());
  assert.strictEqual((await fetch(base + h.loc)).status, 403);
  assert.strictEqual((await fetch(base + h.loc, { headers: { cookie: h.cookie + 'x' } })).status, 403);
});

test('missing measurements explain what to add', async () => {
  const h = await handoff(ticket({ model: 'lace-mermaid', measurements: { bust: 92, waist: 72, hips: 100, height: 165 } }));
  const html = await (await fetch(base + h.loc, { headers: { cookie: h.cookie } })).text();
  assert.match(html, /חסרות מידות/);
  assert.match(html, /מהמותן עד הרצפה/);
});

test('unknown model is refused cleanly', async () => {
  assert.strictEqual((await handoff(ticket({ model: 'zana' }))).status, 400);
});

test('options cannot override body measurements; bad options are ignored', async () => {
  const h = await handoff(ticket({ model: 'kim-dress' }));
  const r = await fetch(base + h.loc + '/preview', { method: 'POST', headers: { cookie: h.cookie, 'Content-Type': 'application/json' }, body: JSON.stringify({ options: { B: 200, W: 30, style: 'evil', len: 'abc' } }) });
  const pv = await r.json();
  assert.strictEqual(pv.used.B, 92); assert.strictEqual(pv.used.W, 72);
});

test('invalid design option blocks the PDF with a message', async () => {
  const h = await handoff(ticket({ model: 'lace-mermaid' }));
  const r = await fetch(base + h.loc + '/pdf', { method: 'POST', headers: { cookie: h.cookie, 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'f=a4&o_vD=1&o_sV=3' });
  assert.strictEqual(r.status, 400);
});
