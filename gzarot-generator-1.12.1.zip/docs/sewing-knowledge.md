# Sewing knowledge base

What we learn from each pattern's original sewing instructions. It feeds three things:
the catalogue instructions (`tools/instructions-src/`), new building blocks for photo patterns (`lib/draft/`),
and what the photo analysis (`lib/vision.js`) is asked to recognise. Add a section per pattern.

## KIM (source: Kim_information, GZAROT, 44 steps)

**Garment:** fitted sleeveless dress, maxi or mini. Halter collar band closing with one button at the nape,
two straps from the collar ends down to the back, open back with invisible zip, fully lined.

**Pieces:** front (on fold), back (pair), strap (×2, main only), collar (on fold, main + lining).
Size chart in inches, 7 sizes XS–3X, matches `CH` in `lib/engine.js` exactly. Seam allowance 1.5 cm on all pieces (confirmed by the designer).

**Techniques**
| Technique | How KIM does it | Reusable for |
|---|---|---|
| Bag lining (sleeveless) | Shell and lining sewn separately, joined right sides together along armholes and sides, turned through the open back | any lined sleeveless bodice or dress |
| Understitching | seam allowance stitched to the lining after joining, so the lining does not roll out | every lined edge |
| Loop-turned straps | fold lengthwise RST, stitch, trim, turn with loop turner / safety pin | spaghetti straps, ties, button loops |
| Straps sandwiched | strap basted to the back notch pointing down, caught between shell and lining | any strap that exits a lined edge |
| Collar band | main + lining RST, sew top and sides, bottom only outside the notches; attach main layer to neckline, fold lining over and topstitch | halter collars, stand collars, waistbands |
| Invisible zip in lined back | zip to shell first (teeth away from CB), then lining to the zip tape RST, zip sandwiched | any lined dress with CB zip |
| Fitting last | strap length set on the body at the very end | any strap or halter |
| Rolled hem | fold twice, hide raw edge; shell and lining separately | light wovens |

**Building blocks this suggests for photo patterns:** halter collar band with button (`upper.neckline_front: 'halter'`),
straps from collar to back, full lining as an option, invisible CB zip with lining.

**Issues found in the source document** (fixed in our version): fabric "33 m" (3 m); seam allowance given as both
1.5 cm and 0.5″ (1.5 cm is correct); step 18 says both layers right side up (must be right sides together);
"MOTTUB" (BUTTON, reversed text); mixed grammatical gender.
